# liblwjgl_glfw.so — LWJGL GLFW JNI adapter (Android)

## Kenapa file ini ada (Phase 1)
`org.lwjgl.glfw.GLFW` (LWJGL 3.3.3) tidak memanggil `libglfw.so` langsung.
Dia memanggil JNI methods yang harus ada di `liblwjgl_glfw.so`:

- Java: `GLFW.glfwInit()` -> JNI: `Java_org_lwjgl_glfw_GLFW_nglfwInit`
- Java: `GLFW.glfwCreateWindow(...)` -> JNI: `Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow`
- dst.

Kalau `liblwjgl_glfw.so` tidak ada, LWJGL throw `UnsatisfiedLinkError` walau `libglfw.so` ada.
Itulah yang terjadi sebelumnya: CMake build `liblwjgl.so` + `liblwjgl_opengl.so`,
Flint sediakan `libglfw.so`, tapi adapter JNI-nya tidak pernah di-build.

## Arsitektur
```
Minecraft Java (org.lwjgl.glfw.GLFW)
  -> liblwjgl_glfw.so  (file ini, JNI adapter)
    -> dlopen("libglfw.so")  (Flint C ABI, runtime only)
      -> Android Surface + EGL + GL4ES
```

`liblwjgl_glfw.so` TIDAK link `libglfw.so` di build time (cek `DT_NEEDED` — tidak boleh ada `libglfw.so` di sana).
Ini sengaja supaya binary GLFW desktop / GLIBC tidak pernah ke-link.

## Simbol yang harus ada
Cek dengan `scripts/verify_lwjgl_glfw.py`:
- ELF class 64-bit untuk arm64-v8a, 32-bit untuk armeabi-v7a
- `DT_NEEDED` hanya: libandroid.so, liblog.so, libEGL.so, libGLESv2.so, libdl.so, libc.so, libm.so
- Export JNI: `Java_org_lwjgl_glfw_GLFW_nglfwInit`, `nglfwTerminate`, `nglfwCreateWindow`, `nglfwDestroyWindow`, `nglfwMakeContextCurrent`, `nglfwSwapBuffers`, `nglfwPollEvents`, `nglfwWindowShouldClose`, `nglfwSetKeyCallback`, dst. (daftar lengkap di `src/lwjgl_glfw_jni.c`)

## Version compatibility
Adapter ini ditulis untuk LWJGL 3.3.3 (Minecraft 1.21.x).
JANGAN anggap satu build native cocok untuk semua versi Minecraft historis.
Untuk LWJGL 3.4.x / Minecraft 26.x snapshots, audit ulang signature JNI-nya — LWJGL bisa menambah / mengubah native methods.
