# FLINT — LWJGL GLFW JNI adapter for Android / Bionic
# Builds: liblwjgl_glfw.so  (NOT libglfw.so, NOT desktop GLFW)
# LWJGL 3.3.3 contract: org.lwjgl.glfw.GLFW loads native lib "lwjgl_glfw" via
#   System.loadLibrary("lwjgl_glfw") -> liblwjgl_glfw.so
# This adapter forwards JNI calls to Flint's own libglfw.so C ABI via dlopen().
# It MUST NOT link desktop Linux / GLIBC GLFW at build time.
cmake_minimum_required(VERSION 3.22)
project(flint_lwjgl_glfw_jni C)

add_library(lwjgl_glfw SHARED src/lwjgl_glfw_jni.c)

target_include_directories(lwjgl_glfw PRIVATE src)

# Only Bionic-safe libs. No libglfw.so in target_link_libraries on purpose:
# libglfw.so is resolved at runtime with dlopen("libglfw.so") so a wrong
# desktop .so can never be linked in by accident.
find_library(ANDROID_LIB android)
find_library(LOG_LIB log)
find_library(EGL_LIB EGL)
find_library(GLES_LIB GLESv2)
find_library(DL_LIB dl)

target_link_libraries(lwjgl_glfw PRIVATE ${ANDROID_LIB} ${LOG_LIB} ${EGL_LIB} ${GLES_LIB} ${DL_LIB})

# Android ABI: arm64-v8a is primary (itel A665L), armeabi-v7a secondary.
# -fPIC, no GLIBC, no X11, no Wayland, no desktop GLFW.
target_compile_options(lwjgl_glfw PRIVATE -fPIC -Wall -Wextra -Wno-unused-parameter -O2 -DANDROID -D__ANDROID_API__=26)
set_target_properties(lwjgl_glfw PROPERTIES
  OUTPUT_NAME "lwjgl_glfw"
  PREFIX "lib"
  SUFFIX ".so"
  C_STANDARD 11
  C_STANDARD_REQUIRED ON
)
