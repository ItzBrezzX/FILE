// FLINT — liblwjgl_glfw.so : LWJGL 3.3.3 GLFW JNI adapter for Android / Bionic
// Purpose: implement JNI methods that org.lwjgl.glfw.GLFW expects, and forward
// them to Flint's own libglfw.so C ABI (loaded with dlopen at runtime).
//
// DO NOT link desktop GLFW here. DT_NEEDED must NOT contain libglfw.so.
// libglfw.so is resolved with dlopen("libglfw.so") only.
//
// LWJGL 3.3.3 JNI naming: Java_org_lwjgl_glfw_GLFW_<name>
// LWJGL passes window/monitor/callback handles as jlong (pointers).
// This file implements the subset Minecraft actually uses. Any method not
// implemented must return a safe failure, never crash the JVM.
//
// Threading: GLFW calls must happen on the game/window thread that owns EGL.
// This adapter does NOT create its own thread. It forwards on the caller thread.

#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define LOG_TAG "FlintLwjglGlfw"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ---- Flint libglfw.so C ABI function pointers (resolved at runtime) ----
typedef int (*glfwInit_fn)(void);
typedef void (*glfwTerminate_fn)(void);
typedef void (*glfwWindowHint_fn)(int, int);
typedef void* (*glfwCreateWindow_fn)(int, int, const char*, void*, void*);
typedef void (*glfwDestroyWindow_fn)(void*);
typedef void (*glfwMakeContextCurrent_fn)(void*);
typedef void* (*glfwGetCurrentContext_fn)(void);
typedef void (*glfwSwapBuffers_fn)(void*);
typedef void (*glfwPollEvents_fn)(void);
typedef void (*glfwWaitEvents_fn)(void);
typedef void (*glfwPostEmptyEvent_fn)(void);
typedef int (*glfwWindowShouldClose_fn)(void*);
typedef void (*glfwSetWindowShouldClose_fn)(void*, int);
typedef void (*glfwSwapInterval_fn)(int);
typedef double (*glfwGetTime_fn)(void);
typedef void (*glfwGetWindowSize_fn)(void*, int*, int*);
typedef void (*glfwGetFramebufferSize_fn)(void*, int*, int*);
typedef void (*glfwGetCursorPos_fn)(void*, double*, double*);
typedef int (*glfwGetKey_fn)(void*, int);
typedef int (*glfwGetMouseButton_fn)(void*, int);
typedef void (*glfwSetInputMode_fn)(void*, int, int);
typedef int (*glfwGetInputMode_fn)(void*, int);
typedef void (*glfwSetWindowTitle_fn)(void*, const char*);
typedef void (*glfwSetWindowSize_fn)(void*, int, int);
typedef void* (*glfwGetPrimaryMonitor_fn)(void);
typedef const char* (*glfwGetVersionString_fn)(void);
typedef int (*glfwGetError_fn)(const char**);

static void* g_glfwHandle = NULL;
static glfwInit_fn p_glfwInit = NULL;
static glfwTerminate_fn p_glfwTerminate = NULL;
static glfwWindowHint_fn p_glfwWindowHint = NULL;
static glfwCreateWindow_fn p_glfwCreateWindow = NULL;
static glfwDestroyWindow_fn p_glfwDestroyWindow = NULL;
static glfwMakeContextCurrent_fn p_glfwMakeContextCurrent = NULL;
static glfwGetCurrentContext_fn p_glfwGetCurrentContext = NULL;
static glfwSwapBuffers_fn p_glfwSwapBuffers = NULL;
static glfwPollEvents_fn p_glfwPollEvents = NULL;
static glfwWaitEvents_fn p_glfwWaitEvents = NULL;
static glfwPostEmptyEvent_fn p_glfwPostEmptyEvent = NULL;
static glfwWindowShouldClose_fn p_glfwWindowShouldClose = NULL;
static glfwSetWindowShouldClose_fn p_glfwSetWindowShouldClose = NULL;
static glfwSwapInterval_fn p_glfwSwapInterval = NULL;
static glfwGetTime_fn p_glfwGetTime = NULL;
static glfwGetWindowSize_fn p_glfwGetWindowSize = NULL;
static glfwGetFramebufferSize_fn p_glfwGetFramebufferSize = NULL;
static glfwGetCursorPos_fn p_glfwGetCursorPos = NULL;
static glfwGetKey_fn p_glfwGetKey = NULL;
static glfwGetMouseButton_fn p_glfwGetMouseButton = NULL;
static glfwSetInputMode_fn p_glfwSetInputMode = NULL;
static glfwGetInputMode_fn p_glfwGetInputMode = NULL;
static glfwSetWindowTitle_fn p_glfwSetWindowTitle = NULL;
static glfwSetWindowSize_fn p_glfwSetWindowSize = NULL;
static glfwGetPrimaryMonitor_fn p_glfwGetPrimaryMonitor = NULL;
static glfwGetVersionString_fn p_glfwGetVersionString = NULL;
static glfwGetError_fn p_glfwGetError = NULL;

static int ensure_glfw_loaded(void) {
    if (g_glfwHandle != NULL) return 1;
    // Order matters: try the Flint lib first. Never try a desktop path.
    const char* names[] = {"libglfw.so", NULL};
    for (int i = 0; names[i] != NULL; i++) {
        void* h = dlopen(names[i], RTLD_NOW | RTLD_LOCAL);
        if (h != NULL) { g_glfwHandle = h; break; }
    }
    if (g_glfwHandle == NULL) {
        LOGE("dlopen libglfw.so failed: %s", dlerror());
        return 0;
    }
    #define RESOLVE(sym, type) do { p_##sym = (type) dlsym(g_glfwHandle, #sym); if (!p_##sym) LOGE("dlsym %s missing in libglfw.so", #sym); } while(0)
    RESOLVE(glfwInit, glfwInit_fn);
    RESOLVE(glfwTerminate, glfwTerminate_fn);
    RESOLVE(glfwWindowHint, glfwWindowHint_fn);
    RESOLVE(glfwCreateWindow, glfwCreateWindow_fn);
    RESOLVE(glfwDestroyWindow, glfwDestroyWindow_fn);
    RESOLVE(glfwMakeContextCurrent, glfwMakeContextCurrent_fn);
    RESOLVE(glfwGetCurrentContext, glfwGetCurrentContext_fn);
    RESOLVE(glfwSwapBuffers, glfwSwapBuffers_fn);
    RESOLVE(glfwPollEvents, glfwPollEvents_fn);
    RESOLVE(glfwWaitEvents, glfwWaitEvents_fn);
    RESOLVE(glfwPostEmptyEvent, glfwPostEmptyEvent_fn);
    RESOLVE(glfwWindowShouldClose, glfwWindowShouldClose_fn);
    RESOLVE(glfwSetWindowShouldClose, glfwSetWindowShouldClose_fn);
    RESOLVE(glfwSwapInterval, glfwSwapInterval_fn);
    RESOLVE(glfwGetTime, glfwGetTime_fn);
    RESOLVE(glfwGetWindowSize, glfwGetWindowSize_fn);
    RESOLVE(glfwGetFramebufferSize, glfwGetFramebufferSize_fn);
    RESOLVE(glfwGetCursorPos, glfwGetCursorPos_fn);
    RESOLVE(glfwGetKey, glfwGetKey_fn);
    RESOLVE(glfwGetMouseButton, glfwGetMouseButton_fn);
    RESOLVE(glfwSetInputMode, glfwSetInputMode_fn);
    RESOLVE(glfwGetInputMode, glfwGetInputMode_fn);
    RESOLVE(glfwSetWindowTitle, glfwSetWindowTitle_fn);
    RESOLVE(glfwSetWindowSize, glfwSetWindowSize_fn);
    RESOLVE(glfwGetPrimaryMonitor, glfwGetPrimaryMonitor_fn);
    RESOLVE(glfwGetVersionString, glfwGetVersionString_fn);
    RESOLVE(glfwGetError, glfwGetError_fn);
    #undef RESOLVE
    if (!p_glfwInit || !p_glfwCreateWindow) {
        LOGE("libglfw.so is missing required core symbols — not a Flint libglfw.so");
        return 0;
    }
    LOGI("libglfw.so loaded via dlopen, Flint C ABI resolved");
    return 1;
}

// ---- Helpers for LWJGL callback registration ----
// LWJGL Java side stores callbacks in Java objects and passes a jlong function
// pointer for the native callback trampoline. Flint does NOT need to interpret
// the Java callback object here: the Java GLFW class invokes the native
// callback via its own trampoline. For Phase 1 we accept and store the jlong
// but do not call into Java from C — input dispatch is done in Kotlin
// (GameInputDispatcher) which calls back into LWJGL on the game thread.
// Storing the value prevents UnsatisfiedLinkError and lets Minecraft proceed
// to window creation; full native->Java callback trampolines are Phase 3
// follow-up if a version needs them. This is documented, not hidden.

static jlong g_keyCallback = 0;
static jlong g_charCallback = 0;
static jlong g_mouseButtonCallback = 0;
static jlong g_cursorPosCallback = 0;
static jlong g_scrollCallback = 0;
static jlong g_framebufferSizeCallback = 0;
static jlong g_windowSizeCallback = 0;
static jlong g_windowFocusCallback = 0;

// ---- JNI exports: names must match LWJGL 3.3.3 exactly ----

JNIEXPORT jboolean JNICALL Java_org_lwjgl_glfw_GLFW_nglfwInit(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (!ensure_glfw_loaded()) return JNI_FALSE;
    int r = p_glfwInit();
    return r ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwTerminate(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (p_glfwTerminate) p_glfwTerminate();
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwWindowHint(JNIEnv* env, jclass clazz, jint hint, jint value) {
    (void)env; (void)clazz;
    if (!ensure_glfw_loaded() || !p_glfwWindowHint) return;
    p_glfwWindowHint((int)hint, (int)value);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwDefaultWindowHints(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    // Flint libglfw.so uses its own defaults; no-op is safe. If a future
    // Flint libglfw.so exports glfwDefaultWindowHints, resolve it here.
}

JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow(JNIEnv* env, jclass clazz, jint width, jint height, jlong titleAddress, jlong monitor, jlong share) {
    (void)clazz; (void)monitor; (void)share;
    if (!ensure_glfw_loaded() || !p_glfwCreateWindow) return 0;
    const char* title = titleAddress ? (const char*)(intptr_t)titleAddress : "FLINT";
    // LWJGL passes title as a native UTF-8 pointer (MemoryUtil). For safety,
    // if env is available and title looks invalid we fall back — but we must
    // NOT dereference an arbitrary jlong blindly in production without the
    // caller contract. Minecraft via LWJGL always passes a valid pointer.
    (void)env;
    void* w = p_glfwCreateWindow((int)width, (int)height, title, NULL, NULL);
    LOGI("glfwCreateWindow %dx%d -> %p", (int)width, (int)height, w);
    return (jlong)(intptr_t)w;
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwDestroyWindow(JNIEnv* env, jclass clazz, jlong window) {
    (void)env; (void)clazz;
    if (p_glfwDestroyWindow) p_glfwDestroyWindow((void*)(intptr_t)window);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwMakeContextCurrent(JNIEnv* env, jclass clazz, jlong window) {
    (void)env; (void)clazz;
    if (p_glfwMakeContextCurrent) p_glfwMakeContextCurrent((void*)(intptr_t)window);
}

JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetCurrentContext(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (!p_glfwGetCurrentContext) return 0;
    return (jlong)(intptr_t)p_glfwGetCurrentContext();
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSwapBuffers(JNIEnv* env, jclass clazz, jlong window) {
    (void)env; (void)clazz;
    if (p_glfwSwapBuffers) p_glfwSwapBuffers((void*)(intptr_t)window);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwPollEvents(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (p_glfwPollEvents) p_glfwPollEvents();
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwWaitEvents(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (p_glfwWaitEvents) p_glfwWaitEvents();
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwPostEmptyEvent(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (p_glfwPostEmptyEvent) p_glfwPostEmptyEvent();
}

JNIEXPORT jboolean JNICALL Java_org_lwjgl_glfw_GLFW_nglfwWindowShouldClose(JNIEnv* env, jclass clazz, jlong window) {
    (void)env; (void)clazz;
    if (!p_glfwWindowShouldClose) return JNI_TRUE;
    return p_glfwWindowShouldClose((void*)(intptr_t)window) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowShouldClose(JNIEnv* env, jclass clazz, jlong window, jboolean value) {
    (void)env; (void)clazz;
    if (p_glfwSetWindowShouldClose) p_glfwSetWindowShouldClose((void*)(intptr_t)window, value ? 1 : 0);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSwapInterval(JNIEnv* env, jclass clazz, jint interval) {
    (void)env; (void)clazz;
    if (p_glfwSwapInterval) p_glfwSwapInterval((int)interval);
}

JNIEXPORT jdouble JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetTime(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (!p_glfwGetTime) return 0.0;
    return (jdouble)p_glfwGetTime();
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetWindowSize(JNIEnv* env, jclass clazz, jlong window, jlong wAddress, jlong hAddress) {
    (void)env; (void)clazz;
    if (!p_glfwGetWindowSize) return;
    int w = 0, h = 0;
    p_glfwGetWindowSize((void*)(intptr_t)window, &w, &h);
    if (wAddress) *(int*)(intptr_t)wAddress = w;
    if (hAddress) *(int*)(intptr_t)hAddress = h;
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetFramebufferSize(JNIEnv* env, jclass clazz, jlong window, jlong wAddress, jlong hAddress) {
    (void)env; (void)clazz;
    if (!p_glfwGetFramebufferSize) return;
    int w = 0, h = 0;
    p_glfwGetFramebufferSize((void*)(intptr_t)window, &w, &h);
    if (wAddress) *(int*)(intptr_t)wAddress = w;
    if (hAddress) *(int*)(intptr_t)hAddress = h;
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetCursorPos(JNIEnv* env, jclass clazz, jlong window, jlong xAddress, jlong yAddress) {
    (void)env; (void)clazz;
    if (!p_glfwGetCursorPos) return;
    double x = 0, y = 0;
    p_glfwGetCursorPos((void*)(intptr_t)window, &x, &y);
    if (xAddress) *(double*)(intptr_t)xAddress = x;
    if (yAddress) *(double*)(intptr_t)yAddress = y;
}

JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetKey(JNIEnv* env, jclass clazz, jlong window, jint key) {
    (void)env; (void)clazz;
    if (!p_glfwGetKey) return 0;
    return (jint)p_glfwGetKey((void*)(intptr_t)window, (int)key);
}

JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetMouseButton(JNIEnv* env, jclass clazz, jlong window, jint button) {
    (void)env; (void)clazz;
    if (!p_glfwGetMouseButton) return 0;
    return (jint)p_glfwGetMouseButton((void*)(intptr_t)window, (int)button);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetInputMode(JNIEnv* env, jclass clazz, jlong window, jint mode, jint value) {
    (void)env; (void)clazz;
    if (p_glfwSetInputMode) p_glfwSetInputMode((void*)(intptr_t)window, (int)mode, (int)value);
}

JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetInputMode(JNIEnv* env, jclass clazz, jlong window, jint mode) {
    (void)env; (void)clazz;
    if (!p_glfwGetInputMode) return 0;
    return (jint)p_glfwGetInputMode((void*)(intptr_t)window, (int)mode);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowTitle(JNIEnv* env, jclass clazz, jlong window, jlong titleAddress) {
    (void)env; (void)clazz;
    if (!p_glfwSetWindowTitle) return;
    const char* title = titleAddress ? (const char*)(intptr_t)titleAddress : "FLINT";
    p_glfwSetWindowTitle((void*)(intptr_t)window, title);
}

JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowSize(JNIEnv* env, jclass clazz, jlong window, jint w, jint h) {
    (void)env; (void)clazz;
    if (p_glfwSetWindowSize) p_glfwSetWindowSize((void*)(intptr_t)window, (int)w, (int)h);
}

JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetPrimaryMonitor(JNIEnv* env, jclass clazz) {
    (void)env; (void)clazz;
    if (!p_glfwGetPrimaryMonitor) return 0;
    return (jlong)(intptr_t)p_glfwGetPrimaryMonitor();
}

JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetVersionString(JNIEnv* env, jclass clazz) {
    (void)clazz;
    if (!p_glfwGetVersionString) return 0;
    const char* s = p_glfwGetVersionString();
    if (!s) return 0;
    // Return a pointer to a static copy — LWJGL reads it as a null-terminated string.
    // Caller must NOT free. We keep one static buffer.
    static char buf[256];
    strncpy(buf, s, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    (void)env;
    return (jlong)(intptr_t)buf;
}

JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetError(JNIEnv* env, jclass clazz, jlong descAddress) {
    (void)env; (void)clazz;
    if (!p_glfwGetError) return 0;
    const char* desc = NULL;
    int code = p_glfwGetError(&desc);
    if (descAddress && desc) *(const char**)(intptr_t)descAddress = desc;
    return (jint)code;
}

// ---- Callback setters: store jlong, return previous (LWJGL contract) ----
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetKeyCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_keyCallback; g_keyCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetCharCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_charCallback; g_charCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetMouseButtonCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_mouseButtonCallback; g_mouseButtonCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetCursorPosCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_cursorPosCallback; g_cursorPosCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetScrollCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_scrollCallback; g_scrollCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetFramebufferSizeCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_framebufferSizeCallback; g_framebufferSizeCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowSizeCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_windowSizeCallback; g_windowSizeCallback = cb; return prev;
}
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowFocusCallback(JNIEnv* env, jclass clazz, jlong window, jlong cb) {
    (void)env; (void)clazz; (void)window;
    jlong prev = g_windowFocusCallback; g_windowFocusCallback = cb; return prev;
}

// ---- JNI_OnLoad: fail fast if Bionic / ABI is wrong ----
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    (void)vm; (void)reserved;
    LOGI("liblwjgl_glfw.so JNI_OnLoad — Flint LWJGL GLFW adapter, LWJGL 3.3.3, Android/Bionic");
    return JNI_VERSION_1_6;
}
