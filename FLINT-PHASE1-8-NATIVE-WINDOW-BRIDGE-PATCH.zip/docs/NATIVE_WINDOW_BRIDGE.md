# Native Window Bridge — Phase 1-8 (feature/flint-native-window-bridge)

Commit audit: `104093663cb8b798089d457921b49fbeb59a22a0` (branch `feature/flint-native-window-bridge`, NOT main)

## Contradiction resolved (Phase 8)
Sebelumnya docs saling bertentangan: ada yang bilang "LWJGL natives sudah di-build + di-packaging", ada yang bilang belum.
Yang benar:
- SUDAH di-build + di-packaging SEBELUM patch ini: `liblwjgl.so`, `liblwjgl_opengl.so`, `libglfw.so` (Flint C ABI), `libGL.so` (GL4ES)
- BELUM di-build sebelum patch ini: `liblwjgl_glfw.so` (LWJGL GLFW JNI adapter). Inilah yang bikin `org.lwjgl.glfw.GLFW` gagal load walau `libglfw.so` ada.
- Patch ini MENAMBAH `liblwjgl_glfw.so` (native/lwjgl-glfw-jni/) + installer/verifier-nya. Tidak menghapus yang lama.

## LWJGL 3.3.3 (Minecraft 1.21.x) — jangan samakan
| File | Peran | Di-load oleh |
|---|---|---|
| `liblwjgl.so` | LWJGL core JNI | `System.loadLibrary("lwjgl")` |
| `liblwjgl_opengl.so` | LWJGL OpenGL JNI | `System.loadLibrary("lwjgl_opengl")` |
| `liblwjgl_glfw.so` | LWJGL GLFW JNI adapter (BARU) | `System.loadLibrary("lwjgl_glfw")` |
| `libglfw.so` | Flint C ABI (glfwInit, glfwCreateWindow...) | `dlopen("libglfw.so")` dari adapter, BUKAN dari Java |
| `libGL.so` | GL4ES | EGL / GLFW backend |

`libGL.so` ada ≠ renderer tersedia. Bukti renderer tersedia = EGL ready + GLFW init + GL4ES init + frame ter-swap lewat jalur LWJGL.

## Production surface (Phase 2)
`GameActivity` + `GameSurfaceManager` adalah production surface. `GL4ESSurfaceView` + `RendererTestActivity` tetap preview, tidak diklaim sebagai game.
EGL dimiliki SATU thread (game thread). Surface di-attach SEBELUM `glfwInit`.

## PLAY pipeline (Phase 4)
`PlayLaunchPipeline` adalah wrapper additive. `PlayLaunchCoordinator` / `PojavStyleGameLauncher` / dll tetap dipakai di dalam pipeline.
State baru: PreparingRuntime → PreparingNatives → WaitingForSurface → InitializingEGL → InitializingLWJGL → InitializingGLFW → InitializingGL4ES → StartingMinecraft → MinecraftInitialized / Failed.
`Started` (thread jalan) ≠ `MinecraftInitialized` (title screen milestone terbukti).

## JVM (Phase 5)
`JliLifecycle.verifyJre()` cek `libjli.so` + `libjvm.so` dari JRE dir. `JLI_Launch` harus dipanggil di game thread, bukan UI thread.
`GameStopController` adalah stop yang beneran: minta stop → `glfwSetWindowShouldClose` → join thread → release EGL → detach JNI.
`launchMinecraftPlaceholder()` di patch ini return `-9999 NOT_STARTED` sampai wiring `PojavStyleGameLauncher.launch()` yang asli disambung — tidak memalsukan sukses.

## Device target
itel A665L, Android 13, ABI prioritas `arm64-v8a` (deteksi dari `Build.SUPPORTED_ABIS`, bukan asumsi).
Device test di patch ini: BLOCKED / NOT TESTED (tidak ada device di lingkungan ini). Lihat `docs/PHASE1-8_STATUS.md`.
