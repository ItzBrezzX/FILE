# Phase 1-8 — Honest Status

Branch: `feature/flint-native-window-bridge`
Commit audit: `104093663cb8b798089d457921b49fbeb59a22a0`
Izin Mojang: Sudah — Client.jar boleh, offline boleh, Microsoft boleh.

| # | Item | Status |
|---|---|---|
| 1 | LWJGL GLFW JNI adapter `liblwjgl_glfw.so` source (CMake + C + Kotlin verifier) | SOURCE DONE / NOT TESTED on device |
| 2 | Production game surface + EGL ownership (`GameActivity` + `GameSurfaceManager`) | SOURCE DONE / NOT TESTED on device |
| 3 | Real input → LWJGL event loop (`GameInputDispatcher`) | SOURCE DONE / NOT TESTED on device |
| 4 | PLAY → real pipeline (`PlayLaunchPipeline` + states) | SOURCE DONE — JLI wiring placeholder returns -9999, NOT claimed as working |
| 5 | JVM embedding + lifecycle (`JliLifecycle` + `GameStopController`) | SOURCE DONE / NOT TESTED |
| 6 | Integration tests (unit + on-device stub + ELF verify scripts) | SOURCE DONE / CI NOT RUN |
| 7 | Device itel A665L Android 13 — title screen + world + input | BLOCKED / NOT TESTED |
| 8 | Docs + branch hygiene (no merge to main) | DONE in patch |

## Final acceptance (harus semua lolos baru COMPLETE)
1. LWJGL JNI modules load on Android — NOT TESTED
2. Minecraft dapat production window + EGL — NOT TESTED
3. PLAY mulai Minecraft asli — NOT TESTED (placeholder -9999)
4. Minecraft title screen — NOT TESTED
5. Single-player world load — NOT TESTED
6. Touch/keyboard di world — NOT TESTED
7. Exit bersih tanpa EGL/JVM rusak — NOT TESTED
8. CI + regression green — NOT RUN

## Yang TIDAK diklaim di patch ini
- Commit SHA baru: TIDAK ADA (SHA di atas adalah audit lu)
- CI run URL: TIDAK ADA (CI belum jalan)
- APK artifact URL: TIDAK ADA (APK belum di-build dari patch ini)
- Logcat: TIDAK ADA (tidak difabrikasi)
- Minecraft playable: TIDAK DIKLAIM

## File yang berubah (patch additive, tidak ada delete fitur lama)
- native/lwjgl-glfw-jni/CMakeLists.txt, src/lwjgl_glfw_jni.c, README.md (BARU)
- app/src/main/java/com/flintclient/lwjgl/LwjglNativesContract.kt, LwjglGlfwAdapter.kt (BARU)
- app/src/main/java/com/flintclient/game/GameSurfaceManager.kt, GameActivity.kt (BARU)
- app/src/main/java/com/flintclient/input/GameInputDispatcher.kt (BARU)
- app/src/main/java/com/flintclient/launch/GameLaunchState.kt, PlayLaunchPipeline.kt (BARU)
- app/src/main/java/com/flintclient/jvm/JliLifecycle.kt (BARU, berisi JliLifecycle + GameStopController)
- app/src/test/... LwjglGlfwAdapterTest, GameInputDispatcherTest, GameLaunchStateTest (BARU)
- app/src/androidTest/... LwjglGlfwOnDeviceTest (BARU, stub — BLOCKED sampai device)
- scripts/verify_lwjgl_glfw.py, verify_apk_natives.sh (BARU)
- github-workflow-flint-native-window-bridge.yml (pindah ke .github/workflows/ di repo) (BARU, additive — workflow lama tidak dihapus)
- docs/NATIVE_WINDOW_BRIDGE.md, docs/PHASE1-8_STATUS.md, PATCH_NOTES.md (BARU / update docs)

## Cara test di device (itel A665L, Android 13)
1. Apply patch di branch `feature/flint-native-window-bridge`, push, tunggu CI hijau.
2. Download APK artifact dari CI run itu (jangan pakai APK lama).
3. Install di itel A665L, login dengan akun Microsoft / offline sesuai izin lu, pilih instalasi vanilla 1.21.1, Java 21.
4. Tekan PLAY. Catat: state di log, apakah sampai `MinecraftInitialized`, apakah title screen muncul.
5. Buat world single-player, gerak pakai touch + keyboard, cek input sampai ke game.
6. Tekan Back / Stop, cek EGL + JVM tidak rusak, buka lagi PLAY.
7. Kirim logcat + hasil tiap langkah. Tanpa itu, status tetap BLOCKED.
