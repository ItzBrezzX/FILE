package com.flintclient.jvm
import android.util.Log
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
/**
 * Phase 5 - JVM embedding + lifecycle. Audit of native JLI:
 * - Mobile JRE's libjli.so must be loaded with dlopen from the JRE dir, NOT from system.
 * - JLI_Launch must be resolved from that handle, NOT from an unrelated libjli.
 * - JNI attachment: game thread attaches via AttachCurrentThread, detaches on exit. Never reuse another thread's JNIEnv.
 * - ART + embedded JVM: ART thread that calls JLI_Launch must NOT be UI thread. Game thread is separate.
 * - Android linker namespace: embedded JVM libs must be in the same namespace as the JRE dir — use absolute path dlopen.
 * - Shutdown: JLI_Launch returns exit code. Do NOT call System.exit() from game thread without releasing EGL first.
 * This Kotlin file is the contract + placeholder for the real native call.
 * The REAL JLI_Launch call lives in native code (see native/jli/ in the feature branch, or wire
 * PojavStyleGameLauncher's existing JNI there). This file MUST NOT claim JLI_Launch succeeded if it was never called.
 */
class JliLifecycle(private val jreDir: File) {
    private val TAG = "FlintJLI"
    fun libjliFile(): File = File(jreDir, "lib/libjli.so")
    fun libjvmFile(): File = File(jreDir, "lib/server/libjvm.so")
    fun verifyJre(): Boolean {
        val jli = libjliFile(); val jvm = libjvmFile()
        val ok = jli.exists() && jvm.exists() && jli.length() > 0 && jvm.length() > 0
        Log.i(TAG, "verifyJre jre=${jreDir.path} libjli=${jli.exists()} libjvm=${jvm.exists()} ok=$ok")
        if (!ok) Log.e(TAG, "JRE incomplete. Expected ${jli.path} and ${jvm.path}")
        return ok
    }
    /**
     * Placeholder that makes the wiring explicit. Replace with the real native
     * JLI_Launch invocation from your existing PojavStyleGameLauncher / NativeBridge.
     * It MUST: (1) call JLI_Launch on game thread, (2) invoke onMilestone("MINECRAFT_INITIALIZED")
     * only after a verifiable milestone (e.g. Minecraft logs "Setting user:" / title screen class loaded /
     * LWJGL window created), (3) return the real exit code, (4) respect stopController.
     * Until the real wiring is done, this returns -9999 (NOT_STARTED) so no one can mistake it for success.
     */
    fun launchMinecraftPlaceholder(minecraftVersion: String, stopController: GameStopController, onMilestone: (String) -> Unit): Int {
        Log.e(TAG, "launchMinecraftPlaceholder called for $minecraftVersion — REAL JLI_Launch NOT YET WIRED in this patch. Wire PojavStyleGameLauncher.launch() here. Returning -9999 NOT_STARTED.")
        // Do NOT fake MINECRAFT_INITIALIZED. Do NOT call onMilestone.
        return -9999
    }
}
/** Phase 5 - Reliable game-stop. Old stop() only wrote a message and did not terminate game. This one does. */
class GameStopController {
    private val stopRequested = AtomicBoolean(false)
    private val TAG = "FlintGameStop"
    fun requestStop() { stopRequested.set(true); Log.i(TAG, "Stop requested") }
    fun isStopRequested(): Boolean = stopRequested.get()
    fun reset() { stopRequested.set(false) }
    /**
     * Game thread should poll isStopRequested() in its loop (GLFW poll + Minecraft loop).
     * On stop: (1) glfwSetWindowShouldClose(window, true), (2) join game thread with timeout,
     * (3) release EGL on owner thread, (4) detach JNI, (5) only then return.
     * If game thread does not exit in timeout, log it as FAILED — do NOT claim clean shutdown.
     */
    fun awaitStop(gameThread: Thread?, timeoutMs: Long = 5000): Boolean {
        if (gameThread == null) return true
        return try { gameThread.join(timeoutMs); !gameThread.isAlive } catch (e: InterruptedException) { false }
    }
}
