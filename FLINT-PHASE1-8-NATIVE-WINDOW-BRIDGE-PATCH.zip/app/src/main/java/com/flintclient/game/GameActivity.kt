package com.flintclient.game
import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import com.flintclient.launch.PlayLaunchPipeline
import java.util.concurrent.atomic.AtomicBoolean
/**
 * Phase 2 + 4 - Production game Activity. NOT RendererTestActivity, NOT preview.
 * surfaceCreated -> GameSurfaceManager -> game thread starts pipeline. Never UI thread.
 */
class GameActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var surfaceView: SurfaceView
    private lateinit var surfaceManager: GameSurfaceManager
    private lateinit var pipeline: PlayLaunchPipeline
    private val gameStarted = AtomicBoolean(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        surfaceManager = GameSurfaceManager()
        pipeline = PlayLaunchPipeline(this, surfaceManager)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        setContentView(surfaceView)
        Log.i("FlintGameActivity", "GameActivity created - waiting for Surface")
    }
    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceManager.onSurfaceCreated(holder.surface, surfaceView.width, surfaceView.height)
        if (gameStarted.compareAndSet(false, true)) {
            Thread({ pipeline.startFromIntent(intent) }, "Flint-Game-Thread").start()
        }
    }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfaceManager.onSurfaceChanged(width, height); pipeline.onSurfaceChanged(width, height)
    }
    override fun surfaceDestroyed(holder: SurfaceHolder) { surfaceManager.onSurfaceDestroyed(); pipeline.onSurfaceDestroyed() }
    override fun onPause() { super.onPause(); pipeline.onPause() }
    override fun onResume() { super.onResume(); pipeline.onResume() }
    override fun onDestroy() { pipeline.requestStop(); super.onDestroy() }
}
