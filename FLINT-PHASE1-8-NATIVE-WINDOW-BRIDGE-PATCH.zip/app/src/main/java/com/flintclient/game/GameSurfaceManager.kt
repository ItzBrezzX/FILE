package com.flintclient.game
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.util.Log
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
/**
 * Phase 2 - Production game surface + EGL ownership. NOT preview.
 * Rules: exactly ONE owner thread owns EGL at a time (game thread).
 * Surface attach MUST happen BEFORE Minecraft initializes GLFW.
 * Release is explicit. No use-after-destroy.
 */
class GameSurfaceManager {
    enum class State { IDLE, WAITING_SURFACE, SURFACE_READY, EGL_READY, EGL_FAILED, RELEASED, DESTROYED }
    @Volatile var state: State = State.IDLE; private set
    private val surfaceRef = AtomicReference<Surface?>(null)
    private val surfaceReadyLatch = CountDownLatch(1)
    private val eglReadyLatch = CountDownLatch(1)
    @Volatile private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    @Volatile private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    @Volatile private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    @Volatile private var ownerThread: Thread? = null
    private val eglOwned = AtomicBoolean(false)
    private val released = AtomicBoolean(false)
    @Volatile var surfaceWidth: Int = 0; private set
    @Volatile var surfaceHeight: Int = 0; private set
    fun onSurfaceCreated(surface: Surface, width: Int, height: Int) {
        if (released.get()) return
        surfaceRef.set(surface); surfaceWidth = width; surfaceHeight = height
        state = State.SURFACE_READY; surfaceReadyLatch.countDown()
        Log.i("FlintGameSurface", "Surface ready ${width}x$height")
    }
    fun onSurfaceChanged(width: Int, height: Int) { surfaceWidth = width; surfaceHeight = height; Log.i("FlintGameSurface", "Surface changed ${width}x$height state=$state") }
    fun onSurfaceDestroyed() { surfaceRef.set(null); state = State.DESTROYED; Log.i("FlintGameSurface", "Surface destroyed - owner thread will release EGL") }
    fun awaitSurface(timeoutMs: Long = 15000): Boolean {
        state = State.WAITING_SURFACE
        val ok = surfaceReadyLatch.await(timeoutMs, TimeUnit.MILLISECONDS)
        if (!ok) { state = State.EGL_FAILED; return false }
        return surfaceRef.get() != null
    }
    fun initEglOnOwnerThread(): Boolean {
        if (eglOwned.get()) return true
        val surface = surfaceRef.get() ?: run { state = State.EGL_FAILED; return false }
        ownerThread = Thread.currentThread()
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) { state = State.EGL_FAILED; return false }
        val version = IntArray(2)
        if (!EGL14.eglInitialize(display, version, 0, version, 1)) { state = State.EGL_FAILED; return false }
        val attribList = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_STENCIL_SIZE, 0, EGL14.EGL_NONE)
        val configs = arrayOfNulls<EGLConfig>(1); val numConfigs = IntArray(1)
        if (!EGL14.eglChooseConfig(display, attribList, 0, configs, 0, 1, numConfigs, 0) || numConfigs[0] == 0) { state = State.EGL_FAILED; return false }
        val config = configs[0]!!
        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        val ctx = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
        if (ctx == EGL14.EGL_NO_CONTEXT) { state = State.EGL_FAILED; return false }
        val eglSurf = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
        if (eglSurf == EGL14.EGL_NO_SURFACE) { EGL14.eglDestroyContext(display, ctx); state = State.EGL_FAILED; return false }
        if (!EGL14.eglMakeCurrent(display, eglSurf, eglSurf, ctx)) { EGL14.eglDestroySurface(display, eglSurf); EGL14.eglDestroyContext(display, ctx); state = State.EGL_FAILED; Log.e("FlintGameSurface", "eglMakeCurrent failed ${EGL14.eglGetError()} - wrong owner thread"); return false }
        eglDisplay = display; eglSurface = eglSurf; eglContext = ctx; eglOwned.set(true); state = State.EGL_READY; eglReadyLatch.countDown()
        Log.i("FlintGameSurface", "EGL ready on ${Thread.currentThread().name}")
        return true
    }
    fun swapBuffersOnOwnerThread(): Boolean {
        if (!eglOwned.get() || Thread.currentThread() != ownerThread) return false
        return EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }
    fun releaseEglOnOwnerThread() {
        if (!eglOwned.get()) return
        if (Thread.currentThread() != ownerThread) { Log.e("FlintGameSurface", "releaseEgl from non-owner - must be owner"); return }
        try {
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(eglDisplay, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglTerminate(eglDisplay)
        } catch (e: Throwable) { Log.e("FlintGameSurface", "releaseEgl error ${e.message}", e) }
        eglDisplay = EGL14.EGL_NO_DISPLAY; eglSurface = EGL14.EGL_NO_SURFACE; eglContext = EGL14.EGL_NO_CONTEXT
        eglOwned.set(false); ownerThread = null; released.set(true); state = State.RELEASED
    }
    fun awaitEgl(timeoutMs: Long = 10000): Boolean = eglReadyLatch.await(timeoutMs, TimeUnit.MILLISECONDS)
    fun isEglReady(): Boolean = state == State.EGL_READY && eglOwned.get()
}
