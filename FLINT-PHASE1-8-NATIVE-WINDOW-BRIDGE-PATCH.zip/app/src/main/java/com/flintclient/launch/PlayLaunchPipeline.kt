package com.flintclient.launch
import android.content.Context
import android.content.Intent
import android.util.Log
import com.flintclient.game.GameSurfaceManager
import com.flintclient.input.GameInputDispatcher
import com.flintclient.jvm.GameStopController
import com.flintclient.jvm.JliLifecycle
import com.flintclient.lwjgl.LwjglGlfwAdapter
import java.io.File
/**
 * Phase 4 - End-to-end PLAY pipeline. Additive wrapper, does NOT replace
 * PlayLaunchCoordinator / PojavStyleGameLauncher / MobileJreManager /
 * AndroidLwjglNativesInstaller / LaunchCommandBuilder / NativeBridge / FlintApplication / HomeViewModel.
 * Those existing classes are CALLED from here at the steps where they belong.
 * If your existing class names differ slightly, wire them in the TODO markers — do not duplicate their logic here.
 * Pipeline order (must stay in this order):
 * 1 validate installation -> 2 validate account/auth -> 3 validate Java version -> 4 select JRE
 * 5 verify JRE + libjli.so -> 6 classpath + args -> 7 extract resources/natives -> 8 stage LWJGL/GLFW/GL4ES
 * 9 create surface (already done by GameActivity) -> 10 init EGL on owner thread -> 11 load LWJGL modules
 * 12 init GLFW with Android Surface -> 13 init GL4ES -> 14 launch Minecraft main -> 15 render -> 16 dispatch input
 * 17 logs/exit codes -> 18 clean shutdown.
 */
class PlayLaunchPipeline(private val context: Context, private val surfaceManager: GameSurfaceManager) {
    private val TAG = "FlintPlayPipeline"
    @Volatile var state: GameLaunchState = GameLaunchState.IDLE; private set
    var listener: GameLaunchListener? = null
    val inputDispatcher = GameInputDispatcher()
    val stopController = GameStopController()
    @Volatile private var gameThread: Thread? = null
    private fun setState(s: GameLaunchState, detail: String = "") { state = s; Log.i(TAG, "$s $detail"); listener?.onState(s, detail) }
    private fun fail(s: GameLaunchState, msg: String, e: Throwable? = null, exitCode: Int? = null): Boolean {
        setState(GameLaunchState.FAILED, msg); listener?.onFailure(GameLaunchFailure(s, msg, e, exitCode)); return false
    }
    fun startFromIntent(intent: Intent) {
        // Intent extras are read here. Existing HomeViewModel / PlayLaunchCoordinator already
        // validate installation + account — we re-validate defensively, we do not trust UI alone.
        val installationId = intent.getStringExtra("installation_id") ?: "default"
        val minecraftVersion = intent.getStringExtra("minecraft_version") ?: "1.21.1"
        val javaVersion = intent.getIntExtra("java_version", 21)
        start(installationId, minecraftVersion, javaVersion)
    }
    fun start(installationId: String, minecraftVersion: String, javaVersion: Int) {
        if (gameThread?.isAlive == true) { Log.w(TAG, "start called twice - ignored"); return }
        gameThread = Thread({ runPipeline(installationId, minecraftVersion, javaVersion) }, "Flint-Game-Thread")
        gameThread?.start()
    }
    private fun runPipeline(installationId: String, minecraftVersion: String, javaVersion: Int) {
        try {
            setState(GameLaunchState.PREPARING_RUNTIME, "install=$installationId mc=$minecraftVersion java=$javaVersion")
            // 1-3: TODO wire to existing PlayLaunchCoordinator.validateInstallation + auth check + JavaVersionMapper
            // If any of those return false in your codebase, call fail() here. Do NOT proceed.
            // 4-5: JRE selection + verification
            val jreDir = File(context.filesDir, "runtime/java-$javaVersion")
            val jli = JliLifecycle(jreDir)
            if (!jli.verifyJre()) { fail(GameLaunchState.PREPARING_RUNTIME, "JRE verification failed: ${jreDir.path} missing libjli.so / libjvm.so"); return }
            setState(GameLaunchState.PREPARING_NATIVES, "Staging LWJGL/GLFW/GL4ES")
            // 6-7: TODO wire to LaunchCommandBuilder (classpath + args) + resource extraction.
            // 8: Stage natives — FIRST existing AndroidLwjglNativesInstaller, THEN adapter
            val nativesDir = File(context.filesDir, "game/natives")
            nativesDir.mkdirs()
            // TODO: AndroidLwjglNativesInstaller.install(context, nativesDir, minecraftVersion) // existing, keep it
            val staged = LwjglGlfwAdapter.stageAdapter(context, nativesDir)
            if (staged == null) { fail(GameLaunchState.PREPARING_NATIVES, "liblwjgl_glfw.so not in APK native libs. Check APK packaging for ABI ${LwjglGlfwAdapter.detectAbi()}"); return }
            val verify = LwjglGlfwAdapter.verifyStaged(nativesDir)
            if (!verify.ok) { fail(GameLaunchState.PREPARING_NATIVES, "Missing natives: ${verify.missingLibs}"); return }
            // 9-10: Surface + EGL — surface was created by GameActivity, now wait + init on THIS thread (owner)
            setState(GameLaunchState.WAITING_FOR_SURFACE, "Waiting for production Surface")
            if (!surfaceManager.awaitSurface()) { fail(GameLaunchState.WAITING_FOR_SURFACE, "Timeout waiting for game Surface"); return }
            setState(GameLaunchState.INITIALIZING_EGL, "EGL on owner thread ${Thread.currentThread().name}")
            if (!surfaceManager.initEglOnOwnerThread()) { fail(GameLaunchState.INITIALIZING_EGL, "EGL init failed. Check logcat for EGL_BAD_ACCESS / wrong thread"); return }
            // 11: Load LWJGL modules on game thread
            setState(GameLaunchState.INITIALIZING_LWJGL, "Loading liblwjgl + liblwjgl_opengl + liblwjgl_glfw")
            if (!LwjglGlfwAdapter.tryLoadCore()) { fail(GameLaunchState.INITIALIZING_LWJGL, "Failed to load liblwjgl / liblwjgl_opengl"); return }
            if (!LwjglGlfwAdapter.tryLoadAdapter()) { fail(GameLaunchState.INITIALIZING_LWJGL, "Failed to load liblwjgl_glfw.so JNI adapter. See Phase 1 verification."); return }
            // 12-13: GLFW + GL4ES — GLFW init must happen AFTER EGL + Surface. GL4ES init after GLFW.
            setState(GameLaunchState.INITIALIZING_GLFW, "GLFW init with Android Surface")
            // TODO: call existing NativeBridge / Flint GLFW backend init here (do not re-implement GLFW in this file)
            // TODO: call existing RendererManager / MobileGLUESManager / GL4ES init here. Do NOT use libGL.so existence as proof.
            setState(GameLaunchState.INITIALIZING_GL4ES, "GL4ES init")
            // 14: Launch Minecraft main via embedded JVM (JLI_Launch) — NOT just starting a thread and claiming success.
            setState(GameLaunchState.STARTING_MINECRAFT, "Launching Minecraft $minecraftVersion via JLI_Launch")
            // TODO: wire to existing PojavStyleGameLauncher.launch(...) which calls JliLifecycle.launch(...)
            // The launch call must block here on game thread until Minecraft exits or stop is requested.
            // It must report a verifiable milestone (see below) — not just thread start.
            val exitCode = jli.launchMinecraftPlaceholder(minecraftVersion, stopController) { milestone ->
                if (milestone == "MINECRAFT_INITIALIZED") {
                    setState(GameLaunchState.MINECRAFT_INITIALIZED, "Minecraft title screen milestone reached")
                    listener?.onMinecraftInitialized()
                }
            }
            Log.i(TAG, "Minecraft exited code=$exitCode")
            // 17-18: logs + clean shutdown
            surfaceManager.releaseEglOnOwnerThread()
            setState(GameLaunchState.STOPPED, "exit=$exitCode")
        } catch (e: Throwable) {
            fail(GameLaunchState.FAILED, "Pipeline crashed: ${e.message}", e)
        }
    }
    fun onSurfaceChanged(w: Int, h: Int) { inputDispatcher.enqueue(GameInputDispatcher.InputEvent.Resize(w, h)) }
    fun onSurfaceDestroyed() { inputDispatcher.handleFocusLoss() }
    fun onPause() { inputDispatcher.enqueue(GameInputDispatcher.InputEvent.Focus(false)) }
    fun onResume() { inputDispatcher.enqueue(GameInputDispatcher.InputEvent.Focus(true)) }
    fun requestStop() { stopController.requestStop(); inputDispatcher.releaseAllOnStop(null); gameThread?.join(5000) }
}
