package com.flintclient.launch
/**
 * Phase 4 - Meaningful startup states. LaunchResult.Started (worker thread started)
 * MUST NOT be displayed as proof Minecraft launched. Only MinecraftInitialized counts.
 */
enum class GameLaunchState {
    IDLE, PREPARING_RUNTIME, PREPARING_NATIVES, WAITING_FOR_SURFACE, INITIALIZING_EGL,
    INITIALIZING_LWJGL, INITIALIZING_GLFW, INITIALIZING_GL4ES, STARTING_MINECRAFT,
    MINECRAFT_INITIALIZED, FAILED, STOPPED
}
data class GameLaunchFailure(val state: GameLaunchState, val message: String, val throwable: Throwable? = null, val exitCode: Int? = null)
interface GameLaunchListener {
    fun onState(state: GameLaunchState, detail: String = "")
    fun onFailure(failure: GameLaunchFailure)
    fun onMinecraftInitialized()
}
