package com.flintclient.lwjgl

/**
 * Phase 1 — LWJGL natives contract. DO NOT confuse names.
 *
 * - liblwjgl.so           : LWJGL core JNI (org.lwjgl)
 * - liblwjgl_opengl.so    : LWJGL OpenGL JNI (org.lwjgl.opengl.GL)
 * - liblwjgl_glfw.so      : LWJGL GLFW JNI adapter (org.lwjgl.glfw.GLFW) — NEW in this patch, built from native/lwjgl-glfw-jni/
 * - libglfw.so            : Flint C ABI implementation of GLFW (glfwInit, glfwCreateWindow, ...). NOT a JNI lib.
 * - libGL.so              : GL4ES / GL translation. Presence alone does NOT prove renderer works.
 * - libopenal.so          : OpenAL (audio) — staged separately if present, not required for title screen.
 *
 * LWJGL 3.3.3 (Minecraft 1.21.x) loads:
 *   System.loadLibrary("lwjgl")         -> liblwjgl.so
 *   System.loadLibrary("lwjgl_opengl")  -> liblwjgl_opengl.so
 *   System.loadLibrary("lwjgl_glfw")    -> liblwjgl_glfw.so
 *
 * Do NOT assume one native build supports every Minecraft version.
 * For LWJGL 3.4.x / Minecraft 26.x, re-audit this list.
 */
object LwjglNativesContract {
    const val LWJGL_VERSION = "3.3.3"
    const val MINECRAFT_121X = "1.21.x"

    // Required for title screen. If any is missing -> Failed, not Started.
    val REQUIRED_LIBS = listOf(
        "liblwjgl.so",
        "liblwjgl_opengl.so",
        "liblwjgl_glfw.so",
        "libglfw.so",
        "libGL.so"
    )

    // Expected DT_NEEDED for liblwjgl_glfw.so — must NOT contain libglfw.so (dlopen only) and must NOT contain GLIBC / X11 / desktop GLFW.
    val FORBIDDEN_DT_NEEDED = listOf("libglfw.so", "libX11.so", "libwayland-client.so", "libc.so.6")

    // JNI symbols that MUST be exported by liblwjgl_glfw.so
    val REQUIRED_JNI_SYMBOLS = listOf(
        "Java_org_lwjgl_glfw_GLFW_nglfwInit",
        "Java_org_lwjgl_glfw_GLFW_nglfwTerminate",
        "Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow",
        "Java_org_lwjgl_glfw_GLFW_nglfwDestroyWindow",
        "Java_org_lwjgl_glfw_GLFW_nglfwMakeContextCurrent",
        "Java_org_lwjgl_glfw_GLFW_nglfwSwapBuffers",
        "Java_org_lwjgl_glfw_GLFW_nglfwPollEvents",
        "Java_org_lwjgl_glfw_GLFW_nglfwWindowShouldClose",
        "Java_org_lwjgl_glfw_GLFW_nglfwSetKeyCallback",
        "Java_org_lwjgl_glfw_GLFW_nglfwSetCharCallback",
        "Java_org_lwjgl_glfw_GLFW_nglfwSetMouseButtonCallback",
        "Java_org_lwjgl_glfw_GLFW_nglfwSetFramebufferSizeCallback"
    )

    // C ABI symbols that MUST be exported by Flint libglfw.so (separate verification)
    val REQUIRED_GLFW_C_ABI = listOf(
        "glfwInit", "glfwTerminate", "glfwCreateWindow", "glfwDestroyWindow",
        "glfwMakeContextCurrent", "glfwSwapBuffers", "glfwPollEvents",
        "glfwWindowShouldClose", "glfwGetFramebufferSize", "glfwGetWindowSize"
    )
}
