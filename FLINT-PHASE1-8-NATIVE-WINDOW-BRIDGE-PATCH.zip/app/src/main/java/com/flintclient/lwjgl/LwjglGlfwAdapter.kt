package com.flintclient.lwjgl

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File

/**
 * Phase 1 + Phase 4 — Additive installer / verifier for liblwjgl_glfw.so.
 *
 * This does NOT replace AndroidLwjglNativesInstaller. It is called AFTER it.
 * Existing installer stages: liblwjgl.so, liblwjgl_opengl.so, libglfw.so, libGL.so
 * This installer adds: liblwjgl_glfw.so  (and verifies the full set).
 *
 * Packaging: liblwjgl_glfw.so must be in APK under lib/<abi>/liblwjgl_glfw.so
 * for the device ABI. Detect actual ABI, do not assume.
 */
object LwjglGlfwAdapter {
    private const val TAG = "FlintLwjglGlfw"

    data class VerificationResult(
        val ok: Boolean,
        val abi: String,
        val missingLibs: List<String>,
        val details: String
    )

    fun detectAbi(): String {
        val abis = Build.SUPPORTED_ABIS?.toList() ?: emptyList()
        // itel A665L Android 13 is arm64-v8a. Prefer it if present.
        return when {
            "arm64-v8a" in abis -> "arm64-v8a"
            "armeabi-v7a" in abis -> "armeabi-v7a"
            abis.isNotEmpty() -> abis[0]
            else -> "arm64-v8a"
        }
    }

    /**
     * Stage liblwjgl_glfw.so from APK native lib dir into the game natives dir.
     * Returns the staged file, or null if not found in APK.
     * Caller must already have staged the other libs via AndroidLwjglNativesInstaller.
     */
    fun stageAdapter(context: Context, gameNativesDir: File): File? {
        val abi = detectAbi()
        val candidates = listOf(
            File(context.applicationInfo.nativeLibraryDir, "liblwjgl_glfw.so"),
            File("/data/data/${context.packageName}/lib", "liblwjgl_glfw.so"),
            File(context.filesDir, "natives/$abi/liblwjgl_glfw.so")
        )
        val src = candidates.firstOrNull { it.exists() } ?: run {
            Log.e(TAG, "liblwjgl_glfw.so NOT found in APK native libs for ABI $abi. Candidates: $candidates")
            return null
        }
        gameNativesDir.mkdirs()
        val dst = File(gameNativesDir, "liblwjgl_glfw.so")
        src.copyTo(dst, overwrite = true)
        Log.i(TAG, "Staged liblwjgl_glfw.so: ${src.path} -> ${dst.path} (${dst.length()} bytes, ABI $abi)")
        return dst
    }

    /**
     * Verify all required libs exist in game natives dir. Does NOT try to load LWJGL here —
     * loading must happen on the game thread after EGL is ready (see GameSurfaceManager).
     */
    fun verifyStaged(gameNativesDir: File): VerificationResult {
        val abi = detectAbi()
        val missing = LwjglNativesContract.REQUIRED_LIBS.filter { !File(gameNativesDir, it).exists() }
        val ok = missing.isEmpty()
        val details = if (ok) {
            "All ${LwjglNativesContract.REQUIRED_LIBS.size} LWJGL/GLFW libs staged for $abi in ${gameNativesDir.path}"
        } else {
            "Missing for $abi: $missing in ${gameNativesDir.path}. Existing: ${gameNativesDir.list()?.toList()}"
        }
        Log.i(TAG, details)
        return VerificationResult(ok, abi, missing, details)
    }

    /**
     * Try to load LWJGL JNI adapter. MUST be called on game thread, after native lib dir
     * is on java.library.path / org.lwjgl.librarypath, and after EGL surface exists.
     * Returns true only if System.loadLibrary("lwjgl_glfw") succeeds.
     * Any UnsatisfiedLinkError is returned as false + logged, never swallowed silently.
     */
    fun tryLoadAdapter(): Boolean {
        return try {
            System.loadLibrary("lwjgl_glfw")
            Log.i(TAG, "System.loadLibrary(lwjgl_glfw) OK — JNI adapter loaded")
            true
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load liblwjgl_glfw.so: ${e.message}", e)
            false
        } catch (e: Throwable) {
            Log.e(TAG, "Unexpected failure loading lwjgl_glfw: ${e.message}", e)
            false
        }
    }

    fun tryLoadCore(): Boolean {
        return try {
            System.loadLibrary("lwjgl")
            System.loadLibrary("lwjgl_opengl")
            Log.i(TAG, "System.loadLibrary(lwjgl) + (lwjgl_opengl) OK")
            true
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load LWJGL core/opengl: ${e.message}", e)
            false
        }
    }
}
