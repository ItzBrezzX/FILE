package com.flintclient.input
import android.util.Log
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
/**
 * Phase 3 - Connect EXISTING input pipeline to real LWJGL event loop. Do NOT rebuild from scratch.
 * Contract:
 * - Android callbacks ONLY enqueue. Never call GLFW / Minecraft directly from UI thread.
 * - GLFW dispatch happens ONLY on game/window thread (called via dispatchOnGameThread).
 * - Queue is bounded. Overflow drops oldest, never blocks UI thread.
 * - On focus loss / queue overflow / stop, release all pressed keys + mouse buttons so nothing sticks.
 * - Existing Android input mapper / native queue are reused: this dispatcher is the bridge
 *   between them and LWJGL. If your existing mapper is named differently, wire its enqueue
 *   methods to enqueue() below — do not duplicate mapper logic here.
 */
class GameInputDispatcher(private val maxQueue: Int = 512) {
    sealed class InputEvent {
        data class Key(val keyCode: Int, val action: Int, val mods: Int) : InputEvent() // action: 0 release, 1 press, 2 repeat
        data class Char(val codePoint: Int) : InputEvent()
        data class MouseMove(val x: Double, val y: Double) : InputEvent()
        data class MouseButton(val button: Int, val action: Int, val mods: Int) : InputEvent()
        data class Scroll(val xOffset: Double, val yOffset: Double) : InputEvent()
        data class Resize(val width: Int, val height: Int) : InputEvent()
        data class Focus(val focused: Boolean) : InputEvent()
    }
    interface GlfwSink {
        fun onKey(keyCode: Int, action: Int, mods: Int)
        fun onChar(codePoint: Int)
        fun onMouseMove(x: Double, y: Double)
        fun onMouseButton(button: Int, action: Int, mods: Int)
        fun onScroll(xOffset: Double, yOffset: Double)
        fun onResize(width: Int, height: Int)
        fun onFocus(focused: Boolean)
        fun releaseAllKeysAndButtons()
    }
    private val queue = ArrayBlockingQueue<InputEvent>(maxQueue)
    private val pressedKeys = ConcurrentHashMap<Int, Boolean>()
    private val pressedButtons = ConcurrentHashMap<Int, Boolean>()
    @Volatile var droppedCount: Int = 0; private set
    @Volatile var dispatchedCount: Int = 0; private set
    /** Called from Android UI thread ONLY. Never blocks. */
    fun enqueue(ev: InputEvent): Boolean {
        if (ev is InputEvent.Key) { if (ev.action == 1) pressedKeys[ev.keyCode] = true else if (ev.action == 0) pressedKeys.remove(ev.keyCode) }
        if (ev is InputEvent.MouseButton) { if (ev.action == 1) pressedButtons[ev.button] = true else if (ev.action == 0) pressedButtons.remove(ev.button) }
        if (ev is InputEvent.Focus && !ev.focused) { handleFocusLoss() }
        val offered = queue.offer(ev)
        if (!offered) { droppedCount++; queue.poll(); queue.offer(ev); Log.w("FlintInput", "Queue full, dropped oldest. dropped=$droppedCount") }
        return offered
    }
    /** Called ONLY on game/window thread, e.g. inside glfwPollEvents loop. Drains queue to sink. */
    fun dispatchOnGameThread(sink: GlfwSink) {
        while (true) {
            val ev = queue.poll() ?: break
            dispatchedCount++
            when (ev) {
                is InputEvent.Key -> sink.onKey(ev.keyCode, ev.action, ev.mods)
                is InputEvent.Char -> sink.onChar(ev.codePoint)
                is InputEvent.MouseMove -> sink.onMouseMove(ev.x, ev.y)
                is InputEvent.MouseButton -> sink.onMouseButton(ev.button, ev.action, ev.mods)
                is InputEvent.Scroll -> sink.onScroll(ev.xOffset, ev.yOffset)
                is InputEvent.Resize -> sink.onResize(ev.width, ev.height)
                is InputEvent.Focus -> sink.onFocus(ev.focused)
            }
        }
    }
    fun handleFocusLoss() {
        // Release everything so keys/buttons cannot stick after focus loss.
        pressedKeys.keys.toList().forEach { pressedKeys.remove(it) }
        pressedButtons.keys.toList().forEach { pressedButtons.remove(it) }
        queue.offer(InputEvent.Focus(false))
    }
    fun releaseAllOnStop(sink: GlfwSink?) {
        pressedKeys.clear(); pressedButtons.clear(); queue.clear()
        sink?.releaseAllKeysAndButtons()
        Log.i("FlintInput", "Released all keys/buttons on stop. dispatched=$dispatchedCount dropped=$droppedCount")
    }
    fun queueSize(): Int = queue.size
    fun isStuck(): Boolean = pressedKeys.isNotEmpty() || pressedButtons.isNotEmpty()
}
