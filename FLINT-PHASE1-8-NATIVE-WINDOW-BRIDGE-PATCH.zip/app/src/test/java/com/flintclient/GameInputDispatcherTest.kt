package com.flintclient
import com.flintclient.input.GameInputDispatcher
import org.junit.Assert.*
import org.junit.Test
class GameInputDispatcherTest {
    @Test fun overflowDropsOldestAndDoesNotStick() {
        val d = GameInputDispatcher(maxQueue = 4)
        repeat(10) { d.enqueue(GameInputDispatcher.InputEvent.Key(65, 1, 0)) }
        assertTrue(d.droppedCount > 0)
        // Focus loss must clear stuck state
        d.handleFocusLoss()
        assertFalse(d.isStuck())
    }
    @Test fun androidCallbacksOnlyEnqueue() {
        val d = GameInputDispatcher()
        assertTrue(d.enqueue(GameInputDispatcher.InputEvent.MouseMove(10.0, 20.0)))
        assertEquals(1, d.queueSize())
    }
}
