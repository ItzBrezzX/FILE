package com.flintclient
import com.flintclient.launch.GameLaunchState
import org.junit.Assert.*
import org.junit.Test
class GameLaunchStateTest {
    @Test fun startedIsNotMinecraftInitialized() {
        // Regression: old LaunchResult.Started was shown as success. New states must be distinct.
        assertNotEquals(GameLaunchState.STARTING_MINECRAFT, GameLaunchState.MINECRAFT_INITIALIZED)
        assertNotEquals(GameLaunchState.PREPARING_NATIVES, GameLaunchState.MINECRAFT_INITIALIZED)
    }
}
