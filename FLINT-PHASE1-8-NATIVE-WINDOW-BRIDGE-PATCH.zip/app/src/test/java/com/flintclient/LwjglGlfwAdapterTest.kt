package com.flintclient
import com.flintclient.lwjgl.LwjglNativesContract
import org.junit.Assert.*
import org.junit.Test
/** Phase 6 - Unit: contract must not confuse libglfw.so with liblwjgl_glfw.so */
class LwjglGlfwAdapterTest {
    @Test fun requiredLibsContainBothGlfwLibsSeparately() {
        assertTrue(LwjglNativesContract.REQUIRED_LIBS.contains("libglfw.so"))
        assertTrue(LwjglNativesContract.REQUIRED_LIBS.contains("liblwjgl_glfw.so"))
        assertNotEquals("libglfw.so", "liblwjgl_glfw.so")
    }
    @Test fun forbiddenDtNeededDoesNotAllowDesktopGlfw() {
        assertTrue(LwjglNativesContract.FORBIDDEN_DT_NEEDED.contains("libX11.so"))
        assertTrue(LwjglNativesContract.FORBIDDEN_DT_NEEDED.contains("libglfw.so"))
    }
    @Test fun requiredJniSymbolsIncludeInitAndCreateWindow() {
        assertTrue(LwjglNativesContract.REQUIRED_JNI_SYMBOLS.any { it.endsWith("nglfwInit") })
        assertTrue(LwjglNativesContract.REQUIRED_JNI_SYMBOLS.any { it.endsWith("nglfwCreateWindow") })
    }
}
