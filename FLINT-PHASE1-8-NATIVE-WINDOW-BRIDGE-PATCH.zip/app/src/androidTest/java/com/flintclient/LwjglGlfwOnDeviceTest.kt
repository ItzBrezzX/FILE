package com.flintclient
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.flintclient.lwjgl.LwjglGlfwAdapter
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
/**
 * Phase 6 - On-device integration (NOT run in this patch — requires itel A665L Android 13).
 * Steps 1-8: load JRE, launch minimal Java class, load LWJGL classes, load JNI adapter,
 * init GLFW via Android Surface, create real window, init GL4ES, render + swap frame,
 * verify input reaches game. Steps 10-12 (vanilla MC, title screen, world) are manual device tests.
 */
@RunWith(AndroidJUnit4::class)
class LwjglGlfwOnDeviceTest {
    @Test fun lwjglGlfwAdapterLoadsOnDevice() {
        // This test is BLOCKED / NOT TESTED until run on device. Do NOT mark PASS without device run.
        // On device: assertTrue(LwjglGlfwAdapter.tryLoadCore()); assertTrue(LwjglGlfwAdapter.tryLoadAdapter())
        // For now, only verify ABI detection does not crash and does not assume.
        val abi = LwjglGlfwAdapter.detectAbi()
        assertTrue(abi.isNotEmpty())
    }
}
