#!/bin/bash
# Phase 6 - APK natives verification. Run after assembleDebug.
# Fails if liblwjgl_glfw.so is missing for the device ABI.
set -e
APK=${1:-app/build/outputs/apk/debug/app-debug.apk}
echo "Checking $APK"
unzip -l "$APK" | grep -E "liblwjgl\.so|liblwjgl_opengl\.so|liblwjgl_glfw\.so|libglfw\.so|libGL\.so" || { echo "FAIL: missing natives in APK"; exit 1; }
echo "APK natives present (packaging only - not proof Minecraft runs)"
python3 scripts/verify_lwjgl_glfw.py app/build/outputs/apk/debug || true
