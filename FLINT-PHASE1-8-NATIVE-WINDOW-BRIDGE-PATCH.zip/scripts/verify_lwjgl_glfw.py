#!/usr/bin/env python3
"""Phase 1 + 6 — Verify liblwjgl_glfw.so (LWJGL JNI adapter) and libglfw.so (C ABI) separately.
Usage: python3 scripts/verify_lwjgl_glfw.py <path-to-apk-or-natives-dir>
Checks: ELF class/ABI, DT_NEEDED (no desktop GLFW / GLIBC / X11 in adapter), required symbols via nm/readelf.
Exit 1 if any check fails. This is NOT a substitute for device test.
"""
import subprocess, sys, pathlib, re
REQUIRED_JNI = ["Java_org_lwjgl_glfw_GLFW_nglfwInit","Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow","Java_org_lwjgl_glfw_GLFW_nglfwDestroyWindow","Java_org_lwjgl_glfw_GLFW_nglfwMakeContextCurrent","Java_org_lwjgl_glfw_GLFW_nglfwSwapBuffers","Java_org_lwjgl_glfw_GLFW_nglfwPollEvents","Java_org_lwjgl_glfw_GLFW_nglfwWindowShouldClose"]
REQUIRED_C_ABI = ["glfwInit","glfwCreateWindow","glfwDestroyWindow","glfwMakeContextCurrent","glfwSwapBuffers","glfwPollEvents"]
FORBIDDEN_NEEDED = ["libglfw.so","libX11.so","libwayland-client.so","libc.so.6"]
def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.stdout + r.stderr
def check_so(path):
    print(f"== {path} ==")
    if not pathlib.Path(path).exists():
        print("MISSING"); return False
    hdr = run(["readelf","-h",str(path)])
    print("ELF:", [l for l in hdr.splitlines() if "Class:" in l or "Machine:" in l])
    needed = run(["readelf","-d",str(path)])
    print("DT_NEEDED:", [l.strip() for l in needed.splitlines() if "NEEDED" in l])
    ok = True
    for f in FORBIDDEN_NEEDED:
        if f in needed and "lwjgl_glfw" in str(path):
            print(f"FAIL: forbidden DT_NEEDED {f} in adapter"); ok=False
    syms = run(["nm","-D",str(path)])
    if "lwjgl_glfw" in str(path):
        for s in REQUIRED_JNI:
            if s not in syms: print(f"FAIL: missing JNI {s}"); ok=False
    if path.endswith("libglfw.so"):
        for s in REQUIRED_C_ABI:
            if s not in syms: print(f"FAIL: missing C ABI {s}"); ok=False
    print("OK" if ok else "FAIL")
    return ok
if __name__ == "__main__":
    root = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path("app/build")
    files = list(root.rglob("liblwjgl_glfw.so")) + list(root.rglob("libglfw.so"))
    if not files: print(f"No liblwjgl_glfw.so / libglfw.so found under {root}"); sys.exit(1)
    ok = all(check_so(str(f)) for f in files)
    sys.exit(0 if ok else 1)
