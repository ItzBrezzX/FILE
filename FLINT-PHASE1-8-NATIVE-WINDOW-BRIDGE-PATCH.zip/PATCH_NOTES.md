# FLINT — Phase 1-8 Native Window Bridge — PATCH (additive)

Branch yang ditarget: `feature/flint-native-window-bridge`
Commit audit terakhir yang lu kasih: `104093663cb8b798089d457921b49fbeb59a22a0`
Baseline: JANGAN pakai `main` yang lama. Patch ini dibuat untuk di-apply di atas commit di atas.

Izin: Lu udah izin ke Mojang. Client.jar boleh, akun offline boleh, akun Microsoft boleh. Dicatat, tidak ditanya lagi.

## Cara apply (tidak nimpa main, tidak auto-merge)
```bash
git checkout feature/flint-native-window-bridge
git pull origin feature/flint-native-window-bridge
# extract ZIP ini di root repo — semua file di bawah ini BARU, tidak menimpa file lama
# kecuali docs/NATIVE_WINDOW_BRIDGE.md yang memang diminta di Phase 8 (cek diff dulu)
unzip FLINT-PHASE1-8-NATIVE-WINDOW-BRIDGE-PATCH.zip -d .
git status
git add native/lwjgl-glfw-jni app/src/main/java/com/flintclient/lwjgl app/src/main/java/com/flintclient/game app/src/main/java/com/flintclient/input app/src/main/java/com/flintclient/launch app/src/main/java/com/flintclient/jvm scripts docs .github/workflows/flint-native-window-bridge.yml
git commit -m "Phase 1-8: LWJGL GLFW JNI adapter + production game surface + real PLAY pipeline"
git push origin feature/flint-native-window-bridge
```

## Yang TIDAK dilakukan patch ini (jujur)
- TIDAK push langsung ke GitHub dari sini (tidak ada login GitHub + tidak ada internet di sandbox).
- TIDAK membuat commit SHA baru — SHA di atas adalah commit audit lu, bukan commit baru.
- TIDAK menjalankan CI — CI result: NOT RUN / NOT TESTED.
- TIDAK membuat APK artifact — APK: NOT AVAILABLE dari patch ini.
- TIDAK menjalankan test di itel A665L Android 13 — device test: BLOCKED / NOT TESTED (tidak ada device di sini).
- TIDAK mengklaim Minecraft title screen tercapai — belum terbukti sampai device test lolos.

## Prinsip patch
- Additive only. Tidak ada `git reset`, tidak ada delete fitur lama.
- `libglfw.so` (Flint C ABI) != `liblwjgl_glfw.so` (LWJGL JNI adapter). Keduanya dibutuhkan, beda peran.
- Tidak ada mock / preview-only yang diklaim sebagai game asli. Preview tetap preview, game tetap game.
- `LaunchResult.Started` TIDAK lagi dipakai sebagai bukti Minecraft jalan. Diganti state machine di `GameLaunchState.kt`.
- `libGL.so` ada TIDAK lagi dipakai sebagai satu-satunya bukti renderer tersedia.

## File baru di patch ini
Lihat daftar lengkap di bawah + di `docs/PHASE1-8_STATUS.md`.

NOTE: Workflow file is shipped as github-workflow-flint-native-window-bridge.yml at ZIP root (because .github/ gets dropped in this workspace). Move it to .github/workflows/flint-native-window-bridge.yml in the repo before pushing.
