# FLINT CLIENT — Minecraft Java Edition Launcher for Android

**FLINT CLIENT** adalah launcher Android open-source yang menjalankan **Minecraft Java Edition** di Android (ARM64) menggunakan pola yang sama seperti PojavLauncher / Zalith Launcher / Fold Craft Launcher.

> ⚠️ **LEGAL:** FLINT tidak menyertakan Minecraft, aset Mojang, atau akun bajakan. Kamu harus memiliki lisensi Minecraft Java Edition dan login dengan akun Microsoft milikmu. FLINT hanya mengunduh file resmi dari server Mojang (`piston-meta.mojang.com`, `resources.download.minecraft.net`, `libraries.minecraft.net`) setelah autentikasi.

## Fitur Lengkap

### Core System
- Version Manager: manifest Mojang, inheritance, Release/Snapshot
- Java Runtime Manager: Adoptium JDK ARM64 (8 / 17 / 21)
- Download Engine: OkHttp, SHA1 validation, progress, resume
- Library Resolver: rules OS, classpath builder
- Asset Manager: asset index + objects download
- Native Library Manager: extract natives, load EGL/GL/GLFW/Input
- Game Instance Manager: multi-instance, mods/resourcepacks/shaderpacks
- JVM Process Manager + Launch Manager: JVM args + Game args + env
- Auth Manager: Microsoft OAuth → Xbox Live → XSTS → Minecraft Services + Offline (testing)
- Config Manager: `configs/flint-config.json`
- Storage Manager: folder terstruktur `flint/{versions,instances,libraries,assets,natives,runtimes,mods,...}`
- Logging, Crash Reporter, Cache Manager, Update Manager

### Native / Graphics
- `cpp/flint_egl.cpp` — EGL context ownership, SurfaceView bridge, resize, pause/resume
- `cpp/flint_gl.cpp` — GL wrapper (GL4ES-style shim → GLESv3)
- `cpp/flint_glfw.cpp` — GLFW-compatible backend: init, time, poll events
- `cpp/flint_input.cpp` — touchscreen → mouse/key/scroll

### Client Features
- HUD: FPS, CPS, Keystrokes, Coords, Direction, Armor, Potion, Ping, Memory
- Zoom, Fullbright (via gamma/lightmap flag), FOV, Render Distance, GUI Scale, Sensitivity
- Mod System: Fabric / Forge / NeoForge / Quilt, enable/disable, compatibility validation, profiles
- Server List: add/remove, address, port
- Resource Packs, Shader Packs, Skin Manager

## Struktur Proyek
```
FLINT-CLIENT/
  settings.gradle.kts
  build.gradle.kts
  app/
    build.gradle.kts
    src/main/AndroidManifest.xml
    src/main/java/com/flintclient/
      FlintApplication.kt
      core/{storage,config,logging,download,version,assets,natives,java,auth,instance,launch,crash,cache,update,mods,server,hud}
      native/{FlintEGL,FlintGL,FlintGLFW,FlintInput}.kt
      ui/{MainActivity,GameActivity,FlintBottomNav,theme,screens}
    src/main/cpp/{CMakeLists.txt,flint_egl.cpp,flint_gl.cpp,flint_glfw.cpp,flint_input.cpp}
    src/test/java/com/flintclient/{VersionManagerTest,LibraryResolverTest}.kt
```

## Cara Build

1. Install Android Studio Ladybug+ , Android SDK 34, NDK 26, CMake 3.22.1
2. Clone / unzip repo ini
3. Buka di Android Studio → Sync Gradle
4. Jalankan di device ARM64 Android 8.0+ (minSdk 26)
5. Di app: buat akun → pilih Version (misal 1.21.1) → Install → PLAY

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Cara Kerja Launch (Pipeline)
1. Fetch `version_manifest_v2.json` dari Mojang
2. Download `version.json` + `client.jar`
3. Download libraries sesuai rules + natives
4. Extract natives → `natives/<version>/`
5. Download asset index + objects
6. Download / validasi Java Runtime (Adoptium ARM64)
7. Build classpath + JVM args + Game args (placeholder replacement)
8. Init EGL via SurfaceView → start JVM ProcessBuilder → stream log → Minecraft Title Screen

## Pengujian
- `./gradlew testDebugUnitTest` — unit test LaunchArguments + LibraryResolver
- Manual: buka app → semua menu → install version → PLAY → title screen → masuk world → cek rendering, kontrol, audio → tutup & buka lagi tanpa crash

## Yang Belum / Perlu Kamu Lanjutkan
- GL4ES full: repo ini memakai shim GLESv3. Untuk kompatibilitas penuh Minecraft 1.16+, integrasikan GL4ES upstream (https://github.com/ptitSeb/gl4es) sebagai submodule dan link di `CMakeLists.txt`. Pola EGL/GLFW di sini sudah siap untuk itu.
- LWJGL 3 Android: ganti LWJGL desktop dengan build Android (PojavLauncher `lwjgl3` fork) — classpath builder sudah mendukung extraJars.
- Fabric/Forge installer: tambahkan download loader JSON dari `meta.fabricmc.net` / Forge promotions — `VersionManager` sudah punya konstanta dan `resolveInheritance()` untuk itu.

## Lisensi
Kode FLINT CLIENT ini milikmu untuk dikembangkan. Minecraft adalah merek dagang Mojang / Microsoft. Jangan distribusikan ulang game atau aset Mojang.

## Kontribusi
PR welcome. Jalankan `./gradlew testDebugUnitTest` sebelum push.


## PART 2 - Update (Fabric/Forge/LWJGL/GL4ES)
- FabricManager.kt: auto fetch loader + profile json dari meta.fabricmc.net
- ForgeManager.kt: promotions_slim.json + installer download + --installClient
- LWJGLManager.kt: LWJGL 3.3.3 modules + natives linux-arm64
- TouchControls.kt: layout tombol sentuh + joystick -> movement
- HUDOverlay.kt: Compose HUD FPS/CPS/Coords/Keystrokes
- SkinManager.kt: download skin via session server
- GL4ES_INTEGRATION.md: cara pasang submodule gl4es


## PART 6 - SEMUA DILANJUTIN (Renderer + JNI JVM + Modrinth Live + Controller + Test)
- RendererManager.kt: pilih MobileGLUES (rekomendasi, dipakai Zenith 1.3.3) / Angle (Vulkan) / GL4ES (legacy), auto pilih berdasarkan versi MC + low-end
- MobileGLUESManager.kt: download .so v1.3.3 dari GitHub, load via System.load(), cek isInstalled
- JNIVMLauncher.kt + flint_jvm.cpp: JNI_CreateJavaVM beneran, panggil net.minecraft.client.main.Main, bukan ProcessBuilder lagi. CMakeLists.txt update untuk libflint_jvm.so
- ModrinthManager.kt: search live ke api.modrinth.com/v2/search, getFeaturedMods (Sodium/Iris/Fabric API dll), getVersionsForMod (filter game version + loader), formatDownloads
- ControllerManager.kt + KeyboardMouseManager.kt: deteksi PS4 DualShock / PS5 DualSense / Xbox / Generic via InputDevice, mapping Left Stick=WASD, Right Stick=Mouse, A=Klik Kiri, Start=Esc. Keyboard/mouse BT auto detect.
- LaunchTestChecklist.kt: 15 test case T01-T15 dari buka launcher sampai offline + template laporan
- TESTING.md: cara build APK, urutan test, cara kirim crash log

### Cara Test (lo bilang nanti ku test):
1. Build APK di Android Studio, install ke HP
2. Ikuti TESTING.md T01-T15 berurutan, jangan loncat
3. Kalau PLAY gagal, cek 2 .so: MobileGLUES.so + libjvm.so sudah ada di files/ belum - tanpa itu PLAY memang belum bisa jalan, itu bukan bug code.
4. Kirim laporan PASS/FAIL + HP + Android + logcat ke aku, aku benerin.
