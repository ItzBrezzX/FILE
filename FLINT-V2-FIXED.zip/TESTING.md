# FLINT CLIENT - CARA TEST (Part 6)

## 1. Build APK
1. Buka Android Studio -> Open folder `flint-client`
2. Sync Gradle (tunggu sampai selesai, jangan skip)
3. Build > Build APK(s) > Build APK(s) -> Install ke HP
4. Kalau error di native: pastikan NDK terinstall, CMake 3.22.1

## 2. Test Urutan (jangan loncat!)
Ikuti `LaunchTestChecklist.kt` T01 s/d T15. Urutan penting:
- T01 Buka Launcher dulu
- T02 Auto Update Snapshot
- T03 Install 1.21.10
- T04 PLAY 1.21.10 -> Title Screen
- T05 Masuk World 30 detik
- Kalau T04 gagal, jangan lanjut ke T06. Screenshot logcat + kirim ke aku.

## 3. Kalau Crash, Kirim Ini:
- HP: (contoh: Redmi Note 12, 4GB RAM)
- Android: (contoh: Android 13)
- Versi yang di-test: (1.21.10 / snapshot / b1.7.3)
- Renderer: (MobileGLUES / Angle / GL4ES)
- Logcat: `adb logcat | grep FLINT` atau dari CrashReporter di app
- Screenshot error

## 4. Yang Sudah Bisa Di-test Sekarang:
- UI Main Menu + Mod Menu (preview HTML sudah 100%)
- Auto Update manifest (fetch Mojang)
- Modrinth search live (butuh internet)
- Controller detection (butuh controller BT)
- Version filter All/Release/Snapshot/Beta/Alpha

## 5. Yang Masih Butuh .so Real:
- MobileGLUES .so harus di-download dari GitHub MobileGLUES v1.3.3, extract ke files/natives/
- libjvm.so dari Adoptium Java 21, extract ke files/java/21/lib/server/
- Tanpa 2 file .so itu, PLAY akan log "JVM gagal" - itu wajar, bukan bug code.

## 6. Template Laporan:
Lihat `LaunchTestChecklist.getTestReportTemplate()` - copy, isi PASS/FAIL, kirim ke aku.
