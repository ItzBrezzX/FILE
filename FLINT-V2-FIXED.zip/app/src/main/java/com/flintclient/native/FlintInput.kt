package com.flintclient.native
object FlintInput {
    init { try { System.loadLibrary("flint_input") } catch (e: Throwable) { android.util.Log.e("FLINT-INPUT", "load flint_input failed: ${e.message}") } }
    external fun nativeSendMouse(x: Float, y: Float, button: Int, action: Int)
    external fun nativeSendKey(keyCode: Int, action: Int)
    external fun nativeSendScroll(dx: Float, dy: Float)
    external fun nativeSendTouch(x: Float, y: Float, action: Int)
}
