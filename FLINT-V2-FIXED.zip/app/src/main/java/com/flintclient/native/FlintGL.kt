package com.flintclient.native
object FlintGL {
    init { try { System.loadLibrary("flint_gl") } catch (e: Throwable) { android.util.Log.e("FLINT-GL", "load flint_gl failed: ${e.message}") } }
    external fun nativeGetGLVersion(): String
    external fun nativeSetFullbright(enabled: Boolean)
    external fun nativeIsFullbright(): Boolean
}
