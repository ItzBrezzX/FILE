package com.flintclient.native
import android.view.Surface
object FlintEGL {
    init { try { System.loadLibrary("flint_egl") } catch (e: Throwable) { android.util.Log.e("FLINT-EGL", "load flint_egl failed: " + (e.message ?: "")) } }
    // DEPRECATED V2: EGL dibuat di JVM thread via flint_jvm.cpp, BUKAN dari UI thread. Fungsi ini sekarang return false + log.
    @Deprecated("EGL dibuat di JVM thread, jangan panggil dari UI thread")
    external fun nativeInitEGL(surface: Surface): Boolean
    external fun nativeSwapBuffers()
    external fun nativeDestroyEGL()
    external fun nativeResize(w: Int, h: Int)
    external fun nativePause()
    external fun nativeResume()
    external fun nativeGetWidth(): Int
    external fun nativeGetHeight(): Int
    external fun nativeIsReady(): Boolean
}
