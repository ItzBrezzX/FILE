package com.flintclient.native
object FlintGLFW {
    init { try { System.loadLibrary("flint_glfw") } catch (e: Throwable) { android.util.Log.e("FLINT-GLFW", "load flint_glfw failed: ${e.message}") } }
    external fun nativeGetTime(): Double
    external fun nativeInit(): Boolean
    external fun nativePollEvents()
    external fun nativeTerminate()
    external fun nativeGetPendingEventCount(): Int
    external fun nativeSetWindowSize(w: Int, h: Int)
    external fun nativeShouldClose(): Boolean
    external fun nativeSetShouldClose(v: Boolean)
    external fun nativeGetWidth(): Int
    external fun nativeGetHeight(): Int
}
