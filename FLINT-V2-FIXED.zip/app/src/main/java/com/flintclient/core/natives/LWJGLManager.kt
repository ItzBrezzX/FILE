package com.flintclient.core.natives

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.File

// FIX 5 - LWJGL Android yang benar (V2)
// SEBELUMNYA SALAH: LWJGLManager hanya download natives desktop / tidak ada LWJGL Android jar,
//   jadi Minecraft pakai LWJGL desktop yang manggil GLFW .so desktop -> UnsatisfiedLinkError / crash.
// YANG BENAR (Pojav):
//   PojavLauncherTeam/lwjgl3 - LWJGL 3.3.x yang di-patch untuk Android.
//   File-nya: lwjgl-3.3.1-android.jar (atau versi terbaru di releases) + natives-nya sudah di dalam CallbackBridge.
//   LWJGL Android JAR HARUS di classpath SEBELUM LWJGL desktop dari Mojang, supaya class
//   org.lwjgl.glfw.GLFW yang ke-load adalah versi Android (yang manggil CallbackBridge), bukan desktop.
//   Kalau urutan kebalik, Minecraft akan load GLFW desktop dan crash.
//   Source: https://github.com/PojavLauncherTeam/lwjgl3/releases
//   File ini TIDAK di-vendor di repo (lisensi + ukuran). Di-download di device pas first launch, atau di-build machine.
class LWJGLManager(private val storage: StorageManager) {
    private val downloadEngine = DownloadEngine()
    companion object {
        const val LWJGL_ANDROID_RELEASES_API = "https://api.github.com/repos/PojavLauncherTeam/lwjgl3/releases"
        const val LWJGL_ANDROID_JAR_NAME = "lwjgl-android.jar"
    }
    fun lwjglAndroidJar(): File = File(storage.librariesDir, "lwjgl-android/" + LWJGL_ANDROID_JAR_NAME)
    fun isLWJGLAndroidInstalled(): Boolean {
        val f = lwjglAndroidJar()
        return f.exists() && f.length() > 100000
    }
    suspend fun ensureLWJGLAndroid(onProgress: (Int) -> Unit = {}): Boolean {
        if (isLWJGLAndroidInstalled()) { FlintLogger.i("LWJGL", "LWJGL Android sudah ada"); return true }
        FlintLogger.i("LWJGL", "Download LWJGL Android dari PojavLauncherTeam/lwjgl3...")
        val url = resolveLWJGLAndroidUrl()
        if (url == null) { FlintLogger.e("LWJGL", "Gagal resolve URL LWJGL Android - cek https://github.com/PojavLauncherTeam/lwjgl3/releases"); return false }
        val dest = lwjglAndroidJar()
        dest.parentFile?.mkdirs()
        val ok = downloadEngine.download(DownloadTask(url, dest, null, 0))
        if (!ok || !isLWJGLAndroidInstalled()) { FlintLogger.e("LWJGL", "Download LWJGL Android GAGAL"); return false }
        FlintLogger.i("LWJGL", "LWJGL Android OK: " + dest.absolutePath)
        return true
    }
    suspend fun resolveLWJGLAndroidUrl(): String? {
        return try {
            val json = java.net.URL(LWJGL_ANDROID_RELEASES_API).readText()
            // Cari asset .jar yang namanya mengandung lwjgl / android
            var idx = json.indexOf(".jar")
            while (idx >= 0) {
                val start = json.lastIndexOf("browser_download_url", idx)
                if (start >= 0) {
                    val q1 = json.indexOf('"', json.indexOf(':', start) + 1) + 1
                    val q2 = json.indexOf('"', q1)
                    val url = json.substring(q1, q2)
                    if (url.endsWith(".jar") && (url.contains("lwjgl") || url.contains("android"))) return url
                }
                idx = json.indexOf(".jar", idx + 1)
                if (idx < 0) break
            }
            null
        } catch (e: Exception) { FlintLogger.e("LWJGL", "GitHub API LWJGL gagal: " + (e.message ?: "")); null }
    }
    // Classpath: LWJGL Android HARUS pertama, sebelum semua LWJGL desktop Mojang.
    // LaunchManager akan panggil ini dan prepend ke classpath.
    fun buildClasspathWithLWJGLAndroidFirst(baseClasspath: List<File>): List<File> {
        val androidJar = lwjglAndroidJar()
        if (!androidJar.exists()) return baseClasspath
        // Buang LWJGL desktop glfw/lwjgl/openal/stb dari base, ganti dengan Android version.
        // Nama artifact desktop yang harus dibuang: lwjgl-3.3.x.jar, lwjgl-glfw-*.jar, lwjgl-opengl-*.jar, dst.
        // Kita buang yang namanya mengandung lwjgl- dan BUKAN lwjgl-android, supaya tidak ada duplicate class GLFW.
        val filtered = baseClasspath.filter { f ->
            val n = f.name
            !(n.startsWith("lwjgl-") && !n.contains("android"))
        }
        return listOf(androidJar) + filtered
    }
}
