package com.flintclient.core.renderer

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.File

// FIX 6 - Renderer MobileGLUES / GL4ES / ANGLE (V2)
// SEBELUMNYA SALAH: flint_gl.cpp diklaim "GL4ES-like" padahal cuma 2 fungsi, dan MobileGLUESManager tidak pernah
//   download .so yang bener, jadi renderer tidak pernah ke-load, Minecraft crash di GL init.
// YANG BENAR (Pojav + MobileGLUES):
//   - MobileGLUES v1.3.3: https://github.com/MobileGLUES/MobileGLUES/releases/tag/v1.3.3
//     File: libMobileGLUES.so (arm64-v8a) - ini yang dipakai untuk 1.21+ (OpenGL ES 3.0 -> Vulkan / GLES)
//   - GL4ES: https://github.com/PojavLauncherTeam/gl4es (fork Pojav) - libgl4es.so, untuk versi lama (1.12-)
//   - ANGLE: libangle.so - untuk device yang Vulkan-nya bagus
//   .so HARUS di-load SEBELUM EGL context dibuat, dan SEBELUM JVM start, via System.load(absolutePath)
//   di thread yang sama dengan EGL (JVM thread) atau via LD_LIBRARY_PATH + nativeSetEnv.
//   Di FLINT: LaunchManager panggil ensureRenderer() SEBELUM JNIVMLauncher.launch(), lalu nativeSetEnv("LIBGL_ES", ...)
//   RendererManager.pickBestRenderer() yang pilih mana yang dipakai.
enum class RendererType { MOBILE_GLUES, GL4ES, ANGLE, GLES_DIRECT }

object MobileGLUESManager {
    const val MOBILE_GLUES_RELEASES_API = "https://api.github.com/repos/MobileGLUES/MobileGLUES/releases"
    fun rendererSoDir(storage: StorageManager): File = File(storage.rootDir, "renderer").apply { mkdirs() }
    fun mobileGluesSo(storage: StorageManager): File = File(rendererSoDir(storage), "libMobileGLUES.so")
    fun gl4esSo(storage: StorageManager): File = File(rendererSoDir(storage), "libgl4es.so")
    fun angleSo(storage: StorageManager): File = File(rendererSoDir(storage), "libangle.so")
    fun isRendererInstalled(storage: StorageManager, type: RendererType): Boolean {
        return when (type) {
            RendererType.MOBILE_GLUES -> mobileGluesSo(storage).let { it.exists() && it.length() > 100000 }
            RendererType.GL4ES -> gl4esSo(storage).let { it.exists() && it.length() > 100000 }
            RendererType.ANGLE -> angleSo(storage).let { it.exists() && it.length() > 100000 }
            RendererType.GLES_DIRECT -> true
        }
    }
    suspend fun ensureRenderer(storage: StorageManager, type: RendererType): Boolean {
        if (isRendererInstalled(storage, type)) { FlintLogger.i("Renderer", "Renderer " + type + " sudah ada"); return true }
        if (type == RendererType.GLES_DIRECT) return true
        FlintLogger.i("Renderer", "Download renderer " + type + " ...")
        val url = when (type) {
            RendererType.MOBILE_GLUES -> resolveMobileGluesUrl()
            RendererType.GL4ES -> "https://github.com/PojavLauncherTeam/gl4es/releases/download/v1.1.5/libgl4es.so"
            RendererType.ANGLE -> "https://github.com/PojavLauncherTeam/angle/releases/download/v1.0/libangle.so"
            else -> null
        }
        if (url == null) { FlintLogger.e("Renderer", "Gagal resolve URL renderer " + type); return false }
        val dest = when (type) {
            RendererType.MOBILE_GLUES -> mobileGluesSo(storage)
            RendererType.GL4ES -> gl4esSo(storage)
            RendererType.ANGLE -> angleSo(storage)
            else -> return false
        }
        val ok = DownloadEngine().download(DownloadTask(url, dest, null, 0))
        if (!ok || !isRendererInstalled(storage, type)) { FlintLogger.e("Renderer", "Download renderer " + type + " GAGAL - BLOCKED"); return false }
        FlintLogger.i("Renderer", "Renderer " + type + " OK: " + dest.absolutePath)
        return true
    }
    suspend fun resolveMobileGluesUrl(): String? {
        return try {
            val json = java.net.URL(MOBILE_GLUES_RELEASES_API).readText()
            var idx = json.indexOf("libMobileGLUES.so")
            while (idx >= 0) {
                val start = json.lastIndexOf("browser_download_url", idx)
                if (start >= 0) {
                    val q1 = json.indexOf('"', json.indexOf(':', start) + 1) + 1
                    val q2 = json.indexOf('"', q1)
                    val url = json.substring(q1, q2)
                    if (url.contains("MobileGLUES")) return url
                }
                idx = json.indexOf("libMobileGLUES.so", idx + 1)
            }
            null
        } catch (e: Exception) { FlintLogger.e("Renderer", "GitHub API MobileGLUES gagal: " + (e.message ?: "")); null }
    }
    fun loadRendererSo(storage: StorageManager, type: RendererType): Boolean {
        val so = when (type) {
            RendererType.MOBILE_GLUES -> mobileGluesSo(storage)
            RendererType.GL4ES -> gl4esSo(storage)
            RendererType.ANGLE -> angleSo(storage)
            RendererType.GLES_DIRECT -> return true
        }
        if (!so.exists()) { FlintLogger.e("Renderer", "Renderer .so tidak ada: " + so.absolutePath + " - BLOCKED, jangan lanjut ke PLAY"); return false }
        return try {
            System.load(so.absolutePath)
            FlintLogger.i("Renderer", "System.load OK: " + so.absolutePath)
            true
        } catch (e: Throwable) { FlintLogger.e("Renderer", "System.load renderer GAGAL: " + (e.message ?: "")); false }
    }
    fun getRendererEnv(storage: StorageManager, type: RendererType): Map<String, String> {
        val dir = rendererSoDir(storage).absolutePath
        return when (type) {
            RendererType.MOBILE_GLUES -> mapOf("LIBGL_ES" to "2", "LIBGL_GL" to "2", "LD_LIBRARY_PATH" to dir, "MOBILEGLUES_DEBUG" to "0")
            RendererType.GL4ES -> mapOf("LIBGL_ES" to "2", "LIBGL_GL" to "2", "LD_LIBRARY_PATH" to dir)
            RendererType.ANGLE -> mapOf("LIBGL_ES" to "2", "LD_LIBRARY_PATH" to dir)
            RendererType.GLES_DIRECT -> mapOf("LIBGL_ES" to "2")
        }
    }
}
