package com.flintclient.core.java

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.*

data class JavaRuntime(val id: String, val version: Int, val path: File, val isInstalled: Boolean, val libJvmSo: File? = null)

class JavaRuntimeManager(private val storage: StorageManager) {
    private val downloadEngine = DownloadEngine()
    companion object {
        const val POJAV_JRE_RELEASES_API = "https://api.github.com/repos/PojavLauncherTeam/android-openjdk-build/releases"
    }
    fun libJvmSoFor(javaMajor: Int): File? {
        val candidates = listOf(
            File(storage.runtimesDir, "java-" + javaMajor + "/lib/server/libjvm.so"),
            File(storage.runtimesDir, "java-" + javaMajor + "/jre/lib/aarch64/server/libjvm.so"),
            File(storage.runtimesDir, "java-" + javaMajor + "/lib/aarch64/server/libjvm.so")
        )
        return candidates.firstOrNull { it.exists() && it.length() > 1000000 && isBionicJvm(it) }
    }
    fun isBionicJvm(libJvmSo: File): Boolean {
        return try {
            val release = File(libJvmSo.parentFile?.parentFile?.parentFile, "release")
            if (release.exists() && release.readText().contains("Adoptium", ignoreCase = true)) {
                FlintLogger.e("JavaRuntime", "REJECTED Adoptium libjvm.so - glibc, tidak kompatibel Bionic.")
                return false
            }
            FileInputStream(libJvmSo).use { fis ->
                val magic = ByteArray(4); fis.read(magic)
                magic[0]==0x7f.toByte() && magic[1]==69.toByte() && magic[2]==76.toByte() && magic[3]==70.toByte()
            }
        } catch (e: Exception) { false }
    }
    fun isRuntimeInstalled(javaMajor: Int): Boolean = libJvmSoFor(javaMajor) != null
    fun listRuntimes(): List<JavaRuntime> = listOf(8,17,21).map { v ->
        val so = libJvmSoFor(v)
        JavaRuntime("java-" + v, v, File(storage.runtimesDir, "java-" + v), so != null, so)
    }
    fun getJavaForVersion(minecraftVersion: String, javaMajor: Int): JavaRuntime = listRuntimes().first { it.version == javaMajor }
    suspend fun downloadRuntime(javaMajor: Int, onProgress: (Int) -> Unit = {}): Boolean {
        try {
            FlintLogger.i("JavaRuntime", "Download Pojav Android JRE " + javaMajor + " (Bionic) - BUKAN Adoptium")
            val url = resolvePojavJreUrl(javaMajor)
            if (url == null) { FlintLogger.e("JavaRuntime", "Gagal resolve URL Pojav JRE " + javaMajor + " - cek https://github.com/PojavLauncherTeam/android-openjdk-build/releases"); return false }
            val dest = File(storage.downloadsDir, "jre-" + javaMajor + "-android-aarch64.tar.xz")
            FlintLogger.i("JavaRuntime", "Download dari " + url)
            downloadEngine.download(DownloadTask(url, dest, null, 0))
            val ok = extractTarXz(dest, File(storage.runtimesDir, "java-" + javaMajor))
            if (!ok) { FlintLogger.e("JavaRuntime", "Extract Pojav JRE FAILED"); return false }
            val so = libJvmSoFor(javaMajor)
            if (so == null) { FlintLogger.e("JavaRuntime", "libjvm.so Pojav TIDAK DITEMUKAN / masih glibc - BLOCKED"); return false }
            FlintLogger.i("JavaRuntime", "Pojav JRE " + javaMajor + " OK: " + so.absolutePath)
            return true
        } catch (e: Exception) { FlintLogger.e("JavaRuntime", "downloadRuntime Pojav FAILED: " + (e.message ?: "")); return false }
    }
    suspend fun resolvePojavJreUrl(javaMajor: Int): String? {
        return try {
            val json = java.net.URL(POJAV_JRE_RELEASES_API).readText()
            val needle = "jre-" + javaMajor
            var idx = json.indexOf(needle)
            while (idx >= 0) {
                val start = json.lastIndexOf("browser_download_url", idx)
                if (start >= 0) {
                    val q1 = json.indexOf('"', json.indexOf(':', start) + 1) + 1
                    val q2 = json.indexOf('"', q1)
                    val url = json.substring(q1, q2)
                    if (url.endsWith(".tar.xz") && url.contains(needle)) return url
                }
                idx = json.indexOf(needle, idx + 1)
            }
            null
        } catch (e: Exception) {
            FlintLogger.w("JavaRuntime", "GitHub API gagal: " + (e.message ?: ""))
            null
        }
    }
    fun extractTarXz(tarXz: File, destDir: File): Boolean {
        destDir.mkdirs()
        return try {
            val proc = ProcessBuilder("tar", "-xJf", tarXz.absolutePath, "-C", destDir.absolutePath, "--strip-components=1").redirectErrorStream(true).start()
            val out = proc.inputStream.bufferedReader().readText()
            val code = proc.waitFor()
            if (code == 0) { FlintLogger.i("JavaRuntime", "tar -xJf OK"); return true }
            FlintLogger.w("JavaRuntime", "tar -xJf exit " + code + ": " + out)
            false
        } catch (e: Exception) { FlintLogger.e("JavaRuntime", "extractTarXz FAILED: " + (e.message ?: "")); false }
    }
}
