package com.flintclient.ui

import android.os.Bundle
import android.view.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.flintclient.FlintApplication
import com.flintclient.core.assets.AssetManager
import com.flintclient.core.auth.AuthManager
import com.flintclient.core.config.ConfigManager
import com.flintclient.core.controls.TouchControlsOverlay
import com.flintclient.core.instance.GameInstanceManager
import com.flintclient.core.java.JavaRuntimeManager
import com.flintclient.core.launch.LaunchManager
import com.flintclient.core.launch.LaunchState
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.natives.NativeLibraryManager
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.VersionManager
import com.flintclient.native.FlintEGL
import com.flintclient.native.FlintGLFW
import kotlinx.coroutines.launch

class GameActivity : AppCompatActivity(), SurfaceHolder.Callback {
    private lateinit var surfaceView: SurfaceView
    private lateinit var launchManager: LaunchManager
    private lateinit var touchOverlay: TouchControlsOverlay
    private var eglReady = false
    private var launchStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val app = application as FlintApplication
        val storage: StorageManager = app.storage
        val config: ConfigManager = app.config
        val versionManager = VersionManager(storage)
        val authManager = AuthManager(storage)
        val instanceManager = GameInstanceManager(storage)
        val javaManager = JavaRuntimeManager(storage)
        val assetManager = AssetManager(storage)
        val nativeManager = NativeLibraryManager(storage)
        launchManager = LaunchManager(this, storage, config, versionManager, authManager, instanceManager, javaManager, assetManager, nativeManager)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        touchOverlay = TouchControlsOverlay(this)
        val layout = FrameLayout(this)
        layout.addView(surfaceView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        layout.addView(touchOverlay, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(layout)
        // Load natives - if any fails, show REAL error, don't silently continue
        try {
            nativeManager.loadFlintNatives()
            FlintGLFW.nativeInit()
            FlintLogger.i("GameActivity", "Natives + GLFW init OK")
        } catch (e: Throwable) {
            FlintLogger.e("GameActivity", "Native load FAILED: ${e.message}")
            Toast.makeText(this, "Native lib gagal: ${e.message} - APK tidak lengkap / ABI salah", Toast.LENGTH_LONG).show()
            finish(); return
        }
        launchManager.onState = { state ->
            when (state) {
                is LaunchState.Failed -> runOnUiThread { Toast.makeText(this, "Launch gagal: ${state.error}", Toast.LENGTH_LONG).show(); finish() }
                is LaunchState.Running -> runOnUiThread { Toast.makeText(this, "Minecraft berjalan...", Toast.LENGTH_SHORT).show() }
                is LaunchState.Preparing -> FlintLogger.i("GameActivity", "Launch ${state.progress}% ${state.step}")
                else -> {}
            }
        }
        // Touch overlay forwards to FlintInput -> GLFW queue
        touchOverlay.onInput = { type, x, y, button, action -> touchOverlay.forwardToNative(type, x, y, button, action) }
    }
    override fun surfaceCreated(holder: SurfaceHolder) {
        // FIX 4 V2: JANGAN init EGL di UI thread. EGL dibuat di JVM thread (flint_jvm.cpp).
        // Di sini HANYA: simpan Surface -> pass ke LaunchManager -> JNIVMLauncher.nativeSetSurface
        // EGL akan dibuat di JVM thread sebelum Minecraft main dipanggil.
        eglReady = true // artinya Surface ready, BUKAN EGL ready. EGL ready dicek di JVM thread.
        try { launchManager.setSurface(holder.surface) } catch (e: Throwable) { FlintLogger.e("GameActivity", "setSurface gagal: ${e.message}") }
        try { com.flintclient.bridge.CallbackBridge.setWindowSize(holder.surfaceFrame.width(), holder.surfaceFrame.height()) } catch (e: Throwable) {}
        FlintGLFW.nativeSetWindowSize(holder.surfaceFrame.width(), holder.surfaceFrame.height())
        if (!launchStarted) {
            launchStarted = true
            lifecycleScope.launch {
                val app = application as FlintApplication
                launchManager.prepareAndLaunch(app.config.config.selectedInstanceId)
            }
        } else {
            // Surface recreated (rotate) - resume EGL
            try { FlintEGL.nativeResume() } catch (e: Exception) { FlintLogger.e("GameActivity", "EGL resume failed: ${e.message}") }
        }
    }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (eglReady) { try { FlintEGL.nativeResize(width, height); FlintGLFW.nativeSetWindowSize(width, height) } catch (e: Exception) { FlintLogger.e("GameActivity", "Resize failed: ${e.message}") } }
    }
    override fun surfaceDestroyed(holder: SurfaceHolder) {
        // JANGAN destroy/pause EGL dari UI thread - EGL milik JVM thread. Hanya log.
    }
    override fun onPause() { super.onPause(); /* EGL pause di-handle JVM thread, bukan UI thread */ }
    override fun onResume() { super.onResume(); /* EGL resume di-handle JVM thread */ }
    override fun onDestroy() {
        super.onDestroy()
        launchManager.stopGame()
        try { FlintEGL.nativeDestroyEGL() } catch (e: Exception) {}
        try { FlintGLFW.nativeTerminate() } catch (e: Exception) {}
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // External keyboard -> native
        try { com.flintclient.native.FlintInput.nativeSendKey(keyCode, 1) } catch (e: Exception) {}
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        try { com.flintclient.native.FlintInput.nativeSendKey(keyCode, 0) } catch (e: Exception) {}
        return super.onKeyUp(keyCode, event)
    }
}
