// FLINT Input - Real bridge (repaired Phase 7)
// Java -> native GLFW event queue. Previously only LOGI, now actually enqueues.
#include <jni.h>
#include <android/log.h>
#define LOG_TAG "FLINT-INPUT"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
// Declared in flint_glfw.cpp
extern void flint_glfw_push_event(int type, int key, int button, int action, float x, float y, float dx, float dy);
extern "C" {
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendMouse(JNIEnv* env, jclass c, jfloat x, jfloat y, jint button, jint action) {
    flint_glfw_push_event(1, 0, button, action, x, y, 0, 0);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendKey(JNIEnv* env, jclass c, jint keyCode, jint action) {
    flint_glfw_push_event(2, keyCode, 0, action, 0, 0, 0, 0);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendScroll(JNIEnv* env, jclass c, jfloat dx, jfloat dy) {
    flint_glfw_push_event(3, 0, 0, 0, 0, 0, dx, dy);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendTouch(JNIEnv* env, jclass c, jfloat x, jfloat y, jint action) {
    // Touch down/move/up -> mouse move + button
    flint_glfw_push_event(4, 0, 0, action, x, y, 0, 0);
}
}
