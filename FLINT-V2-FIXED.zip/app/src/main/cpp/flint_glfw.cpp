// FLINT GLFW - Forward ke CallbackBridge, BUKAN buang event (V2)
// SEBELUMNYA: nativePollEvents nge-drain queue lalu discard -> LWJGL tidak terima input.
// SEKARANG: setiap push dari FlintInput langsung CallStaticVoidMethod ke CallbackBridge.push*.
// JavaVM* disimpan dari JNI_OnLoad / dari ART, dipakai untuk AttachCurrentThread di native thread.
// LWJGL Android (org.lwjgl.glfw.GLFW) poll via CallbackBridge.pollEvents() dari JVM thread.
#include <jni.h>
#include <android/log.h>
#include <time.h>
#include <mutex>
#define LOG_TAG "FLINT-GLFW"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
static JavaVM* g_vm = nullptr;
static double g_startTime = 0;
static int g_width = 1280, g_height = 720;
static bool g_shouldClose = false;
static double flint_get_time() { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); double now = ts.tv_sec + ts.tv_nsec/1e9; if (g_startTime==0) g_startTime=now; return now-g_startTime; }
// Helper: panggil CallbackBridge.push* dari native thread mana pun.
// Harus AttachCurrentThread dulu kalau thread ini bukan thread JVM/ART.
static void callBridge(const char* method, const char* sig, ...) {
    if (!g_vm) { LOGE("CallbackBridge call %s gagal: g_vm null - JNI_OnLoad belum jalan?", method); return; }
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) { LOGE("AttachCurrentThread gagal untuk %s", method); return; }
        attached = true;
    }
    jclass cls = env->FindClass("com/flintclient/bridge/CallbackBridge");
    if (!cls) { LOGE("CallbackBridge class tidak ketemu"); if (attached) g_vm->DetachCurrentThread(); return; }
    jmethodID mid = env->GetStaticMethodID(cls, method, sig);
    if (!mid) { LOGE("CallbackBridge.%s tidak ketemu", method); if (attached) g_vm->DetachCurrentThread(); return; }
    // Varargs di-handle di caller via overload di bawah - fungsi ini tidak dipakai langsung, lihat flint_glfw_push_event
    if (attached) g_vm->DetachCurrentThread();
}
// Fungsi yang dipanggil flint_input.cpp - FORWARD, bukan buang.
extern "C" void flint_glfw_push_event(int type, int key, int button, int action, float x, float y, float dx, float dy) {
    if (!g_vm) { LOGE("flint_glfw_push_event: g_vm null, event type=%d hilang - JNI_OnLoad belum jalan", type); return; }
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    jclass cls = env->FindClass("com/flintclient/bridge/CallbackBridge");
    if (!cls) { if (attached) g_vm->DetachCurrentThread(); return; }
    if (type == 1) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushMouseButton", "(FFII)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, x, y, button, action);
    } else if (type == 2) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushKey", "(II)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, key, action);
    } else if (type == 3) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushScroll", "(FF)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, dx, dy);
    } else if (type == 4) {
        // Touch / mouse pos: kalau action 1/0 -> mouse button, kalau 2 -> mouse pos
        if (action == 2) {
            jmethodID mid = env->GetStaticMethodID(cls, "pushMousePos", "(FF)V");
            if (mid) env->CallStaticVoidMethod(cls, mid, x, y);
        } else {
            jmethodID mid = env->GetStaticMethodID(cls, "pushMouseButton", "(FFII)V");
            if (mid) env->CallStaticVoidMethod(cls, mid, x, y, button, action);
        }
    }
    if (env->ExceptionCheck()) { env->ExceptionDescribe(); env->ExceptionClear(); }
    if (attached) g_vm->DetachCurrentThread();
}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    g_vm = vm;
    LOGI("flint_glfw JNI_OnLoad OK, g_vm=%p", (void*)vm);
    return JNI_VERSION_1_6;
}
extern "C" {
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintGLFW_nativeInit(JNIEnv* env, jclass c) {
    if (!g_vm) env->GetJavaVM(&g_vm);
    LOGI("GLFW init: window %dx%d, CallbackBridge ready", g_width, g_height);
    g_startTime=0; flint_get_time(); g_shouldClose=false;
    return JNI_TRUE;
}
JNIEXPORT jdouble JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetTime(JNIEnv* env, jclass c) { return flint_get_time(); }
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativePollEvents(JNIEnv* env, jclass c) {
    // JANGAN buang event di sini. LWJGL Android poll via CallbackBridge.pollEvents() dari JVM thread.
    // Fungsi ini hanya untuk kompatibilitas lama - tidak nge-clear queue.
    LOGI("nativePollEvents dipanggil - event di-deliver via CallbackBridge, bukan di sini");
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativeTerminate(JNIEnv* env, jclass c) { LOGI("GLFW terminate"); g_shouldClose=false; }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetPendingEventCount(JNIEnv* env, jclass c) {
    jclass cls = env->FindClass("com/flintclient/bridge/CallbackBridge");
    if (!cls) return 0;
    jmethodID mid = env->GetStaticMethodID(cls, "getPendingCount", "()I");
    if (!mid) return 0;
    return env->CallStaticIntMethod(cls, mid);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativeSetWindowSize(JNIEnv* env, jclass c, jint w, jint h) {
    g_width=w; g_height=h;
    jclass cls = env->FindClass("com/flintclient/bridge/CallbackBridge");
    if (cls) { jmethodID mid = env->GetStaticMethodID(cls, "setWindowSize", "(II)V"); if (mid) env->CallStaticVoidMethod(cls, mid, w, h); }
}
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintGLFW_nativeShouldClose(JNIEnv* env, jclass c) { return g_shouldClose ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativeSetShouldClose(JNIEnv* env, jclass c, jboolean v) { g_shouldClose = (v==JNI_TRUE); }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetWidth(JNIEnv* env, jclass c) { return g_width; }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetHeight(JNIEnv* env, jclass c) { return g_height; }
}
