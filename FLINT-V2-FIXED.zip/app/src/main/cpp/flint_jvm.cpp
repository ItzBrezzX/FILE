// FLINT JVM - Arsitektur BENAR untuk Android (V2, Pojav pattern)
// BUG LAMA:
// 1. Mencampur JNIEnv ART dengan JNIEnv JVM baru. ART JNIEnv HANYA untuk copy string input, lalu RELEASE.
//    Setelah JNI_CreateJavaVM, HANYA pakai JNIEnv dari JVM baru.
//    Sebelumnya: env ART dipakai untuk gameArgs, lalu jvmEnv SetObjectArrayElement dengan jstring ART -> JNI DETECTED ERROR.
// 2. EGL dibuat di UI thread, JVM di IO thread. EGL context TIDAK bisa lintas thread.
//    Sekarang: JVM di DEDICATED pthread stack 8MB, EGL dibuat DI THREAD YANG SAMA sebelum Minecraft main.
// 3. Game args via jvmEnv->NewStringUTF, bukan ART env.
#include <jni.h>
#include <string>
#include <vector>
#include <dlfcn.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <android/log.h>
#include <android/native_window.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#define LOG_TAG "FLINT_JVM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
extern bool flint_egl_init_on_current_thread(ANativeWindow* window, int w, int h);
extern void flint_egl_destroy_on_current_thread();
static JavaVM* g_vm = nullptr;
static void* g_jvmHandle = nullptr;
typedef jint (*CreateJavaVM_t)(JavaVM**, void**, void*);
static CreateJavaVM_t g_createVM = nullptr;
static ANativeWindow* g_surfaceWindow = nullptr;
static jint g_jvmExitCode = 0;
static bool g_jvmRunning = false;
struct JvmLaunchParams {
    std::vector<std::string> jvmArgs;
    std::string classpath;
    std::string mainClassSlash;
    std::vector<std::string> gameArgs;
};
static void* jvm_thread_entry(void* arg) {
    auto* params = (JvmLaunchParams*)arg;
    LOGI("JVM thread started, tid=%ld", (long)gettid());
    std::vector<std::string> optStrings = params->jvmArgs;
    optStrings.push_back(std::string("-Djava.class.path=") + params->classpath);
    std::vector<JavaVMOption> options;
    for (auto &s : optStrings) { JavaVMOption o; o.optionString = (char*)s.c_str(); o.extraInfo = nullptr; options.push_back(o); }
    JavaVMInitArgs vmArgs; vmArgs.version = JNI_VERSION_1_8; vmArgs.nOptions = options.size(); vmArgs.options = options.data(); vmArgs.ignoreUnrecognized = JNI_TRUE;
    JNIEnv* jvmEnv = nullptr;
    if (!g_createVM) { LOGE("g_createVM null - nativeLoadJvmLib belum dipanggil"); g_jvmExitCode = -100; delete params; return nullptr; }
    jint res = g_createVM(&g_vm, (void**)&jvmEnv, &vmArgs);
    if (res != JNI_OK || !g_vm || !jvmEnv) { LOGE("JNI_CreateJavaVM failed %d", res); g_jvmExitCode = res; delete params; return nullptr; }
    LOGI("JVM created di JVM thread, JNIEnv=%p (INI yang dipakai, BUKAN ART JNIEnv)", (void*)jvmEnv);
    g_jvmRunning = true;
    if (g_surfaceWindow) {
        LOGI("Init EGL di JVM thread (bukan UI thread)");
        if (!flint_egl_init_on_current_thread(g_surfaceWindow, 0, 0)) {
            LOGE("EGL init di JVM thread GAGAL - BLOCKED");
            g_jvmExitCode = -200;
            g_vm->DestroyJavaVM(); g_vm = nullptr; g_jvmRunning = false; delete params; return nullptr;
        }
        LOGI("EGL OK di JVM thread");
    } else {
        LOGE("Surface null - EGL tidak bisa init. GameActivity harus pass Surface ke JNIVMLauncher.");
    }
    jclass mainCls = jvmEnv->FindClass(params->mainClassSlash.c_str());
    if (!mainCls) { LOGE("Main class %s tidak ketemu", params->mainClassSlash.c_str()); if (jvmEnv->ExceptionCheck()) jvmEnv->ExceptionDescribe(); g_jvmExitCode = -2; delete params; return nullptr; }
    jmethodID mainMethod = jvmEnv->GetStaticMethodID(mainCls, "main", "([Ljava/lang/String;)V");
    if (!mainMethod) { LOGE("main() tidak ketemu"); g_jvmExitCode = -3; delete params; return nullptr; }
    jclass strCls = jvmEnv->FindClass("java/lang/String");
    jobjectArray jargs = jvmEnv->NewObjectArray((jsize)params->gameArgs.size(), strCls, nullptr);
    for (size_t i=0;i<params->gameArgs.size();i++) {
        jstring s = jvmEnv->NewStringUTF(params->gameArgs[i].c_str());
        jvmEnv->SetObjectArrayElement(jargs, (jsize)i, s);
        jvmEnv->DeleteLocalRef(s);
    }
    LOGI("Calling Minecraft main %s dengan %zu args di JVM thread", params->mainClassSlash.c_str(), params->gameArgs.size());
    jvmEnv->CallStaticVoidMethod(mainCls, mainMethod, jargs);
    if (jvmEnv->ExceptionCheck()) { LOGE("Minecraft main threw"); jvmEnv->ExceptionDescribe(); jvmEnv->ExceptionClear(); g_jvmExitCode = -4; }
    else { LOGI("Minecraft main returned clean"); g_jvmExitCode = 0; }
    flint_egl_destroy_on_current_thread();
    jvmEnv->DeleteLocalRef(jargs);
    g_jvmRunning = false;
    delete params;
    return nullptr;
}
extern "C" {
JNIEXPORT jboolean JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_nativeLoadJvmLib(JNIEnv* env, jobject thiz, jstring jvmLibPath) {
    const char* path = env->GetStringUTFChars(jvmLibPath, nullptr);
    std::string pathStr = path ? path : "";
    env->ReleaseStringUTFChars(jvmLibPath, path);
    LOGI("Loading libjvm.so (Pojav Bionic) dari %s", pathStr.c_str());
    if (pathStr.find("adoptium") != std::string::npos || pathStr.find("temurin") != std::string::npos) {
        LOGE("REJECTED Adoptium libjvm.so - glibc, tidak kompatibel Bionic.");
        return JNI_FALSE;
    }
    g_jvmHandle = dlopen(pathStr.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (!g_jvmHandle) { LOGE("dlopen libjvm failed: %s", dlerror()); return JNI_FALSE; }
    g_createVM = (CreateJavaVM_t) dlsym(g_jvmHandle, "JNI_CreateJavaVM");
    if (!g_createVM) { LOGE("dlsym failed: %s", dlerror()); return JNI_FALSE; }
    LOGI("libjvm.so Pojav loaded OK");
    return JNI_TRUE;
}
JNIEXPORT void JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_nativeSetEnv(JNIEnv* env, jobject thiz, jstring key, jstring value) {
    const char* k = env->GetStringUTFChars(key, nullptr);
    const char* v = env->GetStringUTFChars(value, nullptr);
    if (k && v) setenv(k, v, 1);
    if (k) env->ReleaseStringUTFChars(key, k);
    if (v) env->ReleaseStringUTFChars(value, v);
}
JNIEXPORT void JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_nativeSetSurface(JNIEnv* env, jobject thiz, jobject surface) {
    if (g_surfaceWindow) { ANativeWindow_release(g_surfaceWindow); g_surfaceWindow = nullptr; }
    if (surface) { g_surfaceWindow = ANativeWindow_fromSurface(env, surface); LOGI("Surface disimpan untuk JVM thread"); }
}
JNIEXPORT jint JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_createJVM(JNIEnv* env, jobject thiz, jobjectArray jvmArgs, jstring classpath, jstring mainClass, jobjectArray gameArgs) {
    if (!g_createVM) { LOGE("createJVM sebelum nativeLoadJvmLib - BLOCKED"); return -100; }
    if (g_vm) { LOGE("JVM sudah jalan"); return -101; }
    auto* params = new JvmLaunchParams();
    jsize argc = env->GetArrayLength(jvmArgs);
    for (int i=0;i<argc;i++) { jstring s=(jstring)env->GetObjectArrayElement(jvmArgs,i); const char* c=env->GetStringUTFChars(s,nullptr); if(c) params->jvmArgs.emplace_back(c); env->ReleaseStringUTFChars(s,c); env->DeleteLocalRef(s); }
    { const char* c=env->GetStringUTFChars(classpath,nullptr); if(c) params->classpath=c; env->ReleaseStringUTFChars(classpath,c); }
    { const char* c=env->GetStringUTFChars(mainClass,nullptr); std::string mc=c?c:""; env->ReleaseStringUTFChars(mainClass,c); for(auto &ch: mc) if(ch=='.') ch='/'; params->mainClassSlash=mc; }
    jsize gargc = env->GetArrayLength(gameArgs);
    for (int i=0;i<gargc;i++) { jstring s=(jstring)env->GetObjectArrayElement(gameArgs,i); const char* c=env->GetStringUTFChars(s,nullptr); if(c) params->gameArgs.emplace_back(c); env->ReleaseStringUTFChars(s,c); env->DeleteLocalRef(s); }
    LOGI("Starting JVM di dedicated pthread (stack 8MB)");
    pthread_t thread; pthread_attr_t attr; pthread_attr_init(&attr); pthread_attr_setstacksize(&attr, 8*1024*1024);
    int r = pthread_create(&thread, &attr, jvm_thread_entry, params);
    pthread_attr_destroy(&attr);
    if (r!=0) { LOGE("pthread_create gagal %d", r); delete params; return -103; }
    pthread_join(thread, nullptr);
    LOGI("JVM thread joined, exitCode=%d", g_jvmExitCode);
    return g_jvmExitCode;
}
JNIEXPORT jboolean JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_isJVMRunning(JNIEnv* env, jobject thiz) { return g_jvmRunning ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT jint JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_destroyJVM(JNIEnv* env, jobject thiz) {
    if (!g_vm) return 0;
    jint r = g_vm->DestroyJavaVM(); g_vm=nullptr;
    if (g_jvmHandle) { dlclose(g_jvmHandle); g_jvmHandle=nullptr; g_createVM=nullptr; }
    if (g_surfaceWindow) { ANativeWindow_release(g_surfaceWindow); g_surfaceWindow=nullptr; }
    return r;
}
JNIEXPORT void JNICALL Java_com_flintclient_core_launch_JNIVMLauncher_setEnvVars(JNIEnv* env, jobject thiz, jobject map) { LOGI("setEnvVars deprecated"); }
}
