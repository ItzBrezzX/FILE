package com.flintclient.core.launch

import android.content.Context
import com.flintclient.core.assets.AssetManager
import com.flintclient.core.auth.AuthManager
import com.flintclient.core.config.ConfigManager
import com.flintclient.core.instance.GameInstanceManager
import com.flintclient.core.java.JavaRuntimeManager
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.natives.NativeLibraryManager
import com.flintclient.core.natives.LWJGLManager
import com.flintclient.core.renderer.MobileGLUESManager
import com.flintclient.core.renderer.RendererType
import android.view.Surface
import com.flintclient.core.renderer.RendererManager
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.LibraryResolver
import com.flintclient.core.version.VersionCompatibility
import com.flintclient.core.version.VersionManager
import com.flintclient.bridge.BridgeClasspath
import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

sealed class LaunchState {
    object Idle : LaunchState()
    data class Preparing(val step: String, val progress: Int) : LaunchState()
    data class Running(val pid: Long) : LaunchState()
    data class Failed(val error: String) : LaunchState()
    object Exited : LaunchState()
}

class LaunchManager(
    private val context: Context,
    private val storage: StorageManager,
    private val configManager: ConfigManager,
    private val versionManager: VersionManager,
    private val authManager: AuthManager,
    private val instanceManager: GameInstanceManager,
    private val javaManager: JavaRuntimeManager,
    private val assetManager: AssetManager,
    private val nativeManager: NativeLibraryManager
) {
    var onState: (LaunchState) -> Unit = {}
    @Volatile private var isRunning = false
    @Volatile var pendingSurface: Surface? = null
    fun setSurface(s: Surface) { pendingSurface = s; try { JNIVMLauncher.nativeSetSurface(s) } catch (e: Throwable) { FlintLogger.e("Launch", "setSurface gagal: " + (e.message ?: "")) } }

    // PLAY pipeline - 17 steps from spec. Each step logs + reports progress. Any failure -> LaunchState.Failed with REAL reason, never silent.
    suspend fun prepareAndLaunch(instanceId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            // 1. Validate instance
            onState(LaunchState.Preparing("1/17 Validasi instance", 3))
            val instance = instanceManager.getInstance(instanceId) ?: instanceManager.getOrCreateDefault()
            val versionId = instance.minecraftVersion
            FlintLogger.i("Launch", "PLAY instance=${instance.id} version=$versionId")
            // 2. Validate Java runtime - must be installed + libjvm.so exists
            onState(LaunchState.Preparing("2/17 Validasi Java Runtime", 8))
            val javaMajor = VersionCompatibility.getCompatibility(versionId).javaMajor
            if (!javaManager.isRuntimeInstalled(javaMajor)) {
                FlintLogger.i("Launch", "Java $javaMajor belum ada, download...")
                onState(LaunchState.Preparing("Download Java $javaMajor...", 10))
                val ok = javaManager.downloadRuntime(javaMajor) { p -> onState(LaunchState.Preparing("Download Java $javaMajor $p%", 10)) }
                if (!ok) { fail("Java $javaMajor gagal di-download / libjvm.so tidak ditemukan. BLOCKED - cek internet + storage."); return@withContext false }
            }
            val libJvmSo = javaManager.libJvmSoFor(javaMajor)!!
            FlintLogger.i("Launch", "Java $javaMajor OK: ${libJvmSo.absolutePath}")
            // 3. Validate account/session - NEVER bypass auth
            onState(LaunchState.Preparing("3/17 Validasi akun Microsoft", 15))
            val session = authManager.getActiveSession()
            if (session == null || session.accessToken.isBlank()) {
                fail("Belum login Microsoft. Login dulu di Accounts - FLINT tidak bypass auth."); return@withContext false
            }
            if (authManager.isSessionExpired(session)) {
                FlintLogger.i("Launch", "Session expired, refresh...")
                val refreshed = try { authManager.refreshSession(session) } catch (e: Exception) { null }
                if (refreshed == null) { fail("Session expired dan refresh gagal. Login ulang."); return@withContext false }
            }
            // 4. Resolve version
            onState(LaunchState.Preparing("4/17 Resolve version $versionId", 20))
            var version = versionManager.loadVersionJson(versionId)
            if (version == null) {
                val manifest = versionManager.fetchManifest()
                val entry = manifest.versions.firstOrNull { it.id == versionId } ?: run { fail("Version $versionId tidak ada di manifest Mojang"); return@withContext false }
                versionManager.installVersion(entry) { _, p -> onState(LaunchState.Preparing("Download client.jar $p%", 22)) }
                version = versionManager.loadVersionJson(versionId) ?: run { fail("version.json gagal dimuat setelah install"); return@withContext false }
            }
            if (version.inheritsFrom != null) {
                val parent = versionManager.loadVersionJson(version.inheritsFrom!!)
                if (parent != null) version = versionManager.resolveInheritance(version, parent)
            }
            // 5. Download missing libraries
            onState(LaunchState.Preparing("5/17 Download libraries", 30))
            val downloadEngine = DownloadEngine()
            for (lib in version.libraries) {
                if (!LibraryResolver.isLibraryAllowed(lib)) continue
                lib.downloads?.artifact?.let { art ->
                    val dest = File(storage.librariesDir, art.path)
                    if (!dest.exists() || dest.length() != art.size) {
                        FlintLogger.i("Launch", "Download lib ${art.path}")
                        downloadEngine.download(DownloadTask(art.url, dest, art.sha1, art.size))
                    }
                }
            }
            // 6. Download missing assets
            onState(LaunchState.Preparing("6/17 Download assets", 40))
            try { assetManager.ensureAssets(version) } catch (e: Exception) { FlintLogger.e("Launch", "Assets gagal: ${e.message} - lanjut, mungkin offline tapi assets sudah ada sebagian") }
            // 7. Extract required natives
            onState(LaunchState.Preparing("7/17 Extract natives", 48))
            val nativesDir = File(storage.gameDir, "natives/$versionId")
            nativesDir.mkdirs()
            nativeManager.extractNatives(version, nativesDir)
            // 8. Build complete classpath
            onState(LaunchState.Preparing("8/17 Build classpath", 55))
            val classpathFiles = mutableListOf<File>()
            classpathFiles.add(File(storage.versionDir(versionId), "$versionId.jar"))
            for (lib in version.libraries) {
                if (!LibraryResolver.isLibraryAllowed(lib)) continue
                lib.downloads?.artifact?.let { art -> classpathFiles.add(File(storage.librariesDir, art.path)) }
            }
            val missing = classpathFiles.filter { !it.exists() }
            if (missing.isNotEmpty()) { fail("Classpath missing ${missing.size} files: ${missing.take(3).map { it.name }}"); return@withContext false }
            // classpath final dibuat di step 12a setelah LWJGL Android disisipkan - jangan define di sini
            val baseClasspathForCheck = classpathFiles.joinToString(":") { it.absolutePath }
            // 9+10. JVM + Game args dari version.json (LaunchArguments) - JANGAN hardcode, Mojang JSON yang benar.
            // Hardcode lama: --username/--version/... manual, mengabaikan version.arguments.game/jvm -> 1.21+ gagal karena arg baru (quickPlay, dll) hilang.
            onState(LaunchState.Preparing("9/17 JVM args", 60))
            val safeRam = com.flintclient.core.performance.PerformanceOptimizer.getSafeRamMb(context, configManager.config.ramMb)
            val jvmArgs = mutableListOf<String>()
            jvmArgs.add("-Xmx${safeRam}m")
            jvmArgs.add("-Xms${safeRam/2}m")
            jvmArgs.add("-XX:+UseG1GC")
            jvmArgs.add("-XX:MaxGCPauseMillis=200")
            jvmArgs.add("-Djava.library.path=${nativesDir.absolutePath}:${storage.nativeLibDir}:${java.io.File(storage.rootDir, "renderer").absolutePath}")
            jvmArgs.add("-Dflint.fullbright=${configManager.config.fullbright}")
            jvmArgs.add("-Dorg.lwjgl.librarypath=${nativesDir.absolutePath}")
            jvmArgs.add("-Dminecraft.launcher.brand=FLINT-CLIENT")
            jvmArgs.add("-Dminecraft.launcher.version=1.0.1-flint-repaired")
            // Pojav full --add-opens untuk Java 17+ / 21. Hanya 2 opens lama -> 1.21 crash IllegalAccess di java.lang.invoke / java.nio.
            if (javaMajor >= 17) {
                val opens = listOf("java.base/java.lang","java.base/java.lang.invoke","java.base/java.lang.reflect","java.base/java.io","java.base/java.net","java.base/java.nio","java.base/java.util","java.base/java.util.concurrent","java.base/sun.nio.ch","java.base/sun.nio.cs","java.base/sun.security.action","java.base/sun.util.calendar","java.base/java.text","java.base/java.time")
                for (o in opens) { jvmArgs.add("--add-opens"); jvmArgs.add("$o=ALL-UNNAMED") }
                jvmArgs.add("--add-exports"); jvmArgs.add("java.base/sun.nio.ch=ALL-UNNAMED")
            }
            // Mojang JVM args dari version.json (misal -Dos.name, -Djava.library.path) - filter yang desktop-only
            version.arguments?.jvm?.forEach { arg ->
                if (arg is String) {
                    if (arg.contains("launcher") || arg.contains("classpath")) return@forEach // sudah ditangani LaunchArguments / classpath kita
                    val replaced = LaunchArguments.replacePlaceholders(arg, configManager.config, version, nativesDir, "", storage)
                    if (replaced.isNotBlank() && !jvmArgs.contains(replaced)) jvmArgs.add(replaced)
                }
            }
            onState(LaunchState.Preparing("10/17 Game args", 65))
            // Pakai LaunchArguments.buildGameArgs yang baca version.arguments.game + minecraftArguments legacy
            val mcAccount = com.flintclient.core.auth.MinecraftAccount(username = session.username, uuid = session.uuid, accessToken = session.accessToken, type = if (session.accessToken == "offline") "offline" else "microsoft")
            val gameArgs = try {
                LaunchArguments.buildGameArgs(configManager.config, instance, version, mcAccount, storage.gameDir, storage.assetsDir, version.assetIndex.id)
            } catch (e: Exception) {
                FlintLogger.e("Launch", "LaunchArguments.buildGameArgs gagal, fallback hardcode: ${e.message}")
                mutableListOf("--username", session.username, "--version", versionId, "--gameDir", storage.gameDir.absolutePath, "--assetsDir", storage.assetsDir.absolutePath, "--assetIndex", version.assetIndex.id, "--uuid", session.uuid, "--accessToken", session.accessToken, "--userType", "msa", "--versionType", "release")
            }
            if (gameArgs.isEmpty()) { fail("Game args kosong - version.json arguments.game tidak bisa diparse"); return@withContext false }
            // 11. Working dir
            onState(LaunchState.Preparing("11/17 Working dir", 68))
            storage.gameDir.mkdirs()
            // 12. Native library paths
            onState(LaunchState.Preparing("12/17 Native paths", 70))
            // FIX 5+6 V2: LWJGL Android HARUS pertama, Renderer HARUS di-load SEBELUM JVM
            onState(LaunchState.Preparing("12a/17 LWJGL Android (Pojav lwjgl3)", 72))
            val lwjglMgr = LWJGLManager(storage)
            val lwjglOk = lwjglMgr.ensureLWJGLAndroid()
            if (!lwjglOk) { fail("LWJGL Android gagal di-download - cek https://github.com/PojavLauncherTeam/lwjgl3/releases - BLOCKED"); return@withContext false }
            // Classpath dengan LWJGL Android di depan (buang LWJGL desktop duplikat)
            val classpathWithLWJGL = lwjglMgr.buildClasspathWithLWJGLAndroidFirst(classpathFiles)
            // BRIDGE JAR WAJIB pertama, sebelum LWJGL - kalau tidak ada, FAIL jelas, jangan lanjut (sebelumnya tidak pernah ditambah -> ClassNotFound CallbackBridge)
            val classpathWithBridge = BridgeClasspath.withBridgeJar(classpathWithLWJGL, context.filesDir, context)
            if (classpathWithBridge == null) { fail("flint-bridge.jar tidak ditemukan di assets/filesDir. Jalankan ./gradlew buildBridgeJar lalu copy ke app/src/main/assets/flint-bridge.jar - BLOCKED"); return@withContext false }
            val classpath = classpathWithBridge.joinToString(":") { it.absolutePath }
            FlintLogger.i("Launch", "Classpath LWJGL Android pertama: " + classpathWithLWJGL.firstOrNull()?.name + ", total " + classpathWithLWJGL.size + " jars")
            // Renderer - FIX: pickBestRenderer returns RendererType (enum), NOT String. Do NOT call .lowercase() on enum.
            onState(LaunchState.Preparing("12b/17 Renderer MobileGLUES/GL4ES", 74))
            val rendererType: RendererType = RendererManager.pickBestRenderer(context, versionId, com.flintclient.core.performance.PerformanceOptimizer.isLowEndDevice(context))
            RendererManager.logRendererChoice(rendererType, versionId)
            val rendererOk = MobileGLUESManager.ensureRenderer(storage, rendererType)
            if (!rendererOk) { fail("Renderer " + rendererType + " gagal di-download - BLOCKED"); return@withContext false }
            if (!MobileGLUESManager.loadRendererSo(storage, rendererType)) { fail("Renderer .so gagal di-load - BLOCKED"); return@withContext false }
            val env = RendererManager.getRendererEnv(rendererType, storage.nativeLibDir) + MobileGLUESManager.getRendererEnv(storage, rendererType) + mapOf(
                "FLINT_VERSION" to versionId,
                "FLINT_GAME_DIR" to storage.gameDir.absolutePath
            )
            // 13-16. Init JNI JVM + LWJGL + Graphics - done inside GameActivity EGL init + here via JNIVMLauncher (blocking call on IO thread)
            onState(LaunchState.Preparing("13/17 Init JNI JVM...", 78))
            isRunning = true
            onState(LaunchState.Running(-1))
            // 17. Invoke Minecraft main - BLOCKING until game exits
            val result = JNIVMLauncher.launch(libJvmSo.absolutePath, jvmArgs, classpath, version.mainClass, gameArgs, env, pendingSurface)
            isRunning = false
            if (result != 0) { fail("Minecraft exited with code $result - cek logcat FLINT_JVM / CrashReporter"); return@withContext false }
            onState(LaunchState.Exited)
            true
        } catch (e: Exception) {
            FlintLogger.e("Launch", "prepareAndLaunch FAILED: ${e.message}")
            e.printStackTrace()
            fail("Launch gagal: ${e.message} - ${e.javaClass.simpleName}")
            false
        }
    }
    private fun fail(msg: String) {
        FlintLogger.e("Launch", msg)
        onState(LaunchState.Failed(msg))
    }
    fun stopGame() {
        if (isRunning) {
            try { JNIVMLauncher.destroyJVM() } catch (e: Exception) { FlintLogger.e("Launch", "destroyJVM failed: ${e.message}") }
            isRunning = false
        }
    }
    fun isRunning(): Boolean = isRunning
}
