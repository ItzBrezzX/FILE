# Playable Checklist (12)
1 App kebuka main tanpa crash
2 Settings + diagnostik
3 Instance + version download SHA1 OK
4 JRE ARM64 ada
5 Natives ada
6 PLAY -> Surface+EGL+GL4ES
7 JLI jalan, TITLE_SCREEN
8 World single-player, fps>0
9 Input joystick/tap/jump/inventory/pause
10 Audio ada / silent tanpa crash
11 STOP -> balik main
12 Rotate/pause/resume tanpa crash
Build NOT RUN, Device NOT TESTED, Playable NOT CLAIMED sampai checklist lolos di device.
