# Native
- flint_jli_bridge.c: JLI_Launch via dlopen libjli.so, lazy, no init on load.
- flint_egl_bridge.c: docs, real EGL via EGL14 Kotlin.
- lwjgl_glfw_stub.c: forwards to libglfw.so.
- Build via CMake in real CI (lihat .github/workflows/build.yml + native/CMakeLists.txt).
