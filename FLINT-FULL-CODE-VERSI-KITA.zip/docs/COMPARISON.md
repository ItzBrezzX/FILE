# FLINT vs Pojav/Mojo/Zenith
Pojav: proof JLI in-process + GLFW stub + GL4ES + input pipe native. Mojo: Pojav hidup + 7 renderer + SDL + instance + mrpack. Zenith: Pojav iOS + Zinc/LTW/Vulkan + SDL3 WIP. FLINT: full code ini - arsitektur sama, kode sendiri, package com.flintlauncher.android.
