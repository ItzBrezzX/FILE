# Build via GitHub Actions
1. Push branch feature/flint-native-window-bridge
2. Actions -> FLINT Build -> Run
3. Download artifact flint-debug-apk
4. Install di itel A665L Android 13, test 12 checklist di docs/PLAYABLE_CHECKLIST.md
