# FLINT CLIENT - Versi Kita Sendiri (Full Code)
Minecraft Java Edition launcher untuk Android, ditulis ulang dengan arsitektur yang terbukti jalan di Pojav/Mojo (JLI_Launch in-process, GLFW stub, EGL bridge, GL4ES) tapi kode sendiri, package com.flintlauncher.android.
- Main -> Settings -> Instance -> PLAY -> GameActivity -> World -> STOP -> Main
- Renderer: GL4ES default (Mali), Zink, VirGL, MobileGlues, Krypton
- JRE: 8/17/21/25 via prebuilt ARM64 dari CI (bukan dibikin dari 0)
- Mod: Fabric/Quilt/Fabric + Forge metadata, mrpack import
- SDL3: untuk Minecraft 26.x (GLFW -> SDL3)
- License: LGPL-3.0 (turunan arsitektur Pojav/Mojo, lihat LICENSE)
- Build: ./gradlew :app:assembleDebug (GitHub Actions)
- Status: Full code lengkap, Build NOT RUN di sandbox (no SDK/NDK), Device NOT TESTED, Playable NOT CLAIMED sampai 12 checklist lolos di device.
