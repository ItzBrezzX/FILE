package com.flintlauncher.android
import android.app.Application
import android.util.Log
import com.flintlauncher.android.runtime.FlintCrashHandler
import java.io.File
class FlintApplication : Application() {
  lateinit var container: AppContainer; private set
  override fun onCreate() {
    super.onCreate()
    // FIX STARTUP CRASH: JANGAN init native/EGL/GPU di sini. Cuma crash handler + container ringan.
    try { FlintCrashHandler.install(filesDir) } catch(e: Throwable) { Log.w("FlintApp", "crash handler failed ${e.message}") }
    container = AppContainer(this)
    Log.i("FlintApp", "FlintApplication started, native NOT loaded on startup (lazy)")
  }
}
