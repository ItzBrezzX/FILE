package com.flintlauncher.android
import android.content.Context
import com.flintlauncher.android.minecraft.FlintInstanceSystem
import com.flintlauncher.android.runtime.FlintRendererSelector
import com.flintlauncher.android.runtime.FlintSafeStartup
import java.io.File
class AppContainer(ctx: Context) {
  val appContext: Context = ctx.applicationContext
  val filesDir: File = ctx.filesDir
  val instancesRoot: File = File(filesDir, "flint")
  val rendererSelector = FlintRendererSelector
  val safeStartup = FlintSafeStartup
  fun instancesDir(): File { val d = File(instancesRoot, "instances"); d.mkdirs(); return d }
  fun diagnostics(): String { val native = safeStartup.probeNativeLazy(); val jre = File(filesDir, "runtime/java-21/lib/libjli.so").exists(); val inst = FlintInstanceSystem.list(instancesRoot).size; return "FLINT diag: native=$native jre21=$jre instances=$inst main=OK" }
}
