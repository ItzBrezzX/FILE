package com.flintlauncher.android
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.flintlauncher.android.feature.launch.GameActivity
import com.flintlauncher.android.feature.settings.SettingsActivity
import com.flintlauncher.android.minecraft.FlintInstanceSystem
import java.io.File
class MainActivity : AppCompatActivity() {
  private lateinit var container: AppContainer
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // JANGAN init GPU/native di sini - ini penyebab crash lama.
    container = (application as FlintApplication).container
    val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
    val title = TextView(this).apply { text = "FLINT CLIENT"; textSize = 28f }
    val status = TextView(this).apply { text = "Siap. Pilih instance lalu PLAY."; textSize = 14f }
    val instanceList = ListView(this)
    val btnPlay = Button(this).apply { text = "PLAY" }
    val btnInstance = Button(this).apply { text = "+ Instance Baru (1.21.1)" }
    val btnSettings = Button(this).apply { text = "Settings / Diagnostik" }
    val btnMods = Button(this).apply { text = "Mod Menu" }
    layout.addView(title); layout.addView(status); layout.addView(instanceList); layout.addView(btnPlay); layout.addView(btnInstance); layout.addView(btnSettings); layout.addView(btnMods)
    setContentView(layout)
    fun refresh() {
      val inst = FlintInstanceSystem.list(container.instancesRoot)
      instanceList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, inst.map { "${it.name} - ${it.versionId} - ${it.renderer}" }.ifEmpty { listOf("Belum ada instance - buat dulu") })
      status.text = if (inst.isEmpty()) "Belum ada instance. Buat instance 1.21.1 dulu." else "Instance: ${inst.size} - pilih PLAY untuk main."
    }
    refresh()
    btnInstance.setOnClickListener { FlintInstanceSystem.create(container.instancesRoot, "main-${System.currentTimeMillis()}", "Main", "1.21.1", "GL4ES", 21); refresh(); Toast.makeText(this, "Instance dibuat", Toast.LENGTH_SHORT).show() }
    btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    btnMods.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java).putExtra("tab", "mods")) }
    btnPlay.setOnClickListener {
      val inst = FlintInstanceSystem.list(container.instancesRoot).firstOrNull()
      if (inst == null) { Toast.makeText(this, "Buat instance dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
      val i = Intent(this, GameActivity::class.java).apply { putExtra("instanceId", inst.id); putExtra("versionId", inst.versionId); putExtra("renderer", inst.renderer) }
      startActivity(i)
    }
  }
}
