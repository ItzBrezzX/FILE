package com.flintlauncher.android.feature.settings
import android.app.Activity
import android.os.Bundle
import android.widget.*
import com.flintlauncher.android.runtime.*
import java.io.File
class SettingsActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
    val title = TextView(this).apply { text = "FLINT Settings / Mod Menu"; textSize = 22f }
    val diag = TextView(this).apply { text = "Tekan Diagnostik untuk cek." }
    val btnDiag = Button(this).apply { text = "Diagnostik" }
    val btnRenderer = Button(this).apply { text = "Renderer: GL4ES (Mali)" }
    val btnJre = Button(this).apply { text = "Cek JRE" }
    layout.addView(title); layout.addView(diag); layout.addView(btnDiag); layout.addView(btnRenderer); layout.addView(btnJre)
    setContentView(layout)
    var current = FlintRenderer.GL4ES
    btnDiag.setOnClickListener { val n = FlintSafeStartup.probeNativeLazy(); val jre = File(filesDir, "runtime/java-21/lib/libjli.so").exists(); diag.text = "native=$n jre21=$jre renderer=$current main=OK" }
    btnRenderer.setOnClickListener { current = when(current) { FlintRenderer.GL4ES -> FlintRenderer.ZINK; FlintRenderer.ZINK -> FlintRenderer.VIRGL; FlintRenderer.VIRGL -> FlintRenderer.MOBILE_GLUES; else -> FlintRenderer.GL4ES }; btnRenderer.text = "Renderer: $current"; diag.text = "Renderer diubah ke $current (dipakai di PLAY berikutnya)" }
    btnJre.setOnClickListener { val f = File(filesDir, "runtime/java-21/lib/libjli.so"); diag.text = if (f.exists()) "JRE 21 ketemu: ${f.path}" else "JRE 21 TIDAK ada - download JRE ARM64 ke runtime/java-21" }
  }
}
