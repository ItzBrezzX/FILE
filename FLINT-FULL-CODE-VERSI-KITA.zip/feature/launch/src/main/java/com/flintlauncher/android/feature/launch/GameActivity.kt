package com.flintlauncher.android.feature.launch
import android.app.Activity
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.*
import com.flintlauncher.android.runtime.*
import com.flintlauncher.android.minecraft.*
import java.io.File
import kotlin.concurrent.thread
class GameActivity : Activity(), SurfaceHolder.Callback {
  private lateinit var surfaceMgr: EglGameSurfaceManager
  private lateinit var input: FlintInputDispatcher
  private var loop: FlintGameLoop? = null
  private var jliThread: Thread? = null
  private var statusTv: TextView? = null
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    surfaceMgr = EglGameSurfaceManager(); input = FlintInputDispatcher()
    val root = FrameLayout(this)
    val surfaceView = SurfaceView(this); surfaceView.holder.addCallback(this); root.addView(surfaceView)
    val overlay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    statusTv = TextView(this).apply { text = "FLINT - siap"; setBackgroundColor(0x88000000); setTextColor(0xFFFFFFFF) }
    val btnJump = Button(this).apply { text = "JUMP" }; val btnAttack = Button(this).apply { text = "ATTACK" }; val btnUse = Button(this).apply { text = "USE" }; val btnInv = Button(this).apply { text = "INV" }; val btnPause = Button(this).apply { text = "PAUSE" }; val btnStop = Button(this).apply { text = "STOP" }
    btnJump.setOnClickListener { FlintTouchControls.jump(input) }; btnAttack.setOnClickListener { FlintTouchControls.tapAttack(input) }; btnUse.setOnClickListener { FlintTouchControls.tapUse(input) }; btnInv.setOnClickListener { FlintTouchControls.openInventory(input) }; btnPause.setOnClickListener { FlintTouchControls.pause(input) }; btnStop.setOnClickListener { stopGame() }
    overlay.addView(statusTv); overlay.addView(btnJump); overlay.addView(btnAttack); overlay.addView(btnUse); overlay.addView(btnInv); overlay.addView(btnPause); overlay.addView(btnStop)
    root.addView(overlay); setContentView(root)
    // Joystick sederhana: sentuh area kiri bawah -> gerak. Diimplementasi via OnTouchListener di surfaceView.
    surfaceView.setOnTouchListener { _, ev -> val x = (ev.x / width.coerceAtLeast(1) * 2 - 1); val y = (ev.y / height.coerceAtLeast(1) * 2 - 1); FlintTouchControls.joystickToMove(x, y, input); true }
  }
  override fun surfaceCreated(holder: SurfaceHolder) {}
  override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
    val versionId = intent.getStringExtra("versionId") ?: "1.21.1"
    val rendererName = intent.getStringExtra("renderer") ?: "GL4ES"
    val renderer = FlintRendererSelector.parse(rendererName)
    thread(name = "Flint-Launch") {
      try {
        runOnUiThread { statusTv?.text = "FLINT: EGL + renderer $renderer..." }
        FlintEglBridge.applyRendererEnv(renderer); FlintSdl3Bridge.initIfNeeded(versionId); FlintAudioBridge.init()
        val ok = surfaceMgr.createFromSurface(holder.surface, renderer)
        if (!ok) { runOnUiThread { statusTv?.text = "EGL gagal - cek Surface / renderer"; Toast.makeText(this, "EGL gagal", Toast.LENGTH_LONG).show() }; return@thread }
        loop = FlintGameLoop(surfaceMgr, input); loop?.start()
        runOnUiThread { statusTv?.text = "FLINT: Game jalan - $renderer - $versionId" }
        // JLI launch di thread ini (game thread), bukan UI thread.
        val filesDir = this.filesDir; val instanceId = intent.getStringExtra("instanceId") ?: "main"
        val instDir = File(filesDir, "flint/instances/$instanceId")
        val inst = FlintInstanceSystem.find(File(filesDir, "flint"), instanceId) ?: FlintInstance(instanceId, "Main", versionId, instDir, rendererName, 21)
        val ready = FlintGameLauncher.checkReady(filesDir, inst)
        if (!ready.ok) { runOnUiThread { statusTv?.text = ready.error; Toast.makeText(this, ready.error, Toast.LENGTH_LONG).show() }; return@thread }
        val env = FlintGameLauncher.buildEnv(renderer)
        val args = FlintJliLauncher.buildJvmArgs(filesDir, inst.javaVersion, instDir, "minecraft-client.jar", "net.minecraft.client.main.Main", listOf("--username","Player","--version", versionId, "--gameDir", instDir.absolutePath, "--assetsDir", File(filesDir, "flint/assets").absolutePath, "--assetIndex", versionId), env)
        if (FlintNativeBridge.load()) { FlintJliLauncher.nativeJliLaunch(args.toTypedArray()) } else { runOnUiThread { statusTv?.text = "Native JLI tidak ada - game belum bisa jalan, cek natives" } }
      } catch(e: Throwable) { runOnUiThread { statusTv?.text = "Launch gagal: ${e.message}" } }
    }
  }
  override fun surfaceDestroyed(holder: SurfaceHolder) { stopGame() }
  private fun stopGame() { try { loop?.stop(); surfaceMgr.releaseOnOwnerThread(); } catch(e: Throwable) {} ; finish() }
  override fun onPause() { super.onPause(); /* jangan release EGL di onPause, cuma pause loop kalo perlu */ }
  override fun onDestroy() { try { loop?.stop(); surfaceMgr.releaseOnOwnerThread() } catch(e: Throwable) {}; super.onDestroy() }
}
