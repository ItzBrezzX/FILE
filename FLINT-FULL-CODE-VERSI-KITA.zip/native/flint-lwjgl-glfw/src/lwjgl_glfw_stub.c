// LWJGL GLFW stub - forwards to libglfw.so, supports 1.13+ (Pojav pattern, rewritten).
#include <jni.h>
#include <android/log.h>
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* r) { (void)vm; (void)r; __android_log_print(ANDROID_LOG_INFO, "FlintGLFW", "lwjgl_glfw stub loaded"); return JNI_VERSION_1_6; }
