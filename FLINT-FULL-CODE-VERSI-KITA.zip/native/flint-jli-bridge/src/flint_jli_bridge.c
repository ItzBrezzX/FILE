// Flint JLI bridge - JNI_OnLoad MUST NOT init EGL/JVM. Lazy only.
// Provides nativeJliLaunch, nativeKey, nativeMouseButton, nativeCursor, nativeScroll.
// Full JLI_Launch via libjli.so dlopen in real build (see docs/NATIVE.md).
#include <jni.h>
#include <android/log.h>
#define TAG "FlintJLI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* r) { (void)vm; (void)r; LOGI("flint_jli_bridge loaded - no JVM/EGL init on load"); return JNI_VERSION_1_6; }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintJliLauncher_nativeJliLaunch(JNIEnv* env, jobject thiz, jobjectArray args) { (void)env; (void)thiz; (void)args; LOGI("nativeJliLaunch called - needs libjli.so + JRE at runtime"); return -1; }
JNIEXPORT void JNICALL Java_com_flintlauncher_android_runtime_FlintNativeBridge_nativeKey(JNIEnv* env, jobject thiz, jint code, jint action, jint mods) { (void)env; (void)thiz; (void)code; (void)action; (void)mods; }
JNIEXPORT void JNICALL Java_com_flintlauncher_android_runtime_FlintNativeBridge_nativeMouseButton(JNIEnv* env, jobject thiz, jint btn, jint action, jint mods) { (void)env; (void)thiz; (void)btn; (void)action; (void)mods; }
JNIEXPORT void JNICALL Java_com_flintlauncher_android_runtime_FlintNativeBridge_nativeCursor(JNIEnv* env, jobject thiz, jdouble x, jdouble y) { (void)env; (void)thiz; (void)x; (void)y; }
JNIEXPORT void JNICALL Java_com_flintlauncher_android_runtime_FlintNativeBridge_nativeScroll(JNIEnv* env, jobject thiz, jdouble dx, jdouble dy) { (void)env; (void)thiz; (void)dx; (void)dy; }
