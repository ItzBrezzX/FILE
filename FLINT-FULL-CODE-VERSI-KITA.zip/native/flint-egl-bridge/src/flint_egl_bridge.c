// Flint EGL bridge - docs only, real EGL via EGL14 in EglGameSurfaceManager.kt.
// JNI_OnLoad must not init EGL.
#include <jni.h>
#include <android/log.h>
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* r) { (void)vm; (void)r; __android_log_print(ANDROID_LOG_INFO, "FlintEGL", "flint_egl_bridge loaded - no EGL init"); return JNI_VERSION_1_6; }
