package com.flintlauncher.android.versions
import java.io.File
import java.net.URL
import java.security.MessageDigest
object VersionCatalog {
  const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
  fun sha1(f: File): String { val d = MessageDigest.getInstance("SHA-1"); f.inputStream().use { var b = it.read(); while(b!=-1) { d.update(b.toByte()); b=it.read() } }; return d.digest().joinToString("") { "%02x".format(it) } }
  fun download(url: String, dest: File, expectedSha1: String?): Boolean { dest.parentFile?.mkdirs(); URL(url).openStream().use { inp -> dest.outputStream().use { out -> inp.copyTo(out) } }; if (expectedSha1!=null) { val got = sha1(dest); if (got!=expectedSha1) { dest.delete(); throw IllegalStateException("SHA1 mismatch $got != $expectedSha1") } }; return true }
}
