package com.flintlauncher.android.minecraft
import android.util.Log
import com.flintlauncher.android.runtime.*
import java.io.File
/** Single pipeline: cek JRE -> cek natives -> EGL -> renderer -> JLI -> log watcher TITLE_SCREEN. */
object FlintGameLauncher {
  data class Ready(val ok: Boolean, val error: String?)
  fun checkReady(filesDir: File, instance: FlintInstance): Ready {
    val jli = FlintJliLauncher.findJli(filesDir, instance.javaVersion)
    if (jli == null) return Ready(false, "JRE tidak ditemukan. Download JRE ARM64 ke runtime/java-${instance.javaVersion}")
    val natives = File(instance.dir, "natives")
    if (!File(natives, "libglfw.so").exists() && !File(filesDir, "game/natives/libglfw.so").exists()) return Ready(false, "Natives libglfw.so tidak ditemukan. Download natives dulu.")
    if (!instance.dir.exists()) return Ready(false, "Instance dir tidak ada")
    return Ready(true, null)
  }
  fun buildEnv(renderer: FlintRenderer): Map<String,String> = FlintRendererSelector.envFor(renderer)
  fun logWatcherReady(logFile: File, timeoutMs: Long = 90_000): Boolean { val start = System.currentTimeMillis(); while (System.currentTimeMillis()-start < timeoutMs) { try { if (logFile.exists() && logFile.readText().contains("TITLE_SCREEN")) return true } catch(e: Throwable) {}; Thread.sleep(500) }; Log.w("FlintLaunch","log watcher timeout, TITLE_SCREEN tidak ketemu"); return false }
}
