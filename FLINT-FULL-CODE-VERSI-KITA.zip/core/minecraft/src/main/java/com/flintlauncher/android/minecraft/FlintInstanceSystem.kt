package com.flintlauncher.android.minecraft
import java.io.File
data class FlintInstance(val id: String, val name: String, val versionId: String, val dir: File, val renderer: String, val javaVersion: Int)
object FlintInstanceSystem {
 fun create(root: File, id: String, name: String, versionId: String, renderer: String, javaVersion: Int): FlintInstance { val dir = File(root, "instances/$id"); dir.mkdirs(); File(dir, "mods").mkdirs(); File(dir, "saves").mkdirs(); val inst = FlintInstance(id, name, versionId, dir, renderer, javaVersion); File(dir, "instance.json").writeText("{\"id\":\"$id\",\"name\":\"$name\",\"version\":\"$versionId\",\"renderer\":\"$renderer\",\"java\":$javaVersion}"); return inst }
 fun list(root: File): List<FlintInstance> { val base = File(root, "instances"); if (!base.exists()) return emptyList(); return base.listFiles()?.filter { it.isDirectory && File(it, "instance.json").exists() }?.map { d -> val t = File(d, "instance.json").readText(); val ver = Regex("\"version\":\"([^\"]+)\"").find(t)?.groupValues?.get(1) ?: "1.21.1"; val ren = Regex("\"renderer\":\"([^\"]+)\"").find(t)?.groupValues?.get(1) ?: "GL4ES"; FlintInstance(d.name, d.name, ver, d, ren, 21) } ?: emptyList() }
 fun find(root: File, id: String): FlintInstance? = list(root).firstOrNull { it.id == id }
}
