package com.flintlauncher.android.minecraft
import java.io.File
import java.util.zip.ZipFile
object FlintModpackImporter { data class Result(val ok: Boolean, val name: String, val error: String?)
 fun importMrpack(zip: File, dest: File): Result { if (!zip.exists()) return Result(false, "", "File tidak ada"); return try { ZipFile(zip).use { z -> val m = z.getEntry("modrinth.index.json") ?: z.getEntry("manifest.json") ?: return Result(false, "", "Bukan mrpack/CurseForge"); dest.mkdirs(); File(dest, "modpack-manifest.json").writeText(z.getInputStream(m).bufferedReader().readText()); Result(true, zip.nameWithoutExtension, null) } } catch(e: Throwable) { Result(false, "", "Import gagal: ${e.message}") } } }
