package com.flintlauncher.android.accounts
import android.content.Context
import android.content.SharedPreferences
data class FlintAccount(val uuid: String, val name: String, val type: String, val accessToken: String?)
object AccountStore {
  private fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("flint_accounts", Context.MODE_PRIVATE)
  fun saveOffline(ctx: Context, name: String): FlintAccount { val uuid = "offline-${name.hashCode().toString(16)}"; val a = FlintAccount(uuid, name, "offline", null); prefs(ctx).edit().putString("last_uuid", uuid).putString("last_name", name).putString("last_type", "offline").apply(); return a }
  fun last(ctx: Context): FlintAccount? { val p = prefs(ctx); val n = p.getString("last_name", null) ?: return null; return FlintAccount(p.getString("last_uuid","")?:"", n, p.getString("last_type","offline")?:"offline", null) }
}
