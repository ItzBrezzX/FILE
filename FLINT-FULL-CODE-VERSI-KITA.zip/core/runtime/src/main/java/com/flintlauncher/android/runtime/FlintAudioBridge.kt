package com.flintlauncher.android.runtime
import android.util.Log
object FlintAudioBridge { @Volatile var available=false; private set
 fun init(): Boolean { return try { System.loadLibrary("openal"); available=true; true } catch(e: Throwable) { available=false; Log.w("FlintAudio","openal missing, silent: ${e.message}"); false } } }
