package com.flintlauncher.android.runtime
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.util.Log
import android.view.Surface
import java.util.concurrent.atomic.AtomicBoolean
/** Owns EGL display/context/surface on game thread only. Call makeCurrentOnGameThread from game thread. */
class EglGameSurfaceManager {
  @Volatile private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
  @Volatile private var context: EGLContext = EGL14.EGL_NO_CONTEXT
  @Volatile private var surface: EGLSurface = EGL14.EGL_NO_SURFACE
  private val ready = AtomicBoolean(false)
  fun isEglReady(): Boolean = ready.get() && surface != EGL14.EGL_NO_SURFACE
  fun createFromSurface(s: Surface, renderer: FlintRenderer): Boolean {
    if (!FlintEglBridge.requireSurface(s)) return false
    return try {
      display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY); if (display==EGL14.EGL_NO_DISPLAY) return false
      val v = IntArray(2); if (!EGL14.eglInitialize(display, v, 0, v, 1)) return false
      val cfgAttr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, 4, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT, EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_NONE)
      val configs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1); if (!EGL14.eglChooseConfig(display, cfgAttr, 0, configs, 0, 1, n, 0)) return false
      val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
      context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttr, 0); if (context==EGL14.EGL_NO_CONTEXT) return false
      surface = EGL14.eglCreateWindowSurface(display, configs[0], s, intArrayOf(EGL14.EGL_NONE), 0); if (surface==EGL14.EGL_NO_SURFACE) return false
      if (!EGL14.eglMakeCurrent(display, surface, surface, context)) return false
      ready.set(true); Log.i("FlintEGL","EGL ready renderer=$renderer display=$display"); true
    } catch(e: Throwable) { Log.e("FlintEGL","create failed ${e.message}", e); false }
  }
  fun swapBuffersOnOwnerThread(): Boolean { if (!ready.get()) return false; return try { EGL14.eglSwapBuffers(display, surface) } catch(e: Throwable) { Log.e("FlintEGL","swap failed ${e.message}"); false } }
  fun releaseOnOwnerThread() { try { if (display!=EGL14.EGL_NO_DISPLAY) { EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT); if (surface!=EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface); if (context!=EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context); EGL14.eglTerminate(display) } } catch(e: Throwable) { Log.w("FlintEGL","release ${e.message}") }; display=EGL14.EGL_NO_DISPLAY; context=EGL14.EGL_NO_CONTEXT; surface=EGL14.EGL_NO_SURFACE; ready.set(false) }
}
