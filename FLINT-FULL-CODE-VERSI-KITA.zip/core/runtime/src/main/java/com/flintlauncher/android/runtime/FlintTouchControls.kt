package com.flintlauncher.android.runtime
object FlintTouchControls { const val KEY_W=87; const val KEY_A=65; const val KEY_S=83; const val KEY_D=68; const val KEY_SPACE=32; const val KEY_SHIFT=340; const val KEY_E=69; const val KEY_ESC=256
 fun joystickToMove(x: Float, y: Float, d: FlintInputDispatcher) { d.enqueue(FlintInputDispatcher.Ev.Key(KEY_W, if (y<-0.3) 1 else 0, 0)); d.enqueue(FlintInputDispatcher.Ev.Key(KEY_S, if (y>0.3) 1 else 0, 0)); d.enqueue(FlintInputDispatcher.Ev.Key(KEY_A, if (x<-0.3) 1 else 0, 0)); d.enqueue(FlintInputDispatcher.Ev.Key(KEY_D, if (x>0.3) 1 else 0, 0)) }
 fun tapAttack(d: FlintInputDispatcher) { d.enqueue(FlintInputDispatcher.Ev.Btn(0,1,0)); d.enqueue(FlintInputDispatcher.Ev.Btn(0,0,0)) }
 fun tapUse(d: FlintInputDispatcher) { d.enqueue(FlintInputDispatcher.Ev.Btn(1,1,0)); d.enqueue(FlintInputDispatcher.Ev.Btn(1,0,0)) }
 fun jump(d: FlintInputDispatcher) { d.enqueue(FlintInputDispatcher.Ev.Key(KEY_SPACE,1,0)); d.enqueue(FlintInputDispatcher.Ev.Key(KEY_SPACE,0,0)) }
 fun sneak(d: FlintInputDispatcher, down: Boolean) { d.enqueue(FlintInputDispatcher.Ev.Key(KEY_SHIFT, if (down) 1 else 0, 0)) }
 fun openInventory(d: FlintInputDispatcher) { d.enqueue(FlintInputDispatcher.Ev.Key(KEY_E,1,0)); d.enqueue(FlintInputDispatcher.Ev.Key(KEY_E,0,0)) }
 fun pause(d: FlintInputDispatcher) { d.enqueue(FlintInputDispatcher.Ev.Key(KEY_ESC,1,0)); d.enqueue(FlintInputDispatcher.Ev.Key(KEY_ESC,0,0)) }
}
