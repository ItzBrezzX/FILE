package com.flintlauncher.android.runtime
import android.util.Log
object FlintNativeBridge {
  @Volatile var loaded=false; private set
  fun load(): Boolean { if (loaded) return true; return try { System.loadLibrary("flint_jli_bridge"); loaded=true; true } catch(e: Throwable) { Log.w("FlintNative","load failed ${e.message}"); false } }
  fun sendInputEvent(e: FlintInputDispatcher.Ev) { if (!loaded) return; try { when(e) { is FlintInputDispatcher.Ev.Key -> nativeKey(e.code, e.action, e.mods); is FlintInputDispatcher.Ev.Btn -> nativeMouseButton(e.btn, e.action, e.mods); is FlintInputDispatcher.Ev.Cursor -> nativeCursor(e.x, e.y); is FlintInputDispatcher.Ev.Scroll -> nativeScroll(e.dx, e.dy) } } catch(ex: Throwable) { Log.w("FlintNative","input ${ex.message}") } }
  private external fun nativeKey(code: Int, action: Int, mods: Int)
  private external fun nativeMouseButton(btn: Int, action: Int, mods: Int)
  private external fun nativeCursor(x: Double, y: Double)
  private external fun nativeScroll(dx: Double, dy: Double)
}
