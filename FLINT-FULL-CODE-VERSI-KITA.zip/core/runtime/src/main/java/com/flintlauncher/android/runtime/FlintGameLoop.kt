package com.flintlauncher.android.runtime
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
class FlintGameLoop(private val surface: EglGameSurfaceManager, private val input: FlintInputDispatcher) {
 private val running = AtomicBoolean(false); @Volatile var frames=0L; private set; @Volatile var lastFps=0.0; private set
 fun start(): Thread { running.set(true); val t = Thread({ var last=System.nanoTime(); var acc=0L; var cnt=0; while(running.get()) { try { input.dispatchOnGameThread(); if (surface.isEglReady()) { if (surface.swapBuffersOnOwnerThread()) { frames++; cnt++ } }; val now=System.nanoTime(); acc+=now-last; last=now; if (acc>=1_000_000_000L) { lastFps=cnt*1_000_000_000.0/acc; acc=0; cnt=0 }; Thread.sleep(1) } catch(e: InterruptedException) { break } catch(e: Throwable) { Log.e("FlintLoop","${e.message}", e); if (e.message?.contains("EGL")==true) break } } }, "Flint-GameLoop"); t.start(); return t }
 fun stop() { running.set(false) }
 fun isRunning(): Boolean = running.get()
}
