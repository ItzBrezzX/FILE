package com.flintlauncher.android.runtime
import android.util.Log
import java.util.concurrent.ConcurrentLinkedQueue
/** Input pipe: UI thread enqueue, game thread dispatch to native GLFW. */
class FlintInputDispatcher {
  sealed class Ev { data class Key(val code: Int, val action: Int, val mods: Int): Ev(); data class Btn(val btn: Int, val action: Int, val mods: Int): Ev(); data class Cursor(val x: Double, val y: Double): Ev(); data class Scroll(val dx: Double, val dy: Double): Ev() }
  private val q = ConcurrentLinkedQueue<Ev>()
  fun enqueue(e: Ev) { q.offer(e); if (q.size>1024) q.poll() }
  fun dispatchOnGameThread() { var e = q.poll(); while(e!=null) { try { FlintNativeBridge.sendInputEvent(e) } catch(ex: Throwable) { Log.w("FlintInput","dispatch ${ex.message}") }; e=q.poll() } }
}
