package com.flintlauncher.android.runtime
import android.util.Log
import java.io.File
object FlintCrashHandler { fun install(filesDir: File) { val old = Thread.getDefaultUncaughtExceptionHandler(); Thread.setDefaultUncaughtExceptionHandler { t, e -> try { val f = File(filesDir, "flint-crash-${System.currentTimeMillis()}.log"); f.writeText("Thread ${t.name}: $e\n${e.stackTraceToString()}"); Log.e("FlintCrash","saved ${f.path}", e) } catch(ex: Throwable) {} ; old?.uncaughtException(t, e) }; Log.i("FlintCrash","installed") } }
