package com.flintlauncher.android.runtime
import android.util.Log
object FlintSdl3Bridge { fun needsSdl3(v: String): Boolean = v.startsWith("26.")||v.contains("26w"); fun initIfNeeded(v: String): Boolean { if (!needsSdl3(v)) return true; return try { System.loadLibrary("SDL3"); true } catch(e: Throwable) { Log.w("FlintSDL3","SDL3 missing for $v, fallback GLFW"); false } } }
