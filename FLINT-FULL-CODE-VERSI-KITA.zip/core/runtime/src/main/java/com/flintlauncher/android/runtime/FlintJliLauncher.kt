package com.flintlauncher.android.runtime
import android.util.Log
import java.io.File
/** JLI_Launch in-process ala Boardwalk/Pojav. Harus dipanggil dari game thread, bukan UI thread. */
object FlintJliLauncher {
  fun findJli(filesDir: File, javaVersion: Int): File? { val cands = listOf(File(filesDir, "runtime/java-$javaVersion/lib/libjli.so"), File(filesDir, "runtime/java-21/lib/libjli.so"), File(filesDir, "runtime/java-17/lib/libjli.so"), File(filesDir, "runtime/java-8/lib/libjli.so")); return cands.firstOrNull { it.exists() } }
  fun buildJvmArgs(filesDir: File, javaVersion: Int, gameDir: File, classpath: String, mainClass: String, gameArgs: List<String>, rendererEnv: Map<String,String>): List<String> {
    val jli = findJli(filesDir, javaVersion) ?: throw IllegalStateException("JRE tidak ditemukan di runtime/java-$javaVersion - download JRE ARM64 dulu")
    val args = mutableListOf<String>()
    args += "-Djava.library.path=${File(gameDir, "natives").absolutePath}"
    args += "-Dorg.lwjgl.librarypath=${File(gameDir, "natives").absolutePath}"
    rendererEnv.forEach { (k,v) -> args += "-D$k=$v" }
    args += "-Dorg.lwjgl.opengl.libname=libGL.so"
    args += "-cp"; args += classpath
    args += mainClass; args += gameArgs
    Log.i("FlintJLI","jli=${jli.path} args=${args.size} main=$mainClass")
    return args
  }
  external fun nativeJliLaunch(args: Array<String>): Int
}
