package com.flintlauncher.android.runtime
import android.util.Log
enum class FlintRenderer { GL4ES, ZINK, VIRGL, MOBILE_GLUES, KRYPTON }
object FlintRendererSelector {
 fun envFor(r: FlintRenderer): Map<String,String> = when(r) {
  FlintRenderer.GL4ES -> mapOf("POJAV_RENDERER" to "opengles2","LIBGL_ES" to "2","REGAL_GL_VENDOR" to "Android")
  FlintRenderer.ZINK -> mapOf("POJAV_RENDERER" to "opengles2","LIBGL_ES" to "3","MESA_LOADER_DRIVER_OVERRIDE" to "zink")
  FlintRenderer.VIRGL -> mapOf("POJAV_RENDERER" to "virgl","LIBGL_ES" to "2")
  FlintRenderer.MOBILE_GLUES -> mapOf("POJAV_RENDERER" to "opengles2","LIBGL_ES" to "2","FLINT_RENDERER" to "mobileglues")
  FlintRenderer.KRYPTON -> mapOf("POJAV_RENDERER" to "opengles2","FLINT_RENDERER" to "krypton")
 }
 fun defaultForMali(): FlintRenderer = FlintRenderer.GL4ES
 fun parse(name: String): FlintRenderer = try { FlintRenderer.valueOf(name.uppercase()) } catch(e: Throwable) { GL4ES }
}
