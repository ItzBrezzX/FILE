package com.flintlauncher.android.runtime
import android.util.Log
import android.view.Surface
object FlintEglBridge { @Volatile var renderer: FlintRenderer = FlintRenderer.GL4ES
 fun applyRendererEnv(r: FlintRenderer): Map<String,String> { renderer=r; val env=FlintRendererSelector.envFor(r); Log.i("FlintEGL","renderer=$r env=$env"); return env }
 fun requireSurface(s: Surface?): Boolean { if (s==null||!s.isValid) { Log.e("FlintEGL","Surface null/invalid"); return false }; return true } }
