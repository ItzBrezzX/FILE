package com.flintlauncher.android.runtime
import android.util.Log
object FlintSafeStartup { @Volatile var nativeAvailable=false; private set; @Volatile var lastError:String?=null; private set
 fun probeNativeLazy(): Boolean { return try { System.loadLibrary("flint_jli_bridge"); nativeAvailable=true; true } catch(e: Throwable) { nativeAvailable=false; lastError=e.message; Log.w("FlintStartup","native missing, app tetap jalan: ${e.message}"); false } }
 fun canOpenMain(): Boolean = true }
