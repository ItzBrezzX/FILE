package com.flintlauncher.android.runtime
enum class GameLaunchState { PREPARING, JVM_STARTING, GAME_INITIALIZING, RUNNING, STOPPING, STOPPED, FAILED }
data class GameLaunchFailure(val state: GameLaunchState, val message: String, val cause: Throwable? = null, val exitCode: Int? = null)
interface GameLaunchListener { fun onState(state: GameLaunchState, detail: String); fun onFailure(f: GameLaunchFailure); fun onMinecraftInitialized() }
