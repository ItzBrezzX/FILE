package com.flintlauncher.android.runtime
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.util.Log
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
class EglGameSurfaceManager {
  enum class State { IDLE, WAITING_SURFACE, SURFACE_READY, EGL_READY, EGL_FAILED, RELEASED, DESTROYED }
  @Volatile var state: State = State.IDLE; private set
  private val surfaceRef = AtomicReference<Surface?>(null); private val readyLatch = CountDownLatch(1); private val eglLatch = CountDownLatch(1)
  @Volatile private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY; @Volatile private var surface: EGLSurface = EGL14.EGL_NO_SURFACE; @Volatile private var context: EGLContext = EGL14.EGL_NO_CONTEXT
  @Volatile private var owner: Thread? = null; private val owned = AtomicBoolean(false); private val released = AtomicBoolean(false)
  @Volatile var width = 0; private set; @Volatile var height = 0; private set
  fun onSurfaceCreated(s: Surface, w: Int, h: Int) { if (released.get()) return; surfaceRef.set(s); width = w; height = h; state = State.SURFACE_READY; readyLatch.countDown(); Log.i("FlintEGL", "Surface $w x $h") }
  fun onSurfaceChanged(w: Int, h: Int) { width = w; height = h; Log.i("FlintEGL", "Surface changed $w x $h state=$state") }
  fun onSurfaceDestroyed() { surfaceRef.set(null); state = State.DESTROYED; Log.i("FlintEGL", "Surface destroyed, owner thread must release EGL") }
  fun awaitSurface(ms: Long = 15000): Boolean { state = State.WAITING_SURFACE; val ok = readyLatch.await(ms, TimeUnit.MILLISECONDS); if (!ok) state = State.EGL_FAILED; return ok && surfaceRef.get() != null }
  fun initEglOnOwnerThread(): Boolean {
    if (owned.get()) return true; val surf = surfaceRef.get() ?: run { state = State.EGL_FAILED; return false }; owner = Thread.currentThread()
    val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY); if (d == EGL14.EGL_NO_DISPLAY) { state = State.EGL_FAILED; return false }
    val ver = IntArray(2); if (!EGL14.eglInitialize(d, ver, 0, ver, 1)) { state = State.EGL_FAILED; return false }
    val attribs = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_NONE)
    val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1); if (!EGL14.eglChooseConfig(d, attribs, 0, cfgs, 0, 1, n, 0) || n[0] == 0) { state = State.EGL_FAILED; return false }
    val cfg = cfgs[0]!!; val ctx = EGL14.eglCreateContext(d, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0); if (ctx == EGL14.EGL_NO_CONTEXT) { state = State.EGL_FAILED; return false }
    val es = EGL14.eglCreateWindowSurface(d, cfg, surf, intArrayOf(EGL14.EGL_NONE), 0); if (es == EGL14.EGL_NO_SURFACE) { EGL14.eglDestroyContext(d, ctx); state = State.EGL_FAILED; return false }
    if (!EGL14.eglMakeCurrent(d, es, es, ctx)) { EGL14.eglDestroySurface(d, es); EGL14.eglDestroyContext(d, ctx); state = State.EGL_FAILED; Log.e("FlintEGL", "eglMakeCurrent failed ${EGL14.eglGetError()}"); return false }
    display = d; surface = es; context = ctx; owned.set(true); state = State.EGL_READY; eglLatch.countDown(); Log.i("FlintEGL", "EGL ready on ${Thread.currentThread().name}"); return true
  }
  fun swapBuffersOnOwnerThread(): Boolean { if (!owned.get() || Thread.currentThread() != owner) return false; return EGL14.eglSwapBuffers(display, surface) }
  fun releaseEglOnOwnerThread() { if (!owned.get()) return; if (Thread.currentThread() != owner) { Log.e("FlintEGL", "release from non-owner blocked"); return }; try { EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT); if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface); if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context); EGL14.eglTerminate(display) } catch (e: Throwable) { Log.e("FlintEGL", "release error ${e.message}", e) }; display = EGL14.EGL_NO_DISPLAY; surface = EGL14.EGL_NO_SURFACE; context = EGL14.EGL_NO_CONTEXT; owned.set(false); owner = null; released.set(true); state = State.RELEASED }
  fun isEglReady(): Boolean = state == State.EGL_READY && owned.get()
}
