package com.flintlauncher.android.runtime
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
object LwjglNativeLoader {
  const val LWJGL_VERSION = "3.3.3"
  val REQUIRED = listOf("liblwjgl.so","liblwjgl_opengl.so","liblwjgl_glfw.so","libglfw.so","libGL.so")
  val REQUIRED_JNI = listOf("Java_org_lwjgl_glfw_GLFW_nglfwInit","Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow","Java_org_lwjgl_glfw_GLFW_nglfwDestroyWindow","Java_org_lwjgl_glfw_GLFW_nglfwMakeContextCurrent","Java_org_lwjgl_glfw_GLFW_nglfwSwapBuffers","Java_org_lwjgl_glfw_GLFW_nglfwPollEvents","Java_org_lwjgl_glfw_GLFW_nglfwWindowShouldClose")
  fun detectAbi(): String { val abis = Build.SUPPORTED_ABIS?.toList() ?: emptyList(); return when { "arm64-v8a" in abis -> "arm64-v8a"; "armeabi-v7a" in abis -> "armeabi-v7a"; abis.isNotEmpty() -> abis[0]; else -> "arm64-v8a" } }
  fun stageAll(context: Context, nativesDir: File): Boolean {
    nativesDir.mkdirs(); var ok = true
    for (name in REQUIRED) { val src = File(context.applicationInfo.nativeLibraryDir, name); val dst = File(nativesDir, name); if (!src.exists()) { Log.e("FlintLWJGL", "Missing in APK: $name ABI=${detectAbi()}"); ok = false; continue }; src.copyTo(dst, overwrite = true); Log.i("FlintLWJGL", "Staged $name -> ${dst.path} ${dst.length()} bytes") }
    return ok
  }
  fun verifyStaged(nativesDir: File): List<String> = REQUIRED.filter { !File(nativesDir, it).exists() }
  fun loadAll(): Boolean { return try { System.loadLibrary("lwjgl"); System.loadLibrary("lwjgl_opengl"); System.loadLibrary("lwjgl_glfw"); Log.i("FlintLWJGL", "load lwjgl+opengl+glfw OK"); true } catch (e: UnsatisfiedLinkError) { Log.e("FlintLWJGL", "load failed ${e.message}", e); false } }
  fun libraryPath(nativesDir: File): String = nativesDir.absolutePath
}
