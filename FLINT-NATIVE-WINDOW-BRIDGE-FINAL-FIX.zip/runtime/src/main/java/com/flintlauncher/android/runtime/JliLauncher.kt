package com.flintlauncher.android.runtime
import android.util.Log
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
class JliLauncher(private val jreDir: File) {
  private val running = AtomicBoolean(false); private val cleaned = AtomicBoolean(false)
  fun libjliFile(): File = File(jreDir, "lib/libjli.so")
  fun libjvmFile(): File = File(jreDir, "lib/server/libjvm.so")
  fun verifyJre(): Boolean { val jli = libjliFile(); val jvm = libjvmFile(); val ok = jli.exists() && jli.length() > 0 && jvm.exists() && jvm.length() > 0; Log.i("FlintJLI", "verifyJre jli=${jli.exists()} jvm=${jvm.exists()} ok=$ok"); if (!ok) Log.e("FlintJLI", "JRE incomplete: ${jli.path} / ${jvm.path}"); return ok }
  fun launch(argv: Array<String>, libraryPath: String): Int {
    if (!verifyJre()) return -2
    if (!JliNativeBridge.ensureLoaded()) return -4
    if (!running.compareAndSet(false, true)) { Log.e("FlintJLI", "double init prevented"); return -1 }
    cleaned.set(false)
    try { val code = JliNativeBridge.nativeLaunchJli(jreDir.absolutePath, argv, libraryPath); if (code < 0) Log.e("FlintJLI", "JLI failed $code ${JliNativeBridge.nativeGetLastError()}") else Log.i("FlintJLI", "JLI returned $code"); return code } catch (e: Throwable) { Log.e("FlintJLI", "JLI threw ${e.message}", e); return -4 } finally { running.set(false) }
  }
  fun requestStop(): Int { if (!running.get()) return 0; return try { JliNativeBridge.nativeRequestStop() } catch (e: Throwable) { Log.e("FlintJLI", "stop failed ${e.message}", e); -1 } }
  fun isRunning(): Boolean = running.get() || JliNativeBridge.nativeIsRunning()
  fun cleanupOnce() { if (!cleaned.compareAndSet(false, true)) return; Log.i("FlintJLI", "cleanup once") }
}
