package com.flintlauncher.android.runtime
import android.opengl.GLES20
import android.util.Log
object Gl4esBridge {
  fun initAfterEgl(): Boolean { return try { System.loadLibrary("GL"); val v = GLES20.glGetString(GLES20.GL_VERSION) ?: ""; Log.i("FlintGL4ES", "libGL.so loaded, GL_VERSION=$v"); if (v.isEmpty()) { Log.e("FlintGL4ES", "GL_VERSION empty - GL4ES not actually initialized"); return false }; true } catch (e: UnsatisfiedLinkError) { Log.e("FlintGL4ES", "libGL.so load failed ${e.message}", e); false } catch (e: Throwable) { Log.e("FlintGL4ES", "GL4ES init failed ${e.message}", e); false } }
}
