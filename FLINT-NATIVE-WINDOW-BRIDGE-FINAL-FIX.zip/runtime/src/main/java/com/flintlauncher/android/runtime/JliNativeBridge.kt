package com.flintlauncher.android.runtime
import android.util.Log
object JliNativeBridge {
  @Volatile private var loaded = false
  fun ensureLoaded(): Boolean { if (loaded) return true; try { System.loadLibrary("flint_jli_bridge"); loaded = true; return true } catch (e: UnsatisfiedLinkError) { Log.e("FlintJLI", "load flint_jli_bridge failed: ${e.message}", e); return false } }
  external fun nativeLaunchJli(jreDir: String, argv: Array<String>, libraryPath: String): Int
  external fun nativeGetLastError(): String
  external fun nativeRequestStop(): Int
  external fun nativeIsRunning(): Boolean
}
