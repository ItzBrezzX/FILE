package com.flintlauncher.android.runtime
import android.util.Log
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
object FlintGlfwEventBridge {
  init { try { System.loadLibrary("lwjgl_glfw") } catch (e: UnsatisfiedLinkError) { Log.e("FlintInput", "lwjgl_glfw not loaded for input bridge: ${e.message}") } }
  external fun nativeEnqueueKey(key: Int, scancode: Int, action: Int, mods: Int): Int
  external fun nativeEnqueueChar(codePoint: Int): Int
  external fun nativeEnqueueMouseButton(button: Int, action: Int, mods: Int): Int
  external fun nativeEnqueueCursorPos(x: Double, y: Double): Int
  external fun nativeEnqueueScroll(xOff: Double, yOff: Double): Int
  external fun nativeEnqueueFramebufferSize(w: Int, h: Int): Int
  external fun nativeEnqueueFocus(focused: Boolean): Int
}
class FlintInputDispatcher(private val maxQueue: Int = 512) {
  sealed class Ev { data class Key(val k: Int, val a: Int, val m: Int) : Ev(); data class Ch(val cp: Int) : Ev(); data class Move(val x: Double, val y: Double) : Ev(); data class Btn(val b: Int, val a: Int, val m: Int) : Ev(); data class Scroll(val x: Double, val y: Double) : Ev(); data class Resize(val w: Int, val h: Int) : Ev(); data class Focus(val f: Boolean) : Ev() }
  private val q = ArrayBlockingQueue<Ev>(maxQueue); private val pressedKeys = ConcurrentHashMap<Int, Boolean>(); private val pressedBtns = ConcurrentHashMap<Int, Boolean>()
  @Volatile var dropped = 0; private set; @Volatile var dispatched = 0; private set
  fun enqueue(ev: Ev): Boolean {
    if (ev is Ev.Key) { if (ev.a == 1) pressedKeys[ev.k] = true else if (ev.a == 0) pressedKeys.remove(ev.k) }
    if (ev is Ev.Btn) { if (ev.a == 1) pressedBtns[ev.b] = true else if (ev.a == 0) pressedBtns.remove(ev.b) }
    if (ev is Ev.Focus && !ev.f) handleFocusLoss()
    val ok = q.offer(ev); if (!ok) { dropped++; q.poll(); q.offer(ev) }; return ok
  }
  fun dispatchOnGameThread() { while (true) { val ev = q.poll() ?: break; dispatched++; try { when (ev) { is Ev.Key -> FlintGlfwEventBridge.nativeEnqueueKey(ev.k, 0, ev.a, ev.m); is Ev.Ch -> FlintGlfwEventBridge.nativeEnqueueChar(ev.cp); is Ev.Move -> FlintGlfwEventBridge.nativeEnqueueCursorPos(ev.x, ev.y); is Ev.Btn -> FlintGlfwEventBridge.nativeEnqueueMouseButton(ev.b, ev.a, ev.m); is Ev.Scroll -> FlintGlfwEventBridge.nativeEnqueueScroll(ev.x, ev.y); is Ev.Resize -> FlintGlfwEventBridge.nativeEnqueueFramebufferSize(ev.w, ev.h); is Ev.Focus -> FlintGlfwEventBridge.nativeEnqueueFocus(ev.f) } } catch (e: Throwable) { Log.e("FlintInput", "dispatch failed ${e.message}", e) } } }
  fun handleFocusLoss() { pressedKeys.clear(); pressedBtns.clear(); q.offer(Ev.Focus(false)) }
  fun releaseAllOnStop() { pressedKeys.clear(); pressedBtns.clear(); q.clear() }
  fun queueSize(): Int = q.size
  fun isStuck(): Boolean = pressedKeys.isNotEmpty() || pressedBtns.isNotEmpty()
}
