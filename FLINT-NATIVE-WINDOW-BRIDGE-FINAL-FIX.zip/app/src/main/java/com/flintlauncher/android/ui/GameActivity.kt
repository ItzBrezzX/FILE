package com.flintlauncher.android.ui
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.FrameLayout
import com.flintlauncher.android.minecraft.RealLaunchPipeline
import com.flintlauncher.android.runtime.*
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
class GameActivity : Activity(), SurfaceHolder.Callback {
  private lateinit var surfaceView: SurfaceView; private lateinit var surfaceManager: EglGameSurfaceManager; private lateinit var pipeline: RealLaunchPipeline
  private val pipelineStarted = AtomicBoolean(false); private val surfaceReady = AtomicBoolean(false)
  private lateinit var playButton: Button; private lateinit var stopButton: Button
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    surfaceManager = EglGameSurfaceManager(); pipeline = RealLaunchPipeline(this, surfaceManager)
    pipeline.listener = object : GameLaunchListener { override fun onState(s: GameLaunchState, d: String) { runOnUiThread { updateButtons(s) } }; override fun onFailure(f: GameLaunchFailure) { runOnUiThread { updateButtons(GameLaunchState.FAILED) }; Log.e("FlintGame", "FAIL ${f.state} ${f.message}", f.cause) }; override fun onMinecraftInitialized() { runOnUiThread { updateButtons(GameLaunchState.RUNNING) } } }
    val root = FrameLayout(this); surfaceView = SurfaceView(this); surfaceView.holder.addCallback(this); root.addView(surfaceView)
    playButton = Button(this).apply { text = "PLAY"; setOnClickListener { onPlayClicked() } }; stopButton = Button(this).apply { text = "STOP"; isEnabled = false; setOnClickListener { onStopClicked() } }
    val bar = FrameLayout(this); bar.addView(playButton); bar.addView(stopButton); root.addView(bar); setContentView(root)
  }
  private fun updateButtons(s: GameLaunchState) { when (s) { GameLaunchState.PREPARING, GameLaunchState.JVM_STARTING, GameLaunchState.GAME_INITIALIZING, GameLaunchState.RUNNING -> { playButton.isEnabled = false; stopButton.isEnabled = true }; GameLaunchState.STOPPED, GameLaunchState.FAILED -> { playButton.isEnabled = true; stopButton.isEnabled = false }; else -> {} } }
  private fun onPlayClicked() {
    if (!surfaceReady.get()) { Log.e("FlintGame", "PLAY blocked: Surface not ready"); return }
    if (!pipelineStarted.compareAndSet(false, true)) { Log.e("FlintGame", "PLAY blocked: pipeline already started (double-start prevented)"); return }
    val inst = intent.getStringExtra("installation_id") ?: "default"
    val accounts = File(filesDir, "accounts.json")
    val root = filesDir
    // Pipeline creates ONE game thread internally. Activity does NOT create its own worker thread.
    val ok = pipeline.start(inst, accounts, root)
    if (!ok) pipelineStarted.set(false)
  }
  private fun onStopClicked() { Thread({ val ok = pipeline.requestStop(); if (ok) pipelineStarted.set(false) }, "Flint-Stop-Thread").start() }
  override fun surfaceCreated(h: SurfaceHolder) { surfaceManager.onSurfaceCreated(h.surface, surfaceView.width, surfaceView.height); surfaceReady.set(true) }
  override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) { surfaceManager.onSurfaceChanged(w, h2); pipeline.onSurfaceChanged(w, h2) }
  override fun surfaceDestroyed(h: SurfaceHolder) { surfaceReady.set(false); surfaceManager.onSurfaceDestroyed(); pipeline.onPause() }
  override fun onPause() { super.onPause(); pipeline.onPause() }
  override fun onResume() { super.onResume(); pipeline.onResume() }
  override fun onDestroy() { pipeline.requestStop(); pipelineStarted.set(false); super.onDestroy() }
}
