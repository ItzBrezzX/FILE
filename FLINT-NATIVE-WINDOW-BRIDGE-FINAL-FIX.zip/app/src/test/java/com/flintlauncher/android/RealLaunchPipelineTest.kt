package com.flintlauncher.android
import com.flintlauncher.android.minecraft.LaunchArgumentBuilder
import com.flintlauncher.android.minecraft.AccountSession
import com.flintlauncher.android.runtime.FlintInputDispatcher
import com.flintlauncher.android.runtime.GameLaunchState
import org.junit.Assert.*
import org.junit.Test
import java.io.File
class RealLaunchPipelineTest {
  @Test fun startedIsNotRunning() { assertNotEquals(GameLaunchState.PREPARING, GameLaunchState.RUNNING); assertNotEquals(GameLaunchState.JVM_STARTING, GameLaunchState.RUNNING) }
  @Test fun inputOverflowDoesNotStick() { val d = FlintInputDispatcher(4); repeat(10) { d.enqueue(FlintInputDispatcher.Ev.Key(65, 1, 0)) }; assertTrue(d.dropped > 0); d.handleFocusLoss(); assertFalse(d.isStuck()) }
  @Test fun argBuilderFailsOnMissingLib() { val tmp = File.createTempFile("ver", ".json"); tmp.writeText("{}"); val r = LaunchArgumentBuilder.build(tmp, File("/tmp"), File("/tmp"), File("/tmp"), AccountSession("u","uuid","tok","mojang"), "x"); assertTrue(r.isFailure) }
}
