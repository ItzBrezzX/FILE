package com.flintlauncher.android.minecraft
import android.util.Log
import java.io.File
import org.json.JSONObject
data class Installation(val id: String, val versionId: String, val gameDir: File, val versionJson: File)
object InstallationValidator {
  fun resolve(gameDirRoot: File, installationId: String): Result<Installation> {
    val dir = File(gameDirRoot, "versions/$installationId")
    val jsonFile = File(dir, "$installationId.json")
    if (!jsonFile.exists()) return Result.failure(IllegalStateException("Missing version JSON: ${jsonFile.path}"))
    return try { val json = JSONObject(jsonFile.readText()); val ver = json.optString("id", installationId); if (ver.isEmpty()) return Result.failure(IllegalStateException("Version JSON has empty id")); val clientJar = File(dir, "$installationId.jar"); if (!clientJar.exists()) return Result.failure(IllegalStateException("Missing client jar: ${clientJar.path}")); Log.i("FlintInstall", "Installation OK id=$installationId version=$ver"); Result.success(Installation(installationId, ver, File(gameDirRoot, "instances/$installationId"), jsonFile)) } catch (e: Throwable) { Result.failure(e) }
  }
}
