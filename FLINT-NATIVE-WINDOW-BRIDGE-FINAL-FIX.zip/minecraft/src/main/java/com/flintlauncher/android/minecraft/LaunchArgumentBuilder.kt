package com.flintlauncher.android.minecraft
import java.io.File
import org.json.JSONObject
object LaunchArgumentBuilder {
  data class Built(val classpath: String, val jvmArgs: List<String>, val gameArgs: List<String>, val nativesDir: File, val javaVersion: Int)
  fun build(versionJsonFile: File, gameDir: File, nativesDir: File, assetsDir: File, account: AccountSession, installationId: String, jvmExtra: List<String> = emptyList()): Result<Built> {
    return try {
      val json = JSONObject(versionJsonFile.readText())
      val libs = json.optJSONArray("libraries") ?: return Result.failure(IllegalStateException("No libraries in version JSON"))
      val cpParts = mutableListOf<String>()
      val libDir = File(gameDir, "libraries")
      for (i in 0 until libs.length()) { val lib = libs.getJSONObject(i); val downloads = lib.optJSONObject("downloads"); val artifact = downloads?.optJSONObject("artifact"); val path = artifact?.optString("path") ?: continue; val rules = lib.optJSONArray("rules"); if (!rulesAllow(rules)) continue; val f = File(libDir, path); if (!f.exists()) return Result.failure(IllegalStateException("Missing library file: ${f.path}")); cpParts.add(f.absolutePath) }
      val clientJar = File(versionJsonFile.parentFile, "$installationId.jar"); cpParts.add(clientJar.absolutePath)
      val classpath = cpParts.joinToString(":")
      val assetIndex = json.optJSONObject("assetIndex")?.optString("id", "legacy") ?: "legacy"
      val mainClass = json.optString("mainClass"); if (mainClass.isEmpty()) return Result.failure(IllegalStateException("No mainClass in version JSON"))
      val javaVersion = json.optJSONObject("javaVersion")?.optInt("majorVersion", 21) ?: 21
      val jvmArgs = mutableListOf("-Xmx2048M", "-Xms512M", "-Djava.library.path=${nativesDir.absolutePath}", "-Dorg.lwjgl.librarypath=${nativesDir.absolutePath}", "-Dorg.lwjgl.glfw.libname=libglfw.so", "-Djava.net.preferIPv4Stack=true")
      jvmArgs.addAll(jvmExtra)
      val gameArgs = listOf("--username", account.username, "--version", installationId, "--gameDir", gameDir.absolutePath, "--assetsDir", assetsDir.absolutePath, "--assetIndex", assetIndex, "--uuid", account.uuid, "--accessToken", account.accessToken, "--userType", account.userType, "--versionType", "release")
      Result.success(Built(classpath, jvmArgs, gameArgs, nativesDir, javaVersion))
    } catch (e: Throwable) { Result.failure(e) }
  }
  private fun rulesAllow(rules: org.json.JSONArray?): Boolean {
    if (rules == null) return true
    var allow = true
    for (i in 0 until rules.length()) { val r = rules.getJSONObject(i); val action = r.optString("action"); val os = r.optJSONObject("os"); val osName = os?.optString("name"); if (osName != null && osName != "linux" && osName != "android") continue; if (action == "allow") allow = true else if (action == "disallow") allow = false }
    return allow
  }
}
