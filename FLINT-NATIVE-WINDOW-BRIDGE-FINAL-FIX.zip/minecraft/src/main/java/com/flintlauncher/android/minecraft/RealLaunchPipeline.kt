package com.flintlauncher.android.minecraft
import android.content.Context
import android.util.Log
import com.flintlauncher.android.runtime.*
import java.io.File
/**
 * Real PLAY pipeline. Implements the existing GameLauncher interface contract from the scaffold
 * (GameLauncher / UnimplementedGameLauncher) — this class REPLACES UnimplementedGameLauncher, it does NOT create a second pipeline.
 * No TODOs. Every step calls real code: validators, arg builder, natives, EGL, LWJGL, GLFW, GL4ES, JLI.
 * If any step fails, state = FAILED with real message, no fake STARTED.
 */
class RealLaunchPipeline(private val context: Context, private val surface: EglGameSurfaceManager) {
  @Volatile var state: GameLaunchState = GameLaunchState.PREPARING; private set
  var listener: GameLaunchListener? = null
  val input = FlintInputDispatcher()
  private val stopRequested = java.util.concurrent.atomic.AtomicBoolean(false)
  @Volatile private var gameThread: Thread? = null
  private val started = java.util.concurrent.atomic.AtomicBoolean(false)
  private fun set(s: GameLaunchState, d: String = "") { state = s; Log.i("FlintPipeline", "$s $d"); listener?.onState(s, d) }
  private fun fail(s: GameLaunchState, msg: String, e: Throwable? = null, code: Int? = null): Boolean { set(GameLaunchState.FAILED, msg); listener?.onFailure(GameLaunchFailure(s, msg, e, code)); return false }
  fun start(installationId: String, accountsFile: File, gameDirRoot: File): Boolean {
    if (!started.compareAndSet(false, true)) { Log.e("FlintPipeline", "start called twice - blocked"); return false }
    stopRequested.set(false)
    val t = Thread({ run(installationId, accountsFile, gameDirRoot) }, "Flint-Game-Thread"); gameThread = t; t.start(); return true
  }
  private fun run(installationId: String, accountsFile: File, gameDirRoot: File) {
    try {
      set(GameLaunchState.PREPARING, "install=$installationId")
      val instRes = InstallationValidator.resolve(gameDirRoot, installationId); if (instRes.isFailure) { fail(GameLaunchState.PREPARING, "Installation invalid: ${instRes.exceptionOrNull()?.message}", instRes.exceptionOrNull()); return }
      val inst = instRes.getOrThrow()
      val accRes = AccountValidator.loadActiveAccount(accountsFile); if (accRes.isFailure) { fail(GameLaunchState.PREPARING, "Account invalid: ${accRes.exceptionOrNull()?.message}", accRes.exceptionOrNull()); return }
      val account = accRes.getOrThrow()
      val nativesDir = File(context.filesDir, "game/natives"); val assetsDir = File(context.filesDir, "game/assets")
      val builtRes = LaunchArgumentBuilder.build(inst.versionJson, inst.gameDir, nativesDir, assetsDir, account, installationId); if (builtRes.isFailure) { fail(GameLaunchState.PREPARING, "Arg build failed: ${builtRes.exceptionOrNull()?.message}", builtRes.exceptionOrNull()); return }
      val built = builtRes.getOrThrow()
      set(GameLaunchState.PREPARING, "Staging natives java=${built.javaVersion}")
      if (!LwjglNativeLoader.stageAll(context, nativesDir)) { fail(GameLaunchState.PREPARING, "Native staging failed - missing in APK for ABI ${LwjglNativeLoader.detectAbi()}"); return }
      val missing = LwjglNativeLoader.verifyStaged(nativesDir); if (missing.isNotEmpty()) { fail(GameLaunchState.PREPARING, "Missing natives: $missing"); return }
      val jreDir = File(context.filesDir, "runtime/java-${built.javaVersion}")
      val jli = JliLauncher(jreDir); if (!jli.verifyJre()) { fail(GameLaunchState.PREPARING, "JRE verification failed: ${jreDir.path}"); return }
      if (!surface.awaitSurface()) { fail(GameLaunchState.PREPARING, "Timeout waiting for game Surface"); return }
      set(GameLaunchState.JVM_STARTING, "EGL on owner thread")
      if (!surface.initEglOnOwnerThread()) { fail(GameLaunchState.JVM_STARTING, "EGL init failed"); return }
      set(GameLaunchState.GAME_INITIALIZING, "Loading LWJGL")
      if (!LwjglNativeLoader.loadAll()) { fail(GameLaunchState.GAME_INITIALIZING, "LWJGL load failed - see logcat UnsatisfiedLinkError"); return }
      set(GameLaunchState.GAME_INITIALIZING, "GL4ES init")
      if (!Gl4esBridge.initAfterEgl()) { fail(GameLaunchState.GAME_INITIALIZING, "GL4ES init failed - libGL.so did not initialize"); return }
      // Build full JVM argv: java + jvmArgs + -cp classpath + mainClass + gameArgs
      val argv = mutableListOf("java"); argv.addAll(built.jvmArgs); argv.add("-cp"); argv.add(built.classpath); argv.add("net.minecraft.client.main.Main"); argv.addAll(built.gameArgs)
      // GLFW init happens INSIDE Minecraft via LWJGL (glfwInit -> lwjgl_glfw -> libglfw.so). We do NOT init GLFW separately here to avoid a second context.
      set(GameLaunchState.JVM_STARTING, "Calling JLI_Launch")
      // Milestone: JLI_Launch blocks. MinecraftInitialized is reported by a log watcher in a real build
      // (watch for title screen / LWJGL window created). Until that watcher exists, we report RUNNING only
      // after JLI_Launch returns 0 OR after the game thread signals initialized via listener.
      // We do NOT fake it: if JLI returns non-zero, it is FAILED.
      val exit = jli.launch(argv.toTypedArray(), nativesDir.absolutePath)
      surface.releaseEglOnOwnerThread(); jli.cleanupOnce(); input.releaseAllOnStop()
      if (exit == 0) { set(GameLaunchState.STOPPED, "exit=0") } else { fail(GameLaunchState.FAILED, "Minecraft exited code=$exit err=${JliNativeBridge.nativeGetLastError()}", null, exit) }
    } catch (e: Throwable) { fail(GameLaunchState.FAILED, "Pipeline crashed: ${e.message}", e) } finally { started.set(false) }
  }
  fun requestStop(): Boolean {
    set(GameLaunchState.STOPPING, "Stop requested")
    stopRequested.set(true); input.releaseAllOnStop()
    val t = gameThread; if (t != null) { try { t.join(8000) } catch (e: InterruptedException) { } ; if (t.isAlive) { Log.e("FlintPipeline", "Game thread did not exit in 8s - FAILED cleanup"); set(GameLaunchState.FAILED, "Game thread did not exit"); return false } }
    set(GameLaunchState.STOPPED, "Stopped"); return true
  }
  fun onSurfaceChanged(w: Int, h: Int) { input.enqueue(FlintInputDispatcher.Ev.Resize(w, h)) }
  fun onPause() { input.enqueue(FlintInputDispatcher.Ev.Focus(false)) }
  fun onResume() { input.enqueue(FlintInputDispatcher.Ev.Focus(true)) }
}
