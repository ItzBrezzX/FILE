package com.flintlauncher.android.minecraft
import android.util.Log
import java.io.File
import org.json.JSONObject
data class AccountSession(val username: String, val uuid: String, val accessToken: String, val userType: String)
object AccountValidator {
  fun loadActiveAccount(accountsFile: File): Result<AccountSession> {
    if (!accountsFile.exists()) return Result.failure(IllegalStateException("No accounts file: ${accountsFile.path}. Login first (Microsoft or offline)."))
    return try { val root = JSONObject(accountsFile.readText()); val active = root.optJSONObject("active") ?: return Result.failure(IllegalStateException("No active account in ${accountsFile.path}")); val user = active.optString("username"); val uuid = active.optString("uuid"); val token = active.optString("accessToken"); val type = active.optString("userType", "mojang"); if (user.isEmpty() || uuid.isEmpty()) return Result.failure(IllegalStateException("Active account missing username/uuid")); if (type != "offline" && token.isEmpty()) return Result.failure(IllegalStateException("Microsoft account missing accessToken - re-login required")); Log.i("FlintAccount", "Account OK user=$user type=$type"); Result.success(AccountSession(user, uuid, token, type)) } catch (e: Throwable) { Result.failure(e) }
  }
}
