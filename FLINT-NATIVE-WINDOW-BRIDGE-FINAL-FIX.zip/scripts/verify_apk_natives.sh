#!/bin/bash
set -euo pipefail
APK=${1:-app/build/outputs/apk/debug/app-debug.apk}
echo "Checking $APK"
test -f "$APK"
unzip -l "$APK" | grep -E "liblwjgl\.so|liblwjgl_opengl\.so|liblwjgl_glfw\.so|libglfw\.so|libGL\.so|libflint_jli_bridge\.so"
echo "APK natives present (packaging only - not proof Minecraft runs)"
python3 scripts/verify_lwjgl_glfw.py app/build/outputs/apk/debug
