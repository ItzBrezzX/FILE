#!/usr/bin/env python3
"""Verify liblwjgl_glfw.so + libglfw.so separately. Fails on any missing check. No hiding failures."""
import subprocess, sys, pathlib
REQ_JNI = ["Java_org_lwjgl_glfw_GLFW_nglfwInit","Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow","Java_org_lwjgl_glfw_GLFW_nglfwDestroyWindow","Java_org_lwjgl_glfw_GLFW_nglfwMakeContextCurrent","Java_org_lwjgl_glfw_GLFW_nglfwSwapBuffers","Java_org_lwjgl_glfw_GLFW_nglfwPollEvents","Java_org_lwjgl_glfw_GLFW_nglfwWindowShouldClose"]
REQ_C = ["glfwInit","glfwCreateWindow","glfwDestroyWindow","glfwMakeContextCurrent","glfwSwapBuffers","glfwPollEvents"]
FORBIDDEN = ["libX11.so","libwayland-client.so","libc.so.6"]
def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0: raise SystemExit(f"Command failed: {cmd}\n{r.stdout}{r.stderr}")
    return r.stdout + r.stderr
def check(path):
    print(f"== {path} ==")
    if not pathlib.Path(path).exists(): print("MISSING"); return False
    hdr = run(["readelf","-h",str(path)]); print([l for l in hdr.splitlines() if "Class:" in l or "Machine:" in l])
    needed = run(["readelf","-d",str(path)]); print([l.strip() for l in needed.splitlines() if "NEEDED" in l])
    ok = True
    if "lwjgl_glfw" in str(path):
        for f in FORBIDDEN:
            if f in needed: print(f"FAIL forbidden DT_NEEDED {f}"); ok = False
        if "libglfw.so" in needed: print("FAIL adapter must NOT DT_NEEDED libglfw.so (dlopen only)"); ok = False
        syms = run(["nm","-D",str(path)])
        for s in REQ_JNI:
            if s not in syms: print(f"FAIL missing JNI {s}"); ok = False
    if str(path).endswith("libglfw.so"):
        syms = run(["nm","-D",str(path)])
        for s in REQ_C:
            if s not in syms: print(f"FAIL missing C ABI {s}"); ok = False
    print("OK" if ok else "FAIL"); return ok
if __name__ == "__main__":
    root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path("app/build")
    files = list(root.rglob("liblwjgl_glfw.so")) + list(root.rglob("libglfw.so"))
    if not files: print(f"No natives under {root}"); sys.exit(1)
    sys.exit(0 if all(check(str(f)) for f in files) else 1)
