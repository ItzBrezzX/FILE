# Apply FINAL-FIX
Branch: feature/flint-native-window-bridge. Do NOT merge to main automatically.
Base: main commit 97cfe0c, 157 commits, package com.flintlauncher.android, 17 modules, Gradle 8.9, JDK 17, platform 35.
Feature branch file list could NOT be fetched (browser no stored copy, container no internet) - patch built against REAL main structure.
Steps: checkout branch, delete files in DELETED_FILES.txt, unzip at repo root, move workflow file to .github/workflows/, merge native CMake + Gradle snippets (see docs), verify no com.flintclient remains, run CI on branch.
