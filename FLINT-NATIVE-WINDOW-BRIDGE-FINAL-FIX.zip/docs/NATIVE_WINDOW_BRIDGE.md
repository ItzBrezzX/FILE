# Native Window Bridge - FINAL-FIX
Branch: feature/flint-native-window-bridge. Package: com.flintlauncher.android. Gradle 8.9, JDK 17, platform 35.
Contradiction resolved: Before this patch, runtime was interfaces only (JavaRuntimeManager, GameLauncher, UnimplementedGameLauncher). No JRE, no JNI, no renderer. This patch adds real JLI + GLFW JNI + EGL + GL4ES + LWJGL loading + input + PLAY/STOP.
Files: runtime/ (JliLauncher, JliNativeBridge, LwjglNativeLoader, EglGameSurfaceManager, Gl4esBridge, FlintInputBridge), minecraft/ (RealLaunchPipeline, LaunchArgumentBuilder, validators), app/ui/GameActivity, native/ (lwjgl-glfw-jni + jli-bridge).
Gradle: Do NOT change versions. runtime/build.gradle.kts + minecraft/build.gradle.kts + app/build.gradle.kts: add packaging for liblwjgl_glfw.so + libflint_jli_bridge.so + libglfw.so + libGL.so per ABI. See workflow.
GLFW: libglfw.so (C ABI) != liblwjgl_glfw.so (JNI adapter). Adapter dlopen libglfw.so, dispatches events via queue + function pointers.
JLI: JliLauncher.launch() blocks on game thread, calls nativeLaunchJli -> dlopen libjli.so -> JLI_Launch. No placeholder. Double init/shutdown prevented.
PLAY/STOP: GameActivity PLAY -> RealLaunchPipeline.start() (ONE game thread). STOP -> requestStop() -> join + EGL release + JNI detach. States: PREPARING/JVM_STARTING/GAME_INITIALIZING/RUNNING/STOPPING/STOPPED/FAILED.
