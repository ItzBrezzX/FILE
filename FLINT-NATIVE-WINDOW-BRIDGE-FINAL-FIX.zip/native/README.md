# native/ — Flint Native Window Bridge
Real repo: package com.flintlauncher.android, Gradle 8.9, JDK 17, platform 35, multi-module.
Targets:
- native/lwjgl-glfw-jni -> liblwjgl_glfw.so (LWJGL GLFW JNI adapter, LWJGL 3.3.3). Forwards to Flint libglfw.so via dlopen. No desktop GLFW link.
- native/jli-bridge -> libflint_jli_bridge.so (JLI_Launch bridge). dlopen <jre>/lib/libjli.so, dlsym JLI_Launch, call on game thread.
Merge these targets into the repo's existing native CMake (do not create a second unrelated build). ABI: arm64-v8a primary (itel A665L), armeabi-v7a secondary.
libglfw.so (Flint C ABI) != liblwjgl_glfw.so (JNI adapter). Both required.
