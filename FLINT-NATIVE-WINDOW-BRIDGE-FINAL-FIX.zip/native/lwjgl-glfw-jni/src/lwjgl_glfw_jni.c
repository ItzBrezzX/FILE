// Flint liblwjgl_glfw.so - LWJGL 3.3.3 GLFW JNI adapter, REAL callbacks.
// Previous patch bug: callbacks only stored jlong, never called. Fixed here:
// - Event queue (mutex + ring buffer) fed by FlintGlfwEventBridge.nativeEnqueue* (called from GameInputDispatcher on game thread).
// - glfwPollEvents() drains queue and CALLS the stored LWJGL callback function pointers with correct args.
// - JNI: store JavaVM in JNI_OnLoad, GetEnv/AttachCurrentThread per call, DeleteLocalRef, no leaked local refs.
// - Error reporting: last error string via Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge nativeGetLastError (see below).
// - No desktop GLFW link: libglfw.so via dlopen only, DT_NEEDED must NOT contain libglfw.so / X11 / GLIBC.
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#define LOG_TAG "FlintLwjglGlfw"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
static JavaVM* g_vm = NULL;
static char g_lastError[1024] = "";
static void setError(const char* m) { strncpy(g_lastError, m, sizeof(g_lastError)-1); g_lastError[sizeof(g_lastError)-1]='\0'; LOGE("%s", m); }
// --- Flint libglfw.so C ABI ---
typedef int (*glfwInit_fn)(void); typedef void (*glfwTerminate_fn)(void);
typedef void (*glfwWindowHint_fn)(int,int); typedef void* (*glfwCreateWindow_fn)(int,int,const char*,void*,void*);
typedef void (*glfwDestroyWindow_fn)(void*); typedef void (*glfwMakeContextCurrent_fn)(void*);
typedef void* (*glfwGetCurrentContext_fn)(void); typedef void (*glfwSwapBuffers_fn)(void*);
typedef void (*glfwPollEvents_fn)(void); typedef int (*glfwWindowShouldClose_fn)(void*);
typedef void (*glfwSetWindowShouldClose_fn)(void*,int); typedef void (*glfwSwapInterval_fn)(int);
typedef double (*glfwGetTime_fn)(void); typedef void (*glfwGetWindowSize_fn)(void*,int*,int*);
typedef void (*glfwGetFramebufferSize_fn)(void*,int*,int*); typedef void (*glfwGetCursorPos_fn)(void*,double*,double*);
typedef int (*glfwGetKey_fn)(void*,int); typedef int (*glfwGetMouseButton_fn)(void*,int);
typedef void (*glfwSetInputMode_fn)(void*,int,int); typedef int (*glfwGetInputMode_fn)(void*,int);
static void* g_h = NULL;
static glfwInit_fn p_Init=NULL; static glfwTerminate_fn p_Term=NULL; static glfwWindowHint_fn p_Hint=NULL;
static glfwCreateWindow_fn p_Create=NULL; static glfwDestroyWindow_fn p_Destroy=NULL; static glfwMakeContextCurrent_fn p_Make=NULL;
static glfwGetCurrentContext_fn p_Cur=NULL; static glfwSwapBuffers_fn p_Swap=NULL; static glfwPollEvents_fn p_Poll=NULL;
static glfwWindowShouldClose_fn p_Should=NULL; static glfwSetWindowShouldClose_fn p_SetShould=NULL; static glfwSwapInterval_fn p_Interval=NULL;
static glfwGetTime_fn p_Time=NULL; static glfwGetWindowSize_fn p_WSize=NULL; static glfwGetFramebufferSize_fn p_FSize=NULL;
static glfwGetCursorPos_fn p_CPos=NULL; static glfwGetKey_fn p_GetKey=NULL; static glfwGetMouseButton_fn p_GetBtn=NULL;
static glfwSetInputMode_fn p_SetMode=NULL; static glfwGetInputMode_fn p_GetMode=NULL;
static int ensureLoaded(void) {
  if (g_h) return 1;
  void* h = dlopen("libglfw.so", RTLD_NOW|RTLD_LOCAL);
  if (!h) { char b[1024]; snprintf(b,sizeof(b),"dlopen libglfw.so failed: %s", dlerror()); setError(b); return 0; }
  g_h = h;
  #define R(s,t) do { p_##s = (t) dlsym(g_h, #s); if (!p_##s) LOGE("dlsym %s missing", #s); } while(0)
  R(glfwInit,glfwInit_fn); R(glfwTerminate,glfwTerminate_fn); R(glfwWindowHint,glfwWindowHint_fn); R(glfwCreateWindow,glfwCreateWindow_fn);
  R(glfwDestroyWindow,glfwDestroyWindow_fn); R(glfwMakeContextCurrent,glfwMakeContextCurrent_fn); R(glfwGetCurrentContext,glfwGetCurrentContext_fn);
  R(glfwSwapBuffers,glfwSwapBuffers_fn); R(glfwPollEvents,glfwPollEvents_fn); R(glfwWindowShouldClose,glfwWindowShouldClose_fn);
  R(glfwSetWindowShouldClose,glfwSetWindowShouldClose_fn); R(glfwSwapInterval,glfwSwapInterval_fn); R(glfwGetTime,glfwGetTime_fn);
  R(glfwGetWindowSize,glfwGetWindowSize_fn); R(glfwGetFramebufferSize,glfwGetFramebufferSize_fn); R(glfwGetCursorPos,glfwGetCursorPos_fn);
  R(glfwGetKey,glfwGetKey_fn); R(glfwGetMouseButton,glfwGetMouseButton_fn); R(glfwSetInputMode,glfwSetInputMode_fn); R(glfwGetInputMode,glfwGetInputMode_fn);
  #undef R
  if (!p_Init || !p_Create) { setError("libglfw.so missing core symbols"); return 0; }
  LOGI("libglfw.so loaded via dlopen"); return 1;
}
// --- LWJGL callback function pointers (from jlong set by LWJGL Java) ---
typedef void (*KeyFun)(void*,int,int,int,int); typedef void (*CharFun)(void*,unsigned int);
typedef void (*MouseBtnFun)(void*,int,int,int); typedef void (*CursorFun)(void*,double,double);
typedef void (*ScrollFun)(void*,double,double); typedef void (*FbSizeFun)(void*,int,int);
typedef void (*WinSizeFun)(void*,int,int); typedef void (*FocusFun)(void*,int);
static KeyFun g_keyCb=NULL; static CharFun g_charCb=NULL; static MouseBtnFun g_btnCb=NULL;
static CursorFun g_cursorCb=NULL; static ScrollFun g_scrollCb=NULL; static FbSizeFun g_fbCb=NULL;
static WinSizeFun g_winSizeCb=NULL; static FocusFun g_focusCb=NULL;
static void* g_currentWindow = NULL;
// --- Event queue ---
typedef enum { EV_KEY, EV_CHAR, EV_BTN, EV_CURSOR, EV_SCROLL, EV_FB, EV_FOCUS } EvType;
typedef struct { EvType type; int a; int b; int c; int d; double x; double y; } Ev;
#define QCAP 512
static Ev g_q[QCAP]; static int g_qHead=0, g_qTail=0, g_qCount=0; static pthread_mutex_t g_qMu = PTHREAD_MUTEX_INITIALIZER;
static int qPush(Ev e) { pthread_mutex_lock(&g_qMu); if (g_qCount >= QCAP) { g_qHead = (g_qHead+1)%QCAP; g_qCount--; } g_q[g_qTail]=e; g_qTail=(g_qTail+1)%QCAP; g_qCount++; pthread_mutex_unlock(&g_qMu); return 0; }
static int qPop(Ev* out) { pthread_mutex_lock(&g_qMu); if (g_qCount==0) { pthread_mutex_unlock(&g_qMu); return 0; } *out=g_q[g_qHead]; g_qHead=(g_qHead+1)%QCAP; g_qCount--; pthread_mutex_unlock(&g_qMu); return 1; }
static void dispatchQueue(void) {
  Ev e; while (qPop(&e)) {
    void* w = g_currentWindow;
    if (!w) continue;
    switch (e.type) {
      case EV_KEY: if (g_keyCb) g_keyCb(w, e.a, e.b, e.c, e.d); break;
      case EV_CHAR: if (g_charCb) g_charCb(w, (unsigned int)e.a); break;
      case EV_BTN: if (g_btnCb) g_btnCb(w, e.a, e.b, e.c); break;
      case EV_CURSOR: if (g_cursorCb) g_cursorCb(w, e.x, e.y); break;
      case EV_SCROLL: if (g_scrollCb) g_scrollCb(w, e.x, e.y); break;
      case EV_FB: if (g_fbCb) g_fbCb(w, e.a, e.b); break;
      case EV_FOCUS: if (g_focusCb) g_focusCb(w, e.a); break;
    }
  }
}
// --- Flint enqueue JNI (called from Kotlin FlintGlfwEventBridge on game thread) ---
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueKey(JNIEnv* env, jobject th, jint key, jint sc, jint act, jint mods) { (void)env;(void)th; Ev e={EV_KEY,key,sc,act,mods,0,0}; return qPush(e); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueChar(JNIEnv* env, jobject th, jint cp) { (void)env;(void)th; Ev e={EV_CHAR,cp,0,0,0,0,0}; return qPush(e); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueMouseButton(JNIEnv* env, jobject th, jint b, jint a, jint m) { (void)env;(void)th; Ev e={EV_BTN,b,a,m,0,0,0}; return qPush(e); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueCursorPos(JNIEnv* env, jobject th, jdouble x, jdouble y) { (void)env;(void)th; Ev e={EV_CURSOR,0,0,0,0,x,y}; return qPush(e); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueScroll(JNIEnv* env, jobject th, jdouble x, jdouble y) { (void)env;(void)th; Ev e={EV_SCROLL,0,0,0,0,x,y}; return qPush(e); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueFramebufferSize(JNIEnv* env, jobject th, jint w, jint h) { (void)env;(void)th; Ev e={EV_FB,w,h,0,0,0,0}; return qPush(e); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_FlintGlfwEventBridge_nativeEnqueueFocus(JNIEnv* env, jobject th, jboolean f) { (void)env;(void)th; Ev e={EV_FOCUS,f?1:0,0,0,0,0,0}; return qPush(e); }
// --- LWJGL JNI ---
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* r) { (void)r; g_vm=vm; LOGI("liblwjgl_glfw JNI_OnLoad"); return JNI_VERSION_1_6; }
JNIEXPORT jboolean JNICALL Java_org_lwjgl_glfw_GLFW_nglfwInit(JNIEnv* env, jclass c) { (void)env;(void)c; if (!ensureLoaded()) return JNI_FALSE; return p_Init() ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwTerminate(JNIEnv* env, jclass c) { (void)env;(void)c; if (p_Term) p_Term(); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwWindowHint(JNIEnv* env, jclass c, jint h, jint v) { (void)env;(void)c; if (ensureLoaded() && p_Hint) p_Hint((int)h,(int)v); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwDefaultWindowHints(JNIEnv* env, jclass c) { (void)env;(void)c; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwCreateWindow(JNIEnv* env, jclass c, jint w, jint h, jlong titleAddr, jlong mon, jlong share) { (void)env;(void)c;(void)mon;(void)share; if (!ensureLoaded() || !p_Create) return 0; const char* t = titleAddr ? (const char*)(intptr_t)titleAddr : "FLINT"; void* win = p_Create((int)w,(int)h,t,NULL,NULL); g_currentWindow = win; LOGI("glfwCreateWindow %dx%d -> %p",(int)w,(int)h,win); return (jlong)(intptr_t)win; }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwDestroyWindow(JNIEnv* env, jclass c, jlong w) { (void)env;(void)c; if (p_Destroy) p_Destroy((void*)(intptr_t)w); if ((void*)(intptr_t)w == g_currentWindow) g_currentWindow = NULL; }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwMakeContextCurrent(JNIEnv* env, jclass c, jlong w) { (void)env;(void)c; if (p_Make) p_Make((void*)(intptr_t)w); }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetCurrentContext(JNIEnv* env, jclass c) { (void)env;(void)c; if (!p_Cur) return 0; return (jlong)(intptr_t)p_Cur(); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSwapBuffers(JNIEnv* env, jclass c, jlong w) { (void)env;(void)c; if (p_Swap) p_Swap((void*)(intptr_t)w); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwPollEvents(JNIEnv* env, jclass c) { (void)env;(void)c; if (p_Poll) p_Poll(); dispatchQueue(); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwWaitEvents(JNIEnv* env, jclass c) { (void)env;(void)c; dispatchQueue(); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwPostEmptyEvent(JNIEnv* env, jclass c) { (void)env;(void)c; }
JNIEXPORT jboolean JNICALL Java_org_lwjgl_glfw_GLFW_nglfwWindowShouldClose(JNIEnv* env, jclass c, jlong w) { (void)env;(void)c; if (!p_Should) return JNI_TRUE; return p_Should((void*)(intptr_t)w) ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowShouldClose(JNIEnv* env, jclass c, jlong w, jboolean v) { (void)env;(void)c; if (p_SetShould) p_SetShould((void*)(intptr_t)w, v?1:0); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSwapInterval(JNIEnv* env, jclass c, jint i) { (void)env;(void)c; if (p_Interval) p_Interval((int)i); }
JNIEXPORT jdouble JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetTime(JNIEnv* env, jclass c) { (void)env;(void)c; if (!p_Time) return 0.0; return (jdouble)p_Time(); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetWindowSize(JNIEnv* env, jclass c, jlong w, jlong wa, jlong ha) { (void)env;(void)c; if (!p_WSize) return; int a=0,b=0; p_WSize((void*)(intptr_t)w,&a,&b); if (wa) *(int*)(intptr_t)wa=a; if (ha) *(int*)(intptr_t)ha=b; }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetFramebufferSize(JNIEnv* env, jclass c, jlong w, jlong wa, jlong ha) { (void)env;(void)c; if (!p_FSize) return; int a=0,b=0; p_FSize((void*)(intptr_t)w,&a,&b); if (wa) *(int*)(intptr_t)wa=a; if (ha) *(int*)(intptr_t)ha=b; }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetCursorPos(JNIEnv* env, jclass c, jlong w, jlong xa, jlong ya) { (void)env;(void)c; if (!p_CPos) return; double x=0,y=0; p_CPos((void*)(intptr_t)w,&x,&y); if (xa) *(double*)(intptr_t)xa=x; if (ya) *(double*)(intptr_t)ya=y; }
JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetKey(JNIEnv* env, jclass c, jlong w, jint k) { (void)env;(void)c; if (!p_GetKey) return 0; return (jint)p_GetKey((void*)(intptr_t)w,(int)k); }
JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetMouseButton(JNIEnv* env, jclass c, jlong w, jint b) { (void)env;(void)c; if (!p_GetBtn) return 0; return (jint)p_GetBtn((void*)(intptr_t)w,(int)b); }
JNIEXPORT void JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetInputMode(JNIEnv* env, jclass c, jlong w, jint m, jint v) { (void)env;(void)c; if (p_SetMode) p_SetMode((void*)(intptr_t)w,(int)m,(int)v); }
JNIEXPORT jint JNICALL Java_org_lwjgl_glfw_GLFW_nglfwGetInputMode(JNIEnv* env, jclass c, jlong w, jint m) { (void)env;(void)c; if (!p_GetMode) return 0; return (jint)p_GetMode((void*)(intptr_t)w,(int)m); }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetKeyCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; KeyFun prev=g_keyCb; g_keyCb=(KeyFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetCharCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; CharFun prev=g_charCb; g_charCb=(CharFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetMouseButtonCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; MouseBtnFun prev=g_btnCb; g_btnCb=(MouseBtnFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetCursorPosCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; CursorFun prev=g_cursorCb; g_cursorCb=(CursorFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetScrollCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; ScrollFun prev=g_scrollCb; g_scrollCb=(ScrollFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetFramebufferSizeCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; FbSizeFun prev=g_fbCb; g_fbCb=(FbSizeFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowSizeCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; WinSizeFun prev=g_winSizeCb; g_winSizeCb=(WinSizeFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
JNIEXPORT jlong JNICALL Java_org_lwjgl_glfw_GLFW_nglfwSetWindowFocusCallback(JNIEnv* env, jclass c, jlong w, jlong cb) { (void)env;(void)c;(void)w; FocusFun prev=g_focusCb; g_focusCb=(FocusFun)(intptr_t)cb; return (jlong)(intptr_t)prev; }
