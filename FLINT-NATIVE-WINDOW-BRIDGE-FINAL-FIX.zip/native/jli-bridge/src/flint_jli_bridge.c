// Flint JLI bridge - REAL JLI_Launch, no placeholder.
// Kotlin: JliNativeBridge.nativeLaunchJli(jreDir, argv, libraryPath) -> int
// C: dlopen <jreDir>/lib/libjli.so, dlsym JLI_Launch, call on caller thread (game thread).
// Double init: atomic g_running. Double shutdown: atomic g_stopped.
// JNI: store JavaVM in JNI_OnLoad, use GetEnv/AttachCurrentThread for error callback if needed.
// No fake return: on dlopen/dlsym failure return negative code + store last error string.
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <pthread.h>
#include <stdatomic.h>
#include <string.h>
#include <stdlib.h>
#define LOG_TAG "FlintJLI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
static JavaVM* g_vm = NULL;
static atomic_int g_running = 0;
static atomic_int g_stopRequested = 0;
static char g_lastError[1024] = "";
static void setError(const char* m) { strncpy(g_lastError, m, sizeof(g_lastError)-1); g_lastError[sizeof(g_lastError)-1]='\0'; LOGE("%s", m); }
typedef int (*JLI_Launch_t)(int argc, char** argv, int jargc, const char** jargv, int appclassc, const char** appclassv, const char* fullversion, const char* dotversion, const char* pname, const char* lname, jboolean javaargs, jboolean cpwildcard, jboolean javaw, jint ergo);
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* r) { (void)r; g_vm = vm; LOGI("flint_jli_bridge JNI_OnLoad"); return JNI_VERSION_1_6; }
JNIEXPORT jstring JNICALL Java_com_flintlauncher_android_runtime_JliNativeBridge_nativeGetLastError(JNIEnv* env, jobject thiz) { (void)thiz; return (*env)->NewStringUTF(env, g_lastError); }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_JliNativeBridge_nativeIsRunning(JNIEnv* env, jobject thiz) { (void)env; (void)thiz; return atomic_load(&g_running) ? 1 : 0; }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_JliNativeBridge_nativeRequestStop(JNIEnv* env, jobject thiz) { (void)env; (void)thiz; atomic_store(&g_stopRequested, 1); LOGI("JLI stop requested"); return 0; }
JNIEXPORT jint JNICALL Java_com_flintlauncher_android_runtime_JliNativeBridge_nativeLaunchJli(JNIEnv* env, jobject thiz, jstring jreDir, jobjectArray argv, jstring libraryPath) {
  (void)thiz; (void)libraryPath;
  if (atomic_exchange(&g_running, 1)) { setError("JLI already running - double init prevented"); return -1; }
  atomic_store(&g_stopRequested, 0);
  const char* jre = (*env)->GetStringUTFChars(env, jreDir, NULL);
  if (!jre) { atomic_store(&g_running, 0); setError("jreDir null"); return -5; }
  char libjli[1024]; snprintf(libjli, sizeof(libjli), "%s/lib/libjli.so", jre);
  (*env)->ReleaseStringUTFChars(env, jreDir, jre);
  void* h = dlopen(libjli, RTLD_NOW | RTLD_LOCAL);
  if (!h) { char buf[1024]; snprintf(buf, sizeof(buf), "dlopen %s failed: %s", libjli, dlerror()); setError(buf); atomic_store(&g_running, 0); return -2; }
  JLI_Launch_t launch = (JLI_Launch_t) dlsym(h, "JLI_Launch");
  if (!launch) { setError("dlsym JLI_Launch failed"); dlclose(h); atomic_store(&g_running, 0); return -3; }
  jsize argc = (*env)->GetArrayLength(env, argv);
  if (argc < 1) { setError("argv empty"); dlclose(h); atomic_store(&g_running, 0); return -5; }
  char** cargv = calloc((size_t)argc + 1, sizeof(char*));
  for (jsize i = 0; i < argc; i++) { jstring s = (jstring)(*env)->GetObjectArrayElement(env, argv, i); const char* cs = (*env)->GetStringUTFChars(env, s, NULL); cargv[i] = strdup(cs ? cs : ""); if (cs) (*env)->ReleaseStringUTFChars(env, s, cs); (*env)->DeleteLocalRef(env, s); }
  cargv[argc] = NULL;
  LOGI("Calling JLI_Launch argc=%d", (int)argc);
  // JLI_Launch signature: (argc, argv, jargc, jargv, appclassc, appclassv, fullversion, dotversion, pname, lname, javaargs, cpwildcard, javaw, ergo)
  // For embedded launch we pass argc/argv as the full command line; jargc=0.
  int ret = launch((int)argc, cargv, 0, NULL, 0, NULL, "", "", "java", "java", JNI_FALSE, JNI_FALSE, JNI_FALSE, 0);
  char buf[128]; snprintf(buf, sizeof(buf), "JLI_Launch returned %d", ret); LOGI("%s", buf);
  for (jsize i = 0; i < argc; i++) free(cargv[i]); free(cargv);
  dlclose(h);
  atomic_store(&g_running, 0);
  return ret;
}
