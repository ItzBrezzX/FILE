@rem FLINT CLIENT - Gradle wrapper for Windows
@rem gradle-wrapper.jar belum di-commit (lihat gradle/wrapper/NOTE.md). Kalau jar ada, pakai jar. Kalau tidak, pakai gradle dari PATH.
@echo off
set APP_HOME=%~dp0
if exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  if defined JAVA_HOME (
    "%JAVA_HOME%\bin\java.exe" -jar "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" %*
  ) else (
    java -jar "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" %*
  )
) else (
  echo FLINT: gradle-wrapper.jar not found, using system gradle
  gradle %*
)
