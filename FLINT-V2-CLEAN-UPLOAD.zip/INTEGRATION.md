# INTEGRATION - ItzBrezzX/Flint-Launcher (JANGAN timpa main langsung)

Repo target: https://github.com/ItzBrezzX/Flint-Launcher

## 1. Siapkan branch baru (di local, JANGAN push ke main)
```bash
git clone https://github.com/ItzBrezzX/Flint-Launcher.git
cd Flint-Launcher
git checkout -b flint-v2-complete-repair
# Backup main dulu
git branch backup-main-before-flint-v2
```

## 2. Salin ZIP ini ke repo (ganti semua file, kecuali .git)
- Extract `FLINT-V2-COMPLETE-REPAIR.zip` ke folder sementara
- Copy semua file (termasuk `.github/workflows/build.yml`) ke root repo, timpa yang lama
- JANGAN copy `gradlew_1`, `gradlew_2` (sudah dihapus) - hanya `gradlew` yang benar
- Jika `.github` ke-strip saat upload (GitHub web upload kadang buang dotfolder):
  copy `github-workflow-build.yml` -> `.github/workflows/build.yml` manual

## 3. Cek diff sebelum commit
```bash
git status --short
git diff --stat
# Harus lihat: RendererManager.kt, MobileGLUESManager.kt, LaunchManager.kt, CMakeLists.txt, GameActivity.kt, BridgeClasspath.kt (baru), mipmap-*, REPAIR_REPORT.md, README.md, INTEGRATION.md
git add -A
git commit -m "FLINT V2-FINAL: fix duplicate RendererType, LaunchManager enum, CMake flint_jvm->flint_egl, mipmap, GameActivity EGL thread, BridgeClasspath docs"
git push -u origin flint-v2-complete-repair
```

## 4. GitHub Actions
- Buka repo -> Actions -> "FLINT CLIENT - Build APK" -> Run workflow di branch `flint-v2-complete-repair`
- Jika hijau: download Artifacts `FLINT-CLIENT-debug-apk` -> install di HP ARM64 -> test PLAY
- Jika merah: buka log, cari `e: ... .kt: (line, col)` atau `CMake Error` - itu error compile yang belum ketemu di sandbox, perbaiki di branch yang sama, push lagi (Actions jalan otomatis)

## 5. Merge ke main (hanya setelah Actions hijau + test device)
- Buat Pull Request: `flint-v2-complete-repair` -> `main`
- Reviewer cek: REPAIR_REPORT.md, Test Results (BLOCKED/NOT TESTED jangan diklaim PASS), tidak ada secret di commit
- Merge via Squash atau Merge commit, JANGAN force-push ke main
- Hapus branch setelah merge: `git push origin --delete flint-v2-complete-repair`

## 6. Yang TIDAK ada di ZIP ini (harus di-download di device / CI)
- `gradle/wrapper/gradle-wrapper.jar` - tidak di-commit (binary). `gradlew` di repo ini fallback ke `gradle` dari PATH (GitHub Actions `setup-gradle` menyediakannya). Di local: jalankan `gradle wrapper` sekali untuk generate jar.
- `flint-bridge.jar` - belum di-build (lihat BridgeClasspath.kt, task `buildBridgeJar` disabled)
- Pojav JRE, LWJGL Android, MobileGLUES .so - di-download di device saat first launch (via GitHub API), bukan di repo

## 7. Secrets - JANGAN commit
- Jangan commit `keystore`, `local.properties`, `google-services.json`, token Microsoft, atau `accounts.json` dari `flint/accounts/`
- `.gitignore` harus berisi: `*.keystore`, `local.properties`, `build/`, `.gradle/`, `*.apk` (kecuali release di Releases)
