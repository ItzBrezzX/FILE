package com.flintclient

import com.flintclient.core.version.Library
import com.flintclient.core.version.LibraryResolver
import com.flintclient.core.version.Rule
import org.junit.Assert.*
import org.junit.Test

class LibraryResolverTest {
    @Test fun testWindowsLibraryBlocked() {
        val lib = Library(name = "test:windows:1.0", rules = listOf(Rule(action = "allow", os = com.flintclient.core.version.OsRule(name = "windows"))))
        // On Android (linux) windows-only lib should be disallowed by our resolver logic via isAllowed check
        // Our LibraryResolver.isLibraryAllowed returns false for windows-only because rule applies false -> allowed stays false
        assertFalse(LibraryResolver.isLibraryAllowed(lib))
    }
    @Test fun testNoRulesAllowed() {
        val lib = Library(name = "test:common:1.0")
        assertTrue(LibraryResolver.isLibraryAllowed(lib))
    }
}
