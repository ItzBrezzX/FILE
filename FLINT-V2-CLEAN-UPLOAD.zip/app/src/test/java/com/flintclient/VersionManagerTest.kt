package com.flintclient

import com.flintclient.core.launch.LaunchArguments
import org.junit.Assert.*
import org.junit.Test

class VersionManagerTest {
    @Test fun testSplitArgs() {
        val args = LaunchArguments.splitArgs("-Xmx2048m -Dfoo=\"bar baz\" --game")
        assertEquals(3, args.size)
        assertEquals("-Xmx2048m", args[0])
        assertEquals("-Dfoo=bar baz", args[1])
    }
    @Test fun testSplitArgsSimple() {
        val args = LaunchArguments.splitArgs("--username Steve --version 1.21.1")
        assertEquals(4, args.size)
    }
    @Test fun testPlaceholderReplace() {
        val input = "\${natives_directory}/lib.so"
        val replaced = input.replace("\${natives_directory}", "/data/natives")
        assertEquals("/data/natives/lib.so", replaced)
    }
}
