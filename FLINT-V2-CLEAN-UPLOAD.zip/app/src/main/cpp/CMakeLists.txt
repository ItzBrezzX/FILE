cmake_minimum_required(VERSION 3.22.1)
project(flint)
# FIX: previous CMake built only libflint_jvm.so but Kotlin loaded flint_egl / flint_glfw / flint_input / flint_gl.
# That caused UnsatisfiedLinkError on every launch. Now we build 5 libs with EXACT names Kotlin expects.
# flint_jvm: JNI_CreateJavaVM + Minecraft main invocation
# flint_egl: EGL display/config/context/surface
# flint_gl: GL version query + fullbright flag (thin wrapper over GLES3, NOT a full GL4ES - see REPAIR_REPORT.md)
# flint_glfw: Android GLFW backend - window, event queue, input, time, swap
# flint_input: input event queue bridge Java -> native GLFW queue
add_library(flint_jvm SHARED flint_jvm.cpp)
add_library(flint_egl SHARED flint_egl.cpp)
add_library(flint_gl SHARED flint_gl.cpp)
add_library(flint_glfw SHARED flint_glfw.cpp)
add_library(flint_input SHARED flint_input.cpp)
find_library(log-lib log)
find_library(android-lib android)
find_library(egl-lib EGL)
find_library(glesv2-lib GLESv2)
find_library(glesv3-lib GLESv3)
# FIX: flint_jvm calls flint_egl_init_on_current_thread() defined in flint_egl.cpp.
# Without linking, flint_jvm.so has undefined symbol -> dlopen fails at runtime.
target_link_libraries(flint_jvm ${log-lib} ${android-lib} flint_egl)
target_link_libraries(flint_egl ${log-lib} ${android-lib} ${egl-lib} ${glesv3-lib})
target_link_libraries(flint_gl ${log-lib} ${android-lib} ${glesv3-lib})
target_link_libraries(flint_glfw ${log-lib} ${android-lib})
target_link_libraries(flint_input ${log-lib} ${android-lib})
# NOTE: libjvm.so is NOT linked here. It is downloaded at runtime from Pojav Android JRE (JavaRuntimeManager, Bionic) - NOT Adoptium glibc.
# and loaded via System.load(absolutePath) BEFORE JNIVMLauncher.createJVM() is called.
# Linking it at build time would fail because the JDK is not in the NDK sysroot.
