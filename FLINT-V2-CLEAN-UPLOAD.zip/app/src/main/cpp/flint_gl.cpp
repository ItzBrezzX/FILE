// FLINT GL - Thin GLES3 wrapper (repaired Phase 5)
// HONEST LABEL: This is NOT a full GL4ES. Full GL4ES is ~200k lines, cannot be vendored here.
// Real GL4ES / MobileGLUES must be downloaded as prebuilt .so (see RendererManager + MobileGLUESManager).
// This file only provides version query + fullbright flag that FLINT's Kotlin code uses.
// If MobileGLUES .so is present, it is loaded FIRST (MobileGLUESManager.loadRenderer) and takes over GL calls.
// If not present, Minecraft will fail with clear error "Renderer .so missing" - never silently pretend GL4ES works.
#include <GLES3/gl3.h>
#include <android/log.h>
#include <jni.h>
#define LOG_TAG "FLINT-GL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
static int g_fullbright = 0;
extern "C" {
JNIEXPORT jstring JNICALL Java_com_flintclient_native_FlintGL_nativeGetGLVersion(JNIEnv* env, jclass c) {
    const GLubyte* v = glGetString(GL_VERSION);
    const char* s = v ? (const char*)v : "unknown - no GL context yet";
    return env->NewStringUTF(s);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGL_nativeSetFullbright(JNIEnv* env, jclass c, jboolean enabled) {
    g_fullbright = enabled ? 1 : 0;
    LOGI("Fullbright flag=%d (applied via -Dflint.fullbright + gamma in Minecraft)", g_fullbright);
}
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintGL_nativeIsFullbright(JNIEnv* env, jclass c) { return g_fullbright ? JNI_TRUE : JNI_FALSE; }
}
