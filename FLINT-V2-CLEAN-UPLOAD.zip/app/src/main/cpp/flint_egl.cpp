// FLINT EGL - Thread affinity BENAR (V2)
// BUG LAMA: EGL dibuat di UI thread (surfaceCreated), dipakai di JVM thread -> EGL_BAD_CONTEXT / black screen.
// YANG BENAR (Pojav): EGL display/config/context/surface DIBUAT + MAKE-CURRENT di thread yang sama dengan render (JVM thread).
// Fungsi flint_egl_init_on_current_thread() HANYA dipanggil dari jvm_thread_entry di flint_jvm.cpp.
// Fungsi JNI nativeInitEGL() lama dipertahankan untuk kompatibilitas, tapi sekarang dia HANYA nyimpen Surface,
// EGL beneran dibuat di JVM thread. Jangan panggil nativeInitEGL dari UI thread lalu anggap EGL ready.
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <android/log.h>
#include <jni.h>
#include <pthread.h>
#define LOG_TAG "FLINT-EGL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
static EGLDisplay g_display = EGL_NO_DISPLAY;
static EGLContext g_context = EGL_NO_CONTEXT;
static EGLSurface g_surface = EGL_NO_SURFACE;
static ANativeWindow* g_window = nullptr;
static int g_width=0, g_height=0;
static pthread_t g_eglThread = 0;
static bool g_eglReady = false;
static bool egl_init_internal(ANativeWindow* window) {
    if (g_eglReady && pthread_equal(g_eglThread, pthread_self())) { LOGI("EGL sudah init di thread ini"); return true; }
    if (g_eglReady && !pthread_equal(g_eglThread, pthread_self())) {
        LOGE("EGL init dipanggil dari thread BERBEDA! EGL thread=%lu, current=%lu - REJECTED. EGL harus di JVM thread.", (unsigned long)g_eglThread, (unsigned long)pthread_self());
        return false;
    }
    g_window = window;
    g_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (g_display==EGL_NO_DISPLAY) { LOGE("eglGetDisplay failed 0x%x", eglGetError()); return false; }
    EGLint major, minor;
    if (!eglInitialize(g_display, &major, &minor)) { LOGE("eglInitialize failed 0x%x", eglGetError()); return false; }
    LOGI("EGL %d.%d di thread %lu", major, minor, (unsigned long)pthread_self());
    const EGLint attribs[] = { EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_STENCIL_SIZE, 8, EGL_NONE };
    EGLConfig config; EGLint numConfigs;
    if (!eglChooseConfig(g_display, attribs, &config, 1, &numConfigs) || numConfigs==0) { LOGE("eglChooseConfig failed"); return false; }
    const EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    g_context = eglCreateContext(g_display, config, EGL_NO_CONTEXT, ctxAttribs);
    if (g_context==EGL_NO_CONTEXT) { LOGE("eglCreateContext failed 0x%x", eglGetError()); return false; }
    g_surface = eglCreateWindowSurface(g_display, config, g_window, nullptr);
    if (g_surface==EGL_NO_SURFACE) { LOGE("eglCreateWindowSurface failed 0x%x", eglGetError()); return false; }
    if (!eglMakeCurrent(g_display, g_surface, g_surface, g_context)) { LOGE("eglMakeCurrent failed 0x%x", eglGetError()); return false; }
    EGLint w,h; eglQuerySurface(g_display, g_surface, EGL_WIDTH, &w); eglQuerySurface(g_display, g_surface, EGL_HEIGHT, &h);
    g_width=w; g_height=h; g_eglThread=pthread_self(); g_eglReady=true;
    LOGI("EGL ready %dx%d GL=%s di JVM thread", w, h, glGetString(GL_VERSION));
    return true;
}
bool flint_egl_init_on_current_thread(ANativeWindow* window, int w, int h) { return egl_init_internal(window); }
void flint_egl_destroy_on_current_thread() {
    if (!g_eglReady) return;
    if (!pthread_equal(g_eglThread, pthread_self())) { LOGE("EGL destroy dari thread beda - skip, biar tidak crash"); return; }
    LOGI("EGL destroy di JVM thread");
    if (g_display!=EGL_NO_DISPLAY) eglMakeCurrent(g_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (g_surface!=EGL_NO_SURFACE) { eglDestroySurface(g_display, g_surface); g_surface=EGL_NO_SURFACE; }
    if (g_context!=EGL_NO_CONTEXT) { eglDestroyContext(g_display, g_context); g_context=EGL_NO_CONTEXT; }
    if (g_display!=EGL_NO_DISPLAY) { eglTerminate(g_display); g_display=EGL_NO_DISPLAY; }
    g_eglReady=false; g_eglThread=0;
}
extern "C" {
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintEGL_nativeInitEGL(JNIEnv* env, jclass c, jobject surface) {
    LOGE("nativeInitEGL dari UI thread DEPRECATED - EGL beneran dibuat di JVM thread via flint_jvm.cpp. Surface disimpan, bukan di-init di sini.");
    return JNI_FALSE;
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintEGL_nativeSwapBuffers(JNIEnv* env, jclass c) {
    if (!g_eglReady) return;
    if (!pthread_equal(g_eglThread, pthread_self())) { LOGE("swapBuffers dari thread beda - EGL context milik JVM thread, skip"); return; }
    eglSwapBuffers(g_display, g_surface);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintEGL_nativeDestroyEGL(JNIEnv* env, jclass c) { flint_egl_destroy_on_current_thread(); }
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintEGL_nativeResize(JNIEnv* env, jclass c, jint w, jint h) {
    if (w==g_width && h==g_height) return;
    g_width=w; g_height=h;
    if (g_window) ANativeWindow_setBuffersGeometry(g_window, w, h, 0);
    if (g_eglReady && pthread_equal(g_eglThread, pthread_self())) glViewport(0,0,w,h);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintEGL_nativePause(JNIEnv* env, jclass c) {
    if (g_display!=EGL_NO_DISPLAY && g_eglReady && pthread_equal(g_eglThread, pthread_self())) eglMakeCurrent(g_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintEGL_nativeResume(JNIEnv* env, jclass c) {
    if (g_display!=EGL_NO_DISPLAY && g_surface!=EGL_NO_SURFACE && g_context!=EGL_NO_CONTEXT && pthread_equal(g_eglThread, pthread_self())) eglMakeCurrent(g_display, g_surface, g_surface, g_context);
}
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintEGL_nativeGetWidth(JNIEnv* env, jclass c) { return g_width; }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintEGL_nativeGetHeight(JNIEnv* env, jclass c) { return g_height; }
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintEGL_nativeIsReady(JNIEnv* env, jclass c) { return g_eglReady ? JNI_TRUE : JNI_FALSE; }
}
