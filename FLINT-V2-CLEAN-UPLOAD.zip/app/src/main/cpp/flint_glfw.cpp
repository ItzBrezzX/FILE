// FLINT GLFW - Dual-VM bridge (FIX REAL, bukan docs-only)
// MASALAH: sebelumnya g_vm hanya ART VM (dari JNI_OnLoad saat APK load lib).
// Minecraft + LWJGL jalan di JVM BARU (JNI_CreateJavaVM di flint_jvm.cpp).
// CallbackBridge ada 2 copy: satu di ART, satu di JVM baru (via flint-bridge.jar).
// Kalau event di-push ke ART, LWJGL di JVM baru TIDAK PERNAH lihat event -> input mati.
// FIX: simpan 2 JavaVM*: g_artVm (dari JNI_OnLoad) + g_gameVm (dari flint_jvm.cpp setelah CreateJavaVM).
// push_event PRIORITAS ke g_gameVm, fallback ke g_artVm kalau game belum jalan.
#include <jni.h>
#include <android/log.h>
#include <time.h>
#include <mutex>
#define LOG_TAG "FLINT-GLFW"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
static JavaVM* g_artVm = nullptr;
static JavaVM* g_gameVm = nullptr;
static double g_startTime = 0;
static int g_width = 1280, g_height = 720;
static bool g_shouldClose = false;
static double flint_get_time() { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); double now = ts.tv_sec + ts.tv_nsec/1e9; if (g_startTime==0) g_startTime=now; return now-g_startTime; }

// Dipanggil flint_jvm.cpp setelah JNI_CreateJavaVM berhasil. JANGAN panggil dari ART.
extern "C" void flint_glfw_set_game_vm(JavaVM* vm) {
    g_gameVm = vm;
    LOGI("flint_glfw_set_game_vm: game VM=%p (ART VM=%p) - event sekarang ke GAME JVM", (void*)vm, (void*)g_artVm);
}
extern "C" JavaVM* flint_glfw_get_game_vm() { return g_gameVm; }

static bool push_to_vm(JavaVM* vm, int type, int key, int button, int action, float x, float y, float dx, float dy) {
    if (!vm) return false;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return false;
        attached = true;
    }
    // FindClass di VM ini. Di game VM, CallbackBridge dari flint-bridge.jar.
    // Di ART VM, CallbackBridge dari APK. Keduanya class yang sama, tapi instance queue beda.
    jclass cls = env->FindClass("com/flintclient/bridge/CallbackBridge");
    if (!cls) { if (attached) vm->DetachCurrentThread(); return false; }
    bool ok = true;
    if (type == 1) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushMouseButton", "(FFII)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, x, y, button, action); else ok = false;
    } else if (type == 2) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushKey", "(II)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, key, action); else ok = false;
    } else if (type == 3) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushScroll", "(FF)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, dx, dy); else ok = false;
    } else if (type == 4) {
        if (action == 2) {
            jmethodID mid = env->GetStaticMethodID(cls, "pushMousePos", "(FF)V");
            if (mid) env->CallStaticVoidMethod(cls, mid, x, y); else ok = false;
        } else {
            jmethodID mid = env->GetStaticMethodID(cls, "pushMouseButton", "(FFII)V");
            if (mid) env->CallStaticVoidMethod(cls, mid, x, y, button, action); else ok = false;
        }
    } else if (type == 5) {
        jmethodID mid = env->GetStaticMethodID(cls, "pushChar", "(I)V");
        if (mid) env->CallStaticVoidMethod(cls, mid, key); else ok = false;
    }
    if (env->ExceptionCheck()) { env->ExceptionDescribe(); env->ExceptionClear(); ok = false; }
    if (attached) vm->DetachCurrentThread();
    return ok;
}

extern "C" void flint_glfw_push_event(int type, int key, int button, int action, float x, float y, float dx, float dy) {
    // PRIORITAS: game VM. Kalau game belum jalan (g_gameVm null), fallback ke ART supaya tidak hilang total,
    // tapi log warning karena event itu tidak akan sampai ke Minecraft.
    if (g_gameVm) {
        if (push_to_vm(g_gameVm, type, key, button, action, x, y, dx, dy)) return;
        LOGE("push ke GAME VM gagal, fallback ke ART (event mungkin tidak sampai ke Minecraft)");
    }
    if (g_artVm) {
        push_to_vm(g_artVm, type, key, button, action, x, y, dx, dy);
    } else {
        LOGE("flint_glfw_push_event: g_artVm + g_gameVm null, event type=%d hilang", type);
    }
}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    g_artVm = vm;
    LOGI("flint_glfw JNI_OnLoad OK, ART VM=%p", (void*)vm);
    return JNI_VERSION_1_6;
}
extern "C" {
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintGLFW_nativeInit(JNIEnv* env, jclass c) {
    if (!g_artVm) env->GetJavaVM(&g_artVm);
    LOGI("GLFW init: window %dx%d, ART VM=%p game VM=%p", g_width, g_height, (void*)g_artVm, (void*)g_gameVm);
    g_startTime=0; flint_get_time(); g_shouldClose=false;
    return JNI_TRUE;
}
JNIEXPORT jdouble JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetTime(JNIEnv* env, jclass c) { return flint_get_time(); }
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativePollEvents(JNIEnv* env, jclass c) {
    // JANGAN buang event. LWJGL Android poll via CallbackBridge.pollEvents() dari JVM thread.
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativeTerminate(JNIEnv* env, jclass c) { LOGI("GLFW terminate"); g_shouldClose=false; g_gameVm=nullptr; }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetPendingEventCount(JNIEnv* env, jclass c) {
    // Tanya ke GAME VM dulu, karena itu queue yang dibaca Minecraft.
    JavaVM* vm = g_gameVm ? g_gameVm : g_artVm;
    if (!vm) return 0;
    JNIEnv* e = nullptr; bool att=false;
    if (vm->GetEnv((void**)&e, JNI_VERSION_1_6)!=JNI_OK) { if (vm->AttachCurrentThread(&e,nullptr)!=JNI_OK) return 0; att=true; }
    jclass cls = e->FindClass("com/flintclient/bridge/CallbackBridge");
    if (!cls) { if (att) vm->DetachCurrentThread(); return 0; }
    jmethodID mid = e->GetStaticMethodID(cls, "getPendingCount", "()I");
    jint v = mid ? e->CallStaticIntMethod(cls, mid) : 0;
    if (att) vm->DetachCurrentThread();
    return v;
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativeSetWindowSize(JNIEnv* env, jclass c, jint w, jint h) {
    g_width=w; g_height=h;
    // Set ke BOTH VMs supaya ART overlay + game sama ukurannya
    if (g_gameVm) push_to_vm(g_gameVm, -1, 0, 0, 0, 0, 0, 0, 0); // no-op, window size via method below
    // Langsung panggil setWindowSize di kedua VM
    JavaVM* vms[2] = { g_gameVm, g_artVm };
    for (int i=0;i<2;i++) {
        JavaVM* vm = vms[i]; if (!vm) continue;
        JNIEnv* e=nullptr; bool att=false;
        if (vm->GetEnv((void**)&e, JNI_VERSION_1_6)!=JNI_OK) { if (vm->AttachCurrentThread(&e,nullptr)!=JNI_OK) continue; att=true; }
        jclass cls = e->FindClass("com/flintclient/bridge/CallbackBridge");
        if (cls) { jmethodID mid = e->GetStaticMethodID(cls, "setWindowSize", "(II)V"); if (mid) e->CallStaticVoidMethod(cls, mid, w, h); }
        if (att) vm->DetachCurrentThread();
    }
}
JNIEXPORT jboolean JNICALL Java_com_flintclient_native_FlintGLFW_nativeShouldClose(JNIEnv* env, jclass c) { return g_shouldClose ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintGLFW_nativeSetShouldClose(JNIEnv* env, jclass c, jboolean v) { g_shouldClose = (v==JNI_TRUE); }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetWidth(JNIEnv* env, jclass c) { return g_width; }
JNIEXPORT jint JNICALL Java_com_flintclient_native_FlintGLFW_nativeGetHeight(JNIEnv* env, jclass c) { return g_height; }
}
