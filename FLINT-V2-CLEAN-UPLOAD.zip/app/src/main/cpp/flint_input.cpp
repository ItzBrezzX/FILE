// FLINT Input - Real bridge
// Java -> native GLFW event queue. Button -1 = mouse move (camera drag), bukan click.
#include <jni.h>
#include <android/log.h>
#define LOG_TAG "FLINT-INPUT"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
extern void flint_glfw_push_event(int type, int key, int button, int action, float x, float y, float dx, float dy);
extern "C" {
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendMouse(JNIEnv* env, jclass c, jfloat x, jfloat y, jint button, jint action) {
    if (button == -1) {
        // Camera drag: mouse move, action 2 = move
        flint_glfw_push_event(4, 0, 0, 2, x, y, 0, 0);
    } else {
        flint_glfw_push_event(1, 0, button, action, x, y, 0, 0);
    }
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendKey(JNIEnv* env, jclass c, jint keyCode, jint action) {
    // keyCode di sini SUDAH GLFW keycode (dipetakan di Kotlin via GlfwKeyMapper). Jangan kirim Android keycode mentah.
    flint_glfw_push_event(2, keyCode, 0, action, 0, 0, 0, 0);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendScroll(JNIEnv* env, jclass c, jfloat dx, jfloat dy) {
    flint_glfw_push_event(3, 0, 0, 0, 0, 0, dx, dy);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendTouch(JNIEnv* env, jclass c, jfloat x, jfloat y, jint action) {
    flint_glfw_push_event(4, 0, 0, action, x, y, 0, 0);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendChar(JNIEnv* env, jclass c, jint charCode) {
    flint_glfw_push_event(5, charCode, 0, 0, 0, 0, 0, 0);
}
JNIEXPORT void JNICALL Java_com_flintclient_native_FlintInput_nativeSendMousePos(JNIEnv* env, jclass c, jfloat x, jfloat y) {
    flint_glfw_push_event(4, 0, 0, 2, x, y, 0, 0);
}
}
