package com.flintclient.core.java

import com.flintclient.core.version.VersionCompatibility

object JavaVersionMapper {
    // Mapping lengkap Minecraft -> Java yang harus dipakai
    fun getRequiredJava(versionId: String): Int = VersionCompatibility.getJavaForVersion(versionId)
    fun getJavaDownloadUrl(javaMajor: Int): String {
        return when (javaMajor) {
            8 -> "https://api.adoptium.net/v3/binary/latest/8/ga/linux/aarch64/jdk/hotspot/normal/eclipse"
            17 -> "https://api.adoptium.net/v3/binary/latest/17/ga/linux/aarch64/jdk/hotspot/normal/eclipse"
            21 -> "https://api.adoptium.net/v3/binary/latest/21/ga/linux/aarch64/jdk/hotspot/normal/eclipse"
            else -> "https://api.adoptium.net/v3/binary/latest/21/ga/linux/aarch64/jdk/hotspot/normal/eclipse"
        }
    }
    fun getJvmArgsForJava(javaMajor: Int, ramMb: Int): List<String> {
        val base = mutableListOf("-Xms${ramMb/2}m", "-Xmx${ramMb}m", "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200", "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC")
        if (javaMajor >= 17) {
            base.addAll(listOf("--add-opens", "java.base/java.lang=ALL-UNNAMED", "--add-opens", "java.base/java.io=ALL-UNNAMED"))
        }
        if (javaMajor == 8) {
            base.addAll(listOf("-XX:+UseConcMarkSweepGC", "-XX:+CMSIncrementalMode"))
        }
        return base
    }
    fun validateJavaForVersion(installedJava: Int, minecraftVersion: String): Pair<Boolean, String> {
        val required = getRequiredJava(minecraftVersion)
        if (installedJava == required) return Pair(true, "Java $installedJava cocok untuk $minecraftVersion")
        if (installedJava > required && minecraftVersion.startsWith("1.16")) return Pair(true, "Java $installedJava bisa jalan untuk $minecraftVersion (backward compatible)")
        return Pair(false, "Minecraft $minecraftVersion butuh Java $required, tapi yang terinstall Java $installedJava. FLINT akan auto-download Java $required.")
    }
}
