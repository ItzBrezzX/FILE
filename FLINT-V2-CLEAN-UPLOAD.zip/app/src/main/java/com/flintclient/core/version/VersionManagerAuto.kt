package com.flintclient.core.version
// Extension untuk VersionManager: auto-fetch + cache manifest
// Dipakai oleh AutoUpdateManager & UI biar snapshot baru langsung muncul tanpa restart
// File ini sengaja dipisah biar VersionManager.kt tetap bersih
import com.flintclient.core.storage.StorageManager
import java.io.File
object VersionManifestCache {
    fun save(storage: StorageManager, json: String) {
        val f = File(storage.cacheDir, "version_manifest_cache.json")
        f.parentFile?.mkdirs(); f.writeText(json)
    }
    fun load(storage: StorageManager): String? {
        val f = File(storage.cacheDir, "version_manifest_cache.json")
        return if (f.exists()) f.readText() else null
    }
    fun isStale(storage: StorageManager, maxAgeMs: Long = 6*60*60*1000L): Boolean {
        val f = File(storage.cacheDir, "version_manifest_cache.json")
        if (!f.exists()) return true
        return (System.currentTimeMillis() - f.lastModified()) > maxAgeMs
    }
}
