package com.flintclient.core.instance

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.File

data class GameInstance(
    val id: String,
    var name: String,
    var minecraftVersion: String,
    var modLoader: String = "vanilla",
    var modLoaderVersion: String = "",
    var javaVersion: Int = 21,
    var ramMb: Int = 2048,
    var createdAt: Long = System.currentTimeMillis(),
    var lastPlayedAt: Long = 0L,
    var icon: String = "grass"
)

class GameInstanceManager(private val storage: StorageManager) {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    fun listInstances(): List<GameInstance> {
        val list = mutableListOf<GameInstance>()
        storage.instancesDir.listFiles()?.forEach { dir ->
            val f = File(dir, "instance.json")
            if (f.exists()) {
                try { list.add(gson.fromJson(f.readText(), GameInstance::class.java)) } catch (e: Exception) { }
            }
        }
        return list.sortedByDescending { it.lastPlayedAt }
    }
    fun getInstance(id: String): GameInstance? {
        val f = File(storage.instanceDir(id), "instance.json")
        if (!f.exists()) return null
        return try { gson.fromJson(f.readText(), GameInstance::class.java) } catch (e: Exception) { null }
    }
    fun createInstance(instance: GameInstance): GameInstance {
        val dir = storage.instanceDir(instance.id)
        dir.mkdirs()
        // Create standard Minecraft game directory structure inside instance
        listOf("mods", "resourcepacks", "shaderpacks", "screenshots", "saves", "logs", "crash-reports", "config").forEach { File(dir, it).mkdirs() }
        val f = File(dir, "instance.json")
        f.writeText(gson.toJson(instance))
        FlintLogger.i("Instance", "Created ${instance.id} MC ${instance.minecraftVersion} loader ${instance.modLoader}")
        return instance
    }
    fun updateInstance(instance: GameInstance) {
        val f = File(storage.instanceDir(instance.id), "instance.json")
        f.writeText(gson.toJson(instance))
    }
    fun deleteInstance(id: String): Boolean = storage.instanceDir(id).deleteRecursively()
    fun getOrCreateDefault(): GameInstance {
        return getInstance("default") ?: createInstance(GameInstance(id = "default", name = "Default", minecraftVersion = "1.21.1", modLoader = "vanilla"))
    }
    fun markPlayed(id: String) {
        val inst = getInstance(id) ?: return
        inst.lastPlayedAt = System.currentTimeMillis()
        updateInstance(inst)
    }
}
