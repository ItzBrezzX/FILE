package com.flintclient.core.launch

import android.view.Surface
import com.flintclient.core.logging.FlintLogger

// JNIVMLauncher V2 - Pojav pattern
// - nativeLoadJvmLib(Pojav libjvm.so) HARUS dulu
// - nativeSetSurface(surface) HARUS dipanggil SEBELUM createJVM, supaya EGL bisa dibuat di JVM thread
// - nativeSetEnv(key,value) per var
// - createJVM() blocking di JVM pthread (stack 8MB), JNIEnv HANYA dari JVM baru, TIDAK dicampur ART
object JNIVMLauncher {
    init {
        try { System.loadLibrary("flint_jvm") } catch (e: Throwable) {
            FlintLogger.e("JVM", "loadLibrary flint_jvm FAILED: " + (e.message ?: ""))
            throw e
        }
    }
    external fun nativeLoadJvmLib(jvmLibPath: String): Boolean
    external fun nativeSetEnv(key: String, value: String)
    external fun nativeSetSurface(surface: Surface)
    external fun createJVM(jvmArgs: Array<String>, classpath: String, mainClass: String, gameArgs: Array<String>): Int
    external fun isJVMRunning(): Boolean
    external fun destroyJVM(): Int
    @Deprecated("Use nativeSetEnv(key,value)")
    fun setEnvVars(env: Map<String, String>) { env.forEach { (k, v) -> nativeSetEnv(k, v) } }

    fun launch(
        libJvmSo: String,
        jvmArgs: List<String>,
        classpath: String,
        mainClass: String,
        gameArgs: List<String>,
        env: Map<String, String>,
        surface: Surface? = null
    ): Int {
        FlintLogger.i("JVM", "Loading libjvm.so (Pojav Bionic): " + libJvmSo)
        if (libJvmSo.contains("adoptium", ignoreCase = true) || libJvmSo.contains("temurin", ignoreCase = true)) {
            FlintLogger.e("JVM", "REJECTED Adoptium - glibc tidak kompatibel Bionic. Pakai Pojav JRE.")
            return -100
        }
        if (!nativeLoadJvmLib(libJvmSo)) {
            FlintLogger.e("JVM", "nativeLoadJvmLib FAILED - Pojav JRE tidak ada / ABI salah")
            return -100
        }
        if (surface != null) {
            try { nativeSetSurface(surface) } catch (e: Throwable) { FlintLogger.e("JVM", "nativeSetSurface gagal: " + (e.message ?: "")) }
        } else {
            FlintLogger.e("JVM", "Surface NULL - EGL tidak bisa dibuat di JVM thread. GameActivity harus pass Surface.")
        }
        env.forEach { (k, v) -> nativeSetEnv(k, v) }
        FlintLogger.i("JVM", "Launching main=" + mainClass + ", jvmArgs=" + jvmArgs.size + " gameArgs=" + gameArgs.size)
        return try {
            createJVM(jvmArgs.toTypedArray(), classpath, mainClass, gameArgs.toTypedArray())
        } catch (e: Throwable) {
            FlintLogger.e("JVM", "createJVM threw: " + (e.message ?: ""))
            -1
        }
    }
}
