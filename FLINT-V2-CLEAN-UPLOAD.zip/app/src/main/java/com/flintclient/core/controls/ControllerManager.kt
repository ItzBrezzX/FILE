package com.flintclient.core.controls

import android.content.Context
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import com.flintclient.core.logging.FlintLogger

// CONTROLLER SUPPORT - Part 6: PS4/PS5 DualShock/DualSense, Xbox One/Series, Bluetooth keyboard/mouse
// Minecraft Java di Android butuh mapping controller -> keyboard/mouse virtual.

enum class ControllerType { PS4_DUALSHOCK, PS5_DUALSENSE, XBOX_ONE, XBOX_SERIES, GENERIC, KEYBOARD_MOUSE, NONE }

data class ControllerInfo(val name: String, val type: ControllerType, val deviceId: Int, val isConnected: Boolean)

object ControllerManager {
    fun getConnectedControllers(context: Context): List<ControllerInfo> {
        val ids = InputDevice.getDeviceIds()
        val result = mutableListOf<ControllerInfo>()
        for (id in ids) {
            val dev = InputDevice.getDevice(id) ?: continue
            val sources = dev.sources
            if ((sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                val name = dev.name.lowercase()
                val type = when {
                    name.contains("dualsense") || name.contains("ps5") -> ControllerType.PS5_DUALSENSE
                    name.contains("dualshock") || name.contains("ps4") || name.contains("sony") -> ControllerType.PS4_DUALSHOCK
                    name.contains("xbox") -> ControllerType.XBOX_SERIES
                    else -> ControllerType.GENERIC
                }
                result.add(ControllerInfo(dev.name, type, id, true))
            }
        }
        FlintLogger.i("Controller", "Found ${result.size} controllers: ${result.map { it.name }}")
        return result
    }
    // Mapping default: Left Stick = WASD, Right Stick = Mouse, A/X = Left Click, B/O = Right Click, RT = Attack, LT = Use, Start = Esc
    fun getDefaultMapping(type: ControllerType): Map<String, String> = mapOf(
        "LEFT_STICK_X" to "WASD_X", "LEFT_STICK_Y" to "WASD_Y",
        "RIGHT_STICK_X" to "MOUSE_X", "RIGHT_STICK_Y" to "MOUSE_Y",
        "BUTTON_A" to "MOUSE_LEFT", "BUTTON_B" to "MOUSE_RIGHT",
        "BUTTON_X" to "KEY_E", "BUTTON_Y" to "KEY_Q",
        "BUTTON_R1" to "KEY_1", "BUTTON_L1" to "KEY_2",
        "BUTTON_R2" to "MOUSE_LEFT_HOLD", "BUTTON_L2" to "MOUSE_RIGHT_HOLD",
        "BUTTON_START" to "KEY_ESC", "BUTTON_SELECT" to "KEY_F3"
    )
    fun handleMotionEvent(event: MotionEvent): Pair<Float, Float> {
        // Left stick -> WASD
        val x = event.getAxisValue(MotionEvent.AXIS_X)
        val y = event.getAxisValue(MotionEvent.AXIS_Y)
        return Pair(x, y)
    }
    fun handleKeyEvent(event: KeyEvent): String? {
        return when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> "MOUSE_LEFT"
            KeyEvent.KEYCODE_BUTTON_B -> "MOUSE_RIGHT"
            KeyEvent.KEYCODE_BUTTON_START -> "KEY_ESC"
            else -> null
        }
    }
}

object KeyboardMouseManager {
    // Bluetooth keyboard/mouse: Android sudah handle otomatis sebagai InputDevice SOURCE_KEYBOARD / SOURCE_MOUSE
    // FLINT cuma perlu forward ke GLFW via flint_input.cpp
    fun isKeyboardConnected(context: Context): Boolean {
        return InputDevice.getDeviceIds().any { id ->
            val dev = InputDevice.getDevice(id) ?: return@any false
            (dev.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
        }
    }
    fun isMouseConnected(context: Context): Boolean {
        return InputDevice.getDeviceIds().any { id ->
            val dev = InputDevice.getDevice(id) ?: return@any false
            (dev.sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
        }
    }
    fun getStatus(context: Context): String {
        val kb = isKeyboardConnected(context)
        val mouse = isMouseConnected(context)
        val ctrl = ControllerManager.getConnectedControllers(context)
        return "Keyboard: ${if(kb) "Connected" else "Touch"}, Mouse: ${if(mouse) "Connected" else "Touch"}, Controller: ${ctrl.size} connected (${ctrl.joinToString { it.name }})"
    }
}
