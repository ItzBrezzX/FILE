package com.flintclient.core.version

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

class VersionManager(private val storage: StorageManager) {
    companion object {
        const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
        const val FABRIC_META = "https://meta.fabricmc.net/v2/versions/loader"
        const val FORGE_META = "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"
    }
    private val gson = Gson()
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private val downloadEngine = DownloadEngine()

    suspend fun fetchManifest(): VersionManifest = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(MANIFEST_URL).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("Manifest HTTP ${resp.code}")
            gson.fromJson(resp.body!!.string(), VersionManifest::class.java)
        }
    }
    suspend fun fetchVersionJson(entry: VersionEntry): VersionJson = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(entry.url).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("Version JSON HTTP ${resp.code}")
            gson.fromJson(resp.body!!.string(), VersionJson::class.java)
        }
    }
    fun saveVersionJson(versionId: String, json: VersionJson) {
        val file = File(storage.versionDir(versionId), "$versionId.json")
        file.writeText(gson.toJson(json))
    }
    fun loadVersionJson(versionId: String): VersionJson? {
        val file = File(storage.versionDir(versionId), "$versionId.json")
        if (!file.exists()) return null
        return try { gson.fromJson(file.readText(), VersionJson::class.java) } catch (e: Exception) { null }
    }
    fun resolveInheritance(base: VersionJson, parent: VersionJson): VersionJson {
        // Merge parent libraries + arguments when inheritsFrom is set (Forge/Fabric pattern)
        val mergedLibraries = (parent.libraries + base.libraries).distinctBy { it.name }
        val mergedGameArgs = mutableListOf<Any>()
        parent.arguments?.game?.let { mergedGameArgs.addAll(it) }
        base.arguments?.game?.let { mergedGameArgs.addAll(it) }
        val mergedJvmArgs = mutableListOf<Any>()
        parent.arguments?.jvm?.let { mergedJvmArgs.addAll(it) }
        base.arguments?.jvm?.let { mergedJvmArgs.addAll(it) }
        return base.copy(libraries = mergedLibraries, arguments = Arguments(mergedGameArgs, mergedJvmArgs), mainClass = base.mainClass.ifEmpty { parent.mainClass }, assetIndex = base.assetIndex, minecraftArguments = base.minecraftArguments ?: parent.minecraftArguments)
    }
    suspend fun installVersion(entry: VersionEntry, onProgress: (String, Int) -> Unit = {_,_ -> }): Boolean {
        FlintLogger.i("VersionManager", "Installing ${entry.id}")
        val versionJson = fetchVersionJson(entry)
        saveVersionJson(entry.id, versionJson)
        // Download client jar
        val jarFile = File(storage.versionDir(entry.id), "${entry.id}.jar")
        val clientDl = DownloadTask(versionJson.downloads.client.url, jarFile, versionJson.downloads.client.sha1, versionJson.downloads.client.size)
        if (!downloadEngine.download(clientDl) { p -> onProgress("client.jar", p.percent) }) return false
        // Libraries + natives handled by LibraryResolver / AssetManager in Launch pipeline
        onProgress("version.json", 100)
        FlintLogger.i("VersionManager", "Version ${entry.id} installed")
        return true
    }
    fun listInstalledVersions(): List<String> {
        return storage.versionsDir.listFiles()?.filter { it.isDirectory && File(it, "${it.name}.json").exists() }?.map { it.name }?.sorted() ?: emptyList()
    }
    fun isInstalled(versionId: String): Boolean = File(storage.versionDir(versionId), "$versionId.jar").exists()
    fun deleteVersion(versionId: String): Boolean = storage.versionDir(versionId).deleteRecursively()
}
