package com.flintclient.core.config

import android.content.Context
import com.flintclient.core.storage.StorageManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.File

data class FlintConfig(
    var selectedInstanceId: String = "default",
    var selectedVersionId: String = "1.21.1",
    var selectedJavaId: String = "java-21",
    var selectedAccountId: String = "",
    var ramMb: Int = 2048,
    var maxRamMb: Int = 4096,
    var jvmArgs: String = "-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:+AlwaysPreTouch",
    var gameArgs: String = "",
    var width: Int = 1280,
    var height: Int = 720,
    var renderer: String = "gl4es",
    var renderDistance: Int = 8,
    var fov: Int = 70,
    var guiScale: Int = 2,
    var sensitivity: Float = 1.0f,
    var fullscreen: Boolean = false,
    var showFps: Boolean = true,
    var showCps: Boolean = true,
    var showCoords: Boolean = true,
    var showKeystrokes: Boolean = true,
    var showArmor: Boolean = true,
    var showPotion: Boolean = true,
    var showPing: Boolean = true,
    var showMemory: Boolean = true,
    var zoomEnabled: Boolean = true,
    var fullbright: Boolean = false,
    var language: String = "id_ID",
    var audioEnabled: Boolean = true,
    var audioVolume: Float = 1.0f,
    var touchControls: Boolean = true,
    var enableMods: Boolean = true,
    var enableShaders: Boolean = false,
    var downloadThreads: Int = 4,
    var autoUpdate: Boolean = true,
    var closeLauncherOnPlay: Boolean = false,
    var customControlsJson: String = ""
)

class ConfigManager(context: Context, private val storage: StorageManager) {
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val file = File(storage.configsDir, "flint-config.json")
    var config: FlintConfig = FlintConfig()
        private set
    init { load() }
    fun load() {
        if (file.exists()) {
            try { config = gson.fromJson(file.readText(), FlintConfig::class.java) ?: FlintConfig() } catch (e: Exception) { config = FlintConfig() }
        } else { save() }
    }
    fun save() { file.writeText(gson.toJson(config)) }
    fun update(block: (FlintConfig) -> Unit) { block(config); save() }
    fun reset() { config = FlintConfig(); save() }
}
