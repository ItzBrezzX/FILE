package com.flintclient.core.performance
import android.app.ActivityManager
import android.content.Context
import com.flintclient.core.logging.FlintLogger
import java.io.File
object PerformanceOptimizer {
    private val imageCache = mutableMapOf<String, ByteArray>()
    fun getCachedImage(url: String): ByteArray? = imageCache[url]
    fun putCachedImage(url: String, bytes: ByteArray) {
        if (imageCache.size > 100) imageCache.clear()
        imageCache[url] = bytes
    }
    fun getSafeRamMb(context: Context, requestedMb: Int): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo(); am.getMemoryInfo(memInfo)
        val totalMb = (memInfo.totalMem / 1024 / 1024).toInt()
        val safeMax = when { totalMb <= 3072 -> 1024; totalMb <= 4096 -> 1536; totalMb <= 6144 -> 2048; totalMb <= 8192 -> 3072; else -> 4096 }
        return minOf(requestedMb, safeMax)
    }
    fun <T> paginate(list: List<T>, page: Int, pageSize: Int = 20): List<T> {
        val from = page * pageSize; if (from >= list.size) return emptyList()
        return list.subList(from, minOf(from + pageSize, list.size))
    }
    fun hasEnoughStorage(dir: File, neededBytes: Long): Boolean = dir.freeSpace > neededBytes + 200L*1024*1024
    fun getOptimizedJvmArgs(ramMb: Int, isLowEnd: Boolean): List<String> {
        return if (isLowEnd) listOf("-Xms512m","-Xmx${ramMb}m","-XX:+UseG1GC","-XX:MaxGCPauseMillis=100","-XX:+UseStringDeduplication","-Dfml.earlyWindowSkip=true")
        else listOf("-Xms${ramMb/2}m","-Xmx${ramMb}m","-XX:+UseG1GC","-XX:+ParallelRefProcEnabled","-XX:MaxGCPauseMillis=200","-XX:+UnlockExperimentalVMOptions","-XX:+DisableExplicitGC","-XX:+AlwaysPreTouch")
    }
    fun isLowEndDevice(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo(); am.getMemoryInfo(memInfo)
        return (memInfo.totalMem/1024/1024) <= 4096 || am.isLowRamDevice
    }
}
