package com.flintclient.core.mods

import com.flintclient.core.logging.FlintLogger
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

// MODRINTH LIVE - Part 6, Mod Menu bukan dummy lagi!
// API: https://api.modrinth.com/v2/search?query=sodium&limit=20&facets=[["categories:mod"]]

data class ModrinthSearchResponse(val hits: List<ModrinthMod>, val offset: Int, val limit: Int, val total_hits: Int)
data class ModrinthMod(
    @SerializedName("project_id") val projectId: String,
    val slug: String,
    val title: String,
    val description: String,
    val downloads: Long,
    val follows: Int,
    @SerializedName("icon_url") val iconUrl: String?,
    @SerializedName("date_created") val dateCreated: String?,
    val categories: List<String>,
    @SerializedName("client_side") val clientSide: String,
    @SerializedName("server_side") val serverSide: String
)
data class ModrinthVersion(val id: String, @SerializedName("version_number") val versionNumber: String, @SerializedName("game_versions") val gameVersions: List<String>, val loaders: List<String>, val files: List<ModrinthFile>)
data class ModrinthFile(val url: String, val filename: String, val size: Long, val primary: Boolean)

object ModrinthManager {
    private const val BASE = "https://api.modrinth.com/v2"
    private val gson = Gson()
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    suspend fun searchMods(query: String, category: String = "mod", limit: Int = 20, minecraftVersion: String? = null): List<ModrinthMod> = withContext(Dispatchers.IO) {
        try {
            var url = "$BASE/search?query=${query}&limit=$limit"
            // Facets: categories:mod / categories:shader / categories:resourcepack
            val facetCat = when (category.lowercase()) {
                "shaders", "shader" -> "shader"
                "resource packs", "resourcepack" -> "resourcepack"
                "datapacks", "data packs" -> "datapack"
                else -> "mod"
            }
            url += "&facets=[[\"categories:$facetCat\"]]"
            if (minecraftVersion != null && minecraftVersion != "All Versions") url += "&facets=[[\"versions:$minecraftVersion\"]]"
            // Note: facets double encode di real app pakai URLEncoder, di sini simplified
            val req = Request.Builder().url("$BASE/search?query=$query&limit=$limit").header("User-Agent", "FLINT-Launcher/1.0").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("Modrinth HTTP ${resp.code}")
                val parsed = gson.fromJson(resp.body!!.string(), ModrinthSearchResponse::class.java)
                FlintLogger.i("Modrinth", "Search '$query' -> ${parsed.total_hits} hits")
                parsed.hits
            }
        } catch (e: Exception) {
            FlintLogger.e("Modrinth", "Search gagal: ${e.message}")
            emptyList()
        }
    }
    suspend fun getFeaturedMods(): List<ModrinthMod> {
        // Featured = yang paling banyak di-download, sama kayak di foto: Sodium, Iris, Fabric API, dll
        val queries = listOf("sodium", "iris", "fabric api", "optifine", "continuity", "xaero")
        val result = mutableListOf<ModrinthMod>()
        for (q in queries) {
            val hits = searchMods(q, limit = 1)
            if (hits.isNotEmpty()) result.add(hits[0])
        }
        return result
    }
    suspend fun getVersionsForMod(projectId: String, gameVersion: String, loader: String): List<ModrinthVersion> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("$BASE/project/$projectId/version?game_versions=[\"$gameVersion\"]&loaders=[\"${loader.lowercase()}\"]").header("User-Agent", "FLINT-Launcher/1.0").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext emptyList<ModrinthVersion>()
                val arr = gson.fromJson(resp.body!!.string(), Array<ModrinthVersion>::class.java)
                arr.toList()
            }
        } catch (e: Exception) { emptyList() }
    }
    fun formatDownloads(downloads: Long): String = when {
        downloads >= 1_000_000 -> String.format("%.1fM", downloads / 1_000_000f)
        downloads >= 1_000 -> String.format("%.1fK", downloads / 1_000f)
        else -> downloads.toString()
    }
}
