package com.flintclient.core.controls
import android.view.KeyEvent
// Android KeyEvent.KEYCODE_* != GLFW_KEY_*
// Contoh fatal sebelumnya: W Android=51, GLFW W=87. Kalau kirim 51 mentah, Minecraft baca sebagai GLFW 51 (angka 3?) -> WASD mati.
// Pojav pakai mapping yang sama (lihat PojavLauncherTeam/android-openjdk-build / CallbackBridge).
object GlfwKeyMapper {
    fun androidToGlfw(androidKey: Int): Int = when (androidKey) {
        KeyEvent.KEYCODE_A -> 65; KeyEvent.KEYCODE_B -> 66; KeyEvent.KEYCODE_C -> 67
        KeyEvent.KEYCODE_D -> 68; KeyEvent.KEYCODE_E -> 69; KeyEvent.KEYCODE_F -> 70
        KeyEvent.KEYCODE_G -> 71; KeyEvent.KEYCODE_H -> 72; KeyEvent.KEYCODE_I -> 73
        KeyEvent.KEYCODE_J -> 74; KeyEvent.KEYCODE_K -> 75; KeyEvent.KEYCODE_L -> 76
        KeyEvent.KEYCODE_M -> 77; KeyEvent.KEYCODE_N -> 78; KeyEvent.KEYCODE_O -> 79
        KeyEvent.KEYCODE_P -> 80; KeyEvent.KEYCODE_Q -> 81; KeyEvent.KEYCODE_R -> 82
        KeyEvent.KEYCODE_S -> 83; KeyEvent.KEYCODE_T -> 84; KeyEvent.KEYCODE_U -> 85
        KeyEvent.KEYCODE_V -> 86; KeyEvent.KEYCODE_W -> 87; KeyEvent.KEYCODE_X -> 88
        KeyEvent.KEYCODE_Y -> 89; KeyEvent.KEYCODE_Z -> 90
        KeyEvent.KEYCODE_0 -> 48; KeyEvent.KEYCODE_1 -> 49; KeyEvent.KEYCODE_2 -> 50
        KeyEvent.KEYCODE_3 -> 51; KeyEvent.KEYCODE_4 -> 52; KeyEvent.KEYCODE_5 -> 53
        KeyEvent.KEYCODE_6 -> 54; KeyEvent.KEYCODE_7 -> 55; KeyEvent.KEYCODE_8 -> 56
        KeyEvent.KEYCODE_9 -> 57
        KeyEvent.KEYCODE_SPACE -> 32
        KeyEvent.KEYCODE_ENTER -> 257; KeyEvent.KEYCODE_DEL -> 259; KeyEvent.KEYCODE_TAB -> 258
        KeyEvent.KEYCODE_ESCAPE -> 256; KeyEvent.KEYCODE_BACK -> 256
        KeyEvent.KEYCODE_SHIFT_LEFT -> 340; KeyEvent.KEYCODE_SHIFT_RIGHT -> 344
        KeyEvent.KEYCODE_CTRL_LEFT -> 341; KeyEvent.KEYCODE_CTRL_RIGHT -> 345
        KeyEvent.KEYCODE_ALT_LEFT -> 342; KeyEvent.KEYCODE_ALT_RIGHT -> 346
        KeyEvent.KEYCODE_DPAD_UP -> 265; KeyEvent.KEYCODE_DPAD_DOWN -> 264
        KeyEvent.KEYCODE_DPAD_LEFT -> 263; KeyEvent.KEYCODE_DPAD_RIGHT -> 262
        KeyEvent.KEYCODE_F1 -> 290; KeyEvent.KEYCODE_F2 -> 291; KeyEvent.KEYCODE_F3 -> 292
        KeyEvent.KEYCODE_F4 -> 293; KeyEvent.KEYCODE_F5 -> 294; KeyEvent.KEYCODE_F6 -> 295
        KeyEvent.KEYCODE_F7 -> 296; KeyEvent.KEYCODE_F8 -> 297; KeyEvent.KEYCODE_F9 -> 298
        KeyEvent.KEYCODE_F10 -> 299; KeyEvent.KEYCODE_F11 -> 300; KeyEvent.KEYCODE_F12 -> 301
        KeyEvent.KEYCODE_COMMA -> 44; KeyEvent.KEYCODE_PERIOD -> 46
        KeyEvent.KEYCODE_MINUS -> 45; KeyEvent.KEYCODE_EQUALS -> 61
        KeyEvent.KEYCODE_SLASH -> 47; KeyEvent.KEYCODE_BACKSLASH -> 92
        KeyEvent.KEYCODE_SEMICOLON -> 59; KeyEvent.KEYCODE_APOSTROPHE -> 39
        KeyEvent.KEYCODE_GRAVE -> 96; KeyEvent.KEYCODE_LEFT_BRACKET -> 91; KeyEvent.KEYCODE_RIGHT_BRACKET -> 93
        else -> -1
    }
    // Helper untuk TouchControlsOverlay yang sebelumnya pakai angka mentah 51/47/29/32/57/42
    // Panggil ini, jangan hardcode Android keycode di overlay lagi.
    fun wasdGlfw(dir: String): Int = when (dir) {
        "forward" -> 87; "back" -> 83; "left" -> 65; "right" -> 68
        "jump" -> 32; "sneak" -> 340; "inventory" -> 69
        else -> -1
    }
}
