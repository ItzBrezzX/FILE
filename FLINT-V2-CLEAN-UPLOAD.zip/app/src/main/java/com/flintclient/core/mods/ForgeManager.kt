package com.flintclient.core.mods

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

class ForgeManager(private val storage: StorageManager) {
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    suspend fun getRecommendedForge(mcVersion: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val json = JsonParser.parseString(resp.body!!.string()).asJsonObject
                val promos = json.getAsJsonObject("promos")
                // Try recommended, fallback latest
                val key = "$mcVersion-recommended"
                if (promos.has(key)) return@withContext promos.get(key).asString
                val latestKey = "$mcVersion-latest"
                if (promos.has(latestKey)) return@withContext promos.get(latestKey).asString
                null
            }
        } catch (e: Exception) { FlintLogger.e("Forge", "promos failed", e); null }
    }
    suspend fun installForge(mcVersion: String, forgeVersion: String? = null, onProgress: (Int) -> Unit = {}): Boolean {
        val fv = forgeVersion ?: getRecommendedForge(mcVersion) ?: return false
        val fullVersion = "$mcVersion-$fv"
        val installerUrl = "https://maven.minecraftforge.net/net/minecraftforge/forge/$fullVersion/forge-$fullVersion-installer.jar"
        val dest = File(storage.downloadsDir, "forge-$fullVersion-installer.jar")
        FlintLogger.i("Forge", "Downloading installer $installerUrl")
        val ok = DownloadEngine().download(DownloadTask(installerUrl, dest)) { p -> onProgress(p.percent) }
        if (!ok) return false
        // Forge installer is run with java -jar installer.jar --installClient
        // We extract profile via installer logic: installer creates version json in versions/<mc>-forge-<fv>
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("java", "-jar", dest.absolutePath, "--installClient", storage.rootDir.absolutePath))
            proc.waitFor()
            FlintLogger.i("Forge", "Installer exited ${proc.exitValue()}")
            return proc.exitValue() == 0
        } catch (e: Exception) { FlintLogger.e("Forge", "Install failed", e); return false }
    }
    fun listInstalledForge(): List<String> {
        return storage.versionsDir.listFiles()?.filter { it.name.contains("forge") }?.map { it.name } ?: emptyList()
    }
}
