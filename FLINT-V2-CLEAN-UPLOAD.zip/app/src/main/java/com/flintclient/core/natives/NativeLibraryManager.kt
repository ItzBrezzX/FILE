package com.flintclient.core.natives

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.LibraryResolver
import com.flintclient.core.version.VersionJson
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

// NativeLibraryManager - repaired Phase 6/8
// FIX: previous version tried System.loadLibrary("gl4es") - no such lib in APK, caused UnsatisfiedLinkError on every start.
// Now loads ONLY the 4 libs CMake actually builds: flint_egl, flint_gl, flint_glfw, flint_input.
// gl4es / MobileGLUES are loaded separately via RendererManager / MobileGLUESManager from files/, NOT from APK jniLibs.
class NativeLibraryManager(private val storage: StorageManager) {
    private val downloadEngine = DownloadEngine()
    fun loadFlintNatives() {
        val libs = listOf("flint_egl", "flint_gl", "flint_glfw", "flint_input")
        for (lib in libs) {
            try { System.loadLibrary(lib); FlintLogger.i("Native", "Loaded $lib") }
            catch (e: UnsatisfiedLinkError) { FlintLogger.e("Native", "FAILED to load $lib: ${e.message} - APK built without native lib or wrong ABI. BLOCKED."); throw e }
            catch (e: Exception) { FlintLogger.e("Native", "FAILED $lib: ${e.message}"); throw e }
        }
    }
    suspend fun downloadNatives(version: VersionJson): Boolean {
        for (lib in version.libraries) {
            // SKIP LWJGL desktop natives - diganti LWJGL Android. Kalau di-extract, liblwjgl.so desktop akan menimpa / konflik.
            if (lib.name.startsWith("org.lwjgl")) continue
            val artifact = LibraryResolver.getNativeArtifact(lib) ?: continue
            val dest = File(storage.librariesDir, artifact.path)
            if (!dest.exists()) { if (!downloadEngine.download(DownloadTask(artifact.url, dest, artifact.sha1, artifact.size))) return false }
        }
        return true
    }
    // Overload 1: LaunchManager calls extractNatives(version, nativesDir: File)
    fun extractNatives(version: VersionJson, outDir: File): File {
        outDir.mkdirs()
        for (lib in version.libraries) {
            // SKIP LWJGL desktop natives - diganti LWJGL Android. Kalau di-extract, liblwjgl.so desktop akan menimpa / konflik.
            if (lib.name.startsWith("org.lwjgl")) continue
            val artifact = LibraryResolver.getNativeArtifact(lib) ?: continue
            val jar = File(storage.librariesDir, artifact.path)
            if (!jar.exists()) continue
            try {
                ZipFile(jar).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        if (e.isDirectory) continue
                        if (lib.extract?.exclude?.any { e.name.contains(it) } == true) continue
                        if (e.name.endsWith(".so")) {
                            val out = File(outDir, File(e.name).name)
                            zip.getInputStream(e).use { ins -> FileOutputStream(out).use { o -> ins.copyTo(o) } }
                            out.setExecutable(true)
                        }
                    }
                }
            } catch (ex: Exception) { FlintLogger.e("NativeExtract", "Failed ${lib.name}: ${ex.message}") }
        }
        return outDir
    }
    // Overload 2: old callers used versionId String - keep for compatibility
    fun extractNatives(version: VersionJson, versionId: String): File = extractNatives(version, File(storage.nativesDir, versionId))
    fun getNativeDir(versionId: String): File = File(storage.nativesDir, versionId)
}
