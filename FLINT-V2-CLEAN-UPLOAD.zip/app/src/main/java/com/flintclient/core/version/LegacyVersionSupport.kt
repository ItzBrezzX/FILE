package com.flintclient.core.version

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.File

// Handler khusus untuk Beta / Alpha / Legacy yang cara launch-nya beda total
object LegacyVersionSupport {
    // Minecraft < 1.6 tidak punya assetIndex modern. Assets diambil dari resources/ lama.
    fun getLegacyAssetsDir(storage: StorageManager): File = File(storage.assetsDir, "legacy").apply { mkdirs() }
    // Natives lama: LWJGL 2 butuh liblwjgl.so + libopenal.so versi lama
    fun getLegacyNativesDir(storage: StorageManager, versionId: String): File {
        return File(storage.nativesDir, "legacy-$versionId").apply { mkdirs() }
    }
    // Fix classpath untuk versi lama: mereka butuh lwjgl, lwjgl_util, jinput, dll yang tidak ada di manifest modern
    fun getLegacyExtraLibraries(): List<String> = listOf(
        "org.lwjgl:lwjgl:2.9.4-nightly-20150209",
        "org.lwjgl:lwjgl_util:2.9.4-nightly-20150209",
        "net.java.jinput:jinput:2.0.5",
        "net.java.jutils:jutils:1.0.0"
    )
    // Convert minecraftArguments lama (string) ke list args
    fun parseLegacyMinecraftArguments(minecraftArguments: String?, placeholders: Map<String, String>): List<String> {
        if (minecraftArguments.isNullOrBlank()) return emptyList()
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var inQuote = false
        for (c in minecraftArguments) {
            when {
                c == '"' -> inQuote = !inQuote
                c == ' ' && !inQuote -> { if (current.isNotEmpty()) { result.add(current.toString()); current = StringBuilder() } }
                else -> current.append(c)
            }
        }
        if (current.isNotEmpty()) result.add(current.toString())
        return result.map { arg -> placeholders.entries.fold(arg) { acc, e -> acc.replace(e.key, e.value) } }
    }
    // Untuk Alpha/Beta: game dir harus punya folder resources/ & texturepacks/
    fun prepareLegacyGameDir(gameDir: File) {
        listOf("resources", "texturepacks", "saves", "screenshots").forEach { File(gameDir, it).mkdirs() }
        FlintLogger.i("Legacy", "Prepared legacy game dir ${gameDir.absolutePath}")
    }
    // Validasi apakah versi ini bisa jalan di Android
    fun canRunOnAndroid(versionId: String): Pair<Boolean, String> {
        val era = VersionCompatibility.getEra(versionId)
        return when (era) {
            MinecraftEra.ALPHA -> Pair(true, "Alpha bisa jalan tapi tanpa suara & dengan glitch render. Butuh Legacy Fix.")
            MinecraftEra.BETA -> Pair(true, "Beta 1.7.3 paling stabil di Android. Rekomendasi untuk nostalgia.")
            MinecraftEra.LEGACY -> Pair(true, "1.0-1.5.2 bisa jalan dengan LWJGL 2 patch.")
            else -> Pair(true, "Versi ini didukung penuh.")
        }
    }
    // Snapshot butuh perlakuan khusus: snapshot kadang butuh Java terbaru & assetIndex snapshot
    fun isSnapshotUnstable(versionId: String): Boolean {
        // Snapshot minggu pertama biasanya paling rawan crash
        return VersionCompatibility.isSnapshot(versionId)
    }
}
