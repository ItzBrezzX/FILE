package com.flintclient.core.update

import com.flintclient.core.logging.FlintLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class UpdateInfo(val latestVersion: String, val changelog: String, val downloadUrl: String, val isUpdateAvailable: Boolean)

class UpdateManager(private val currentVersion: String) {
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("https://api.github.com/repos/flintclient/flint-client/releases/latest").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val json = JSONObject(resp.body!!.string())
                val tag = json.optString("tag_name", currentVersion)
                UpdateInfo(latestVersion = tag, changelog = json.optString("body", ""), downloadUrl = json.optString("html_url", ""), isUpdateAvailable = tag != currentVersion)
            }
        } catch (e: Exception) { FlintLogger.e("Update", "Check failed", e); null }
    }
}
