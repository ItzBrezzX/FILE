package com.flintclient.core.server

import com.flintclient.core.storage.StorageManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.File

data class FlintServer(val name: String, val address: String, val port: Int = 25565, val icon: String = "", val lastPing: Long = 0L, val motd: String = "")

class ServerManager(private val storage: StorageManager) {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    private val file get() = File(storage.configsDir, "servers.json")
    fun listServers(): List<FlintServer> {
        if (!file.exists()) return listOf(FlintServer("Hypixel", "mc.hypixel.net"), FlintServer("CubeCraft", "play.cubecraft.net"))
        return try { gson.fromJson(file.readText(), Array<FlintServer>::class.java).toList() } catch (e: Exception) { emptyList() }
    }
    fun saveServers(servers: List<FlintServer>) { file.writeText(gson.toJson(servers)) }
    fun addServer(server: FlintServer) { val list = listServers().toMutableList(); list.add(server); saveServers(list) }
    fun removeServer(address: String) { saveServers(listServers().filter { it.address != address }) }
    fun updateServer(server: FlintServer) { saveServers(listServers().map { if (it.address == server.address) server else it }) }
}
