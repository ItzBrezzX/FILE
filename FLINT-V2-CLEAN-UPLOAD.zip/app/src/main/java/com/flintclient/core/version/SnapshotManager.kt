package com.flintclient.core.version

import com.flintclient.core.logging.FlintLogger

object SnapshotManager {
    data class SnapshotInfo(val id: String, val targetVersion: String, val week: Int, val year: Int, val isExperimental: Boolean)
    fun parseSnapshot(id: String): SnapshotInfo? {
        // Contoh: 24w14a -> year 24, week 14, letter a
        val regex = Regex("^(\\d{2})w(\\d{2})([a-z])$")
        val match = regex.matchEntire(id.trim()) ?: return null
        val year = match.groupValues[1].toInt()
        val week = match.groupValues[2].toInt()
        val letter = match.groupValues[3]
        val isExperimental = letter != "a" // b, c, dst biasanya experimental / fix
        // Perkiraan target version dari tahun snapshot
        val target = when {
            year >= 25 -> "1.21.x"
            year >= 24 -> "1.21"
            year >= 23 -> "1.20.5"
            year >= 22 -> "1.20"
            else -> "1.19"
        }
        return SnapshotInfo(id, target, week, year, isExperimental)
    }
    fun sortSnapshotsNewestFirst(versions: List<VersionEntry>): List<VersionEntry> {
        return versions.filter { it.type == "snapshot" }.sortedByDescending { it.releaseTime }
    }
    fun getLatestSnapshot(versions: List<VersionEntry>): VersionEntry? = sortSnapshotsNewestFirst(versions).firstOrNull()
    fun getLatestBeta(versions: List<VersionEntry>): VersionEntry? = versions.filter { it.type == "old_beta" }.maxByOrNull { it.releaseTime }
    fun getLatestAlpha(versions: List<VersionEntry>): VersionEntry? = versions.filter { it.type == "old_alpha" }.maxByOrNull { it.releaseTime }
    fun logSnapshotWarning(id: String) {
        val info = parseSnapshot(id)
        if (info != null) {
            FlintLogger.w("Snapshot", "Menjalankan snapshot ${info.id} (target ${info.targetVersion}, week ${info.week}, experimental=${info.isExperimental}). Snapshot bisa crash / corrupt world. Backup world dulu!")
        }
    }
}
