package com.flintclient.core.mods

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.File
import java.util.jar.JarFile

data class ModInfo(val fileName: String, val modId: String, val name: String, val version: String, val loader: String, val enabled: Boolean, val size: Long, val minecraftVersion: String = "")

data class ModProfile(val id: String, val name: String, val enabledMods: List<String>)

class ModManager(private val storage: StorageManager) {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    fun listMods(instanceId: String): List<ModInfo> {
        val dir = storage.instanceModsDir(instanceId)
        val list = mutableListOf<ModInfo>()
        dir.listFiles()?.forEach { f ->
            if (f.extension == "jar" || f.extension == "disabled") {
                val enabled = f.extension == "jar"
                val info = parseModJar(f, enabled)
                list.add(info)
            }
        }
        return list.sortedBy { it.name }
    }
    fun parseModJar(file: File, enabled: Boolean): ModInfo {
        var modId = file.nameWithoutExtension
        var name = file.nameWithoutExtension
        var version = "unknown"
        var loader = "unknown"
        var mcVersion = ""
        try {
            JarFile(file).use { jar ->
                val fabricEntry = jar.getEntry("fabric.mod.json")
                if (fabricEntry != null) {
                    val json = com.google.gson.JsonParser.parseString(jar.getInputStream(fabricEntry).bufferedReader().readText()).asJsonObject
                    modId = json.get("id")?.asString ?: modId
                    name = json.get("name")?.asString ?: name
                    version = json.get("version")?.asString ?: version
                    loader = "fabric"
                    if (json.has("depends")) {
                        val deps = json.getAsJsonObject("depends")
                        if (deps.has("minecraft")) mcVersion = deps.get("minecraft").asString
                    }
                }
                val forgeEntry = jar.getEntry("META-INF/mods.toml")
                if (forgeEntry != null) {
                    loader = "forge"
                    val text = jar.getInputStream(forgeEntry).bufferedReader().readText()
                    val modIdMatch = Regex("modId\\s*=\\s*\"([^\"]+)\"").find(text)
                    if (modIdMatch != null) modId = modIdMatch.groupValues[1]
                    val nameMatch = Regex("displayName\\s*=\\s*\"([^\"]+)\"").find(text)
                    if (nameMatch != null) name = nameMatch.groupValues[1]
                }
                val quiltEntry = jar.getEntry("quilt.mod.json")
                if (quiltEntry != null) loader = "quilt"
            }
        } catch (e: Exception) { FlintLogger.w("ModManager", "Parse mod failed ${file.name}: ${e.message}") }
        return ModInfo(fileName = file.name, modId = modId, name = name, version = version, loader = loader, enabled = enabled, size = file.length(), minecraftVersion = mcVersion)
    }
    fun setModEnabled(instanceId: String, fileName: String, enabled: Boolean): Boolean {
        val dir = storage.instanceModsDir(instanceId)
        val file = File(dir, fileName)
        if (!file.exists()) return false
        val targetName = if (enabled) fileName.removeSuffix(".disabled") + ".jar" else fileName.removeSuffix(".jar") + ".disabled"
        // Normalize: if already correct extension, do nothing
        if (enabled && file.extension == "jar") return true
        if (!enabled && file.extension == "disabled") return true
        val target = File(dir, targetName)
        // Handle case where fileName already has .disabled
        val actualTargetName = if (enabled) file.name.removeSuffix(".disabled") else if (file.name.endsWith(".jar")) file.name.removeSuffix(".jar") + ".jar.disabled" else file.name + ".disabled"
        val actualTarget = File(dir, actualTargetName)
        return file.renameTo(actualTarget)
    }
    fun installMod(instanceId: String, source: File): Boolean {
        val dest = File(storage.instanceModsDir(instanceId), source.name)
        return try { source.copyTo(dest, overwrite = true); FlintLogger.i("ModManager", "Installed mod ${source.name}"); true } catch (e: Exception) { FlintLogger.e("ModManager", "Install failed", e); false }
    }
    fun deleteMod(instanceId: String, fileName: String): Boolean = File(storage.instanceModsDir(instanceId), fileName).delete()
    fun validateCompatibility(instanceMcVersion: String, mod: ModInfo): Boolean {
        if (mod.minecraftVersion.isEmpty()) return true
        // Simple check: if mod declares minecraft range containing instance version
        return mod.minecraftVersion.contains(instanceMcVersion) || mod.minecraftVersion.contains("*") || mod.minecraftVersion.contains(">=") || mod.minecraftVersion.contains("~")
    }
    fun listResourcePacks(instanceId: String): List<File> = storage.instanceResourcePacksDir(instanceId).listFiles()?.toList() ?: emptyList()
    fun listShaderPacks(instanceId: String): List<File> = storage.instanceShaderPacksDir(instanceId).listFiles()?.toList() ?: emptyList()
    fun listProfiles(instanceId: String): List<ModProfile> {
        val file = File(storage.instanceDir(instanceId), "mod-profiles.json")
        if (!file.exists()) return emptyList()
        return try { gson.fromJson(file.readText(), Array<ModProfile>::class.java).toList() } catch (e: Exception) { emptyList() }
    }
    fun saveProfiles(instanceId: String, profiles: List<ModProfile>) {
        val file = File(storage.instanceDir(instanceId), "mod-profiles.json")
        file.writeText(gson.toJson(profiles))
    }
}
