package com.flintclient.core.assets

import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.VersionJson
import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class AssetObject(val hash: String, val size: Long)

class AssetManager(private val storage: StorageManager) {
    private val gson = Gson()
    private val downloadEngine = DownloadEngine()
    suspend fun downloadAssetIndex(version: VersionJson): File = withContext(Dispatchers.IO) {
        val indexFile = File(storage.assetsDir, "indexes/${version.assetIndex.id}.json")
        indexFile.parentFile?.mkdirs()
        val task = DownloadTask(version.assetIndex.url, indexFile, version.assetIndex.sha1, version.assetIndex.size)
        downloadEngine.download(task)
        indexFile
    }
    suspend fun downloadAssets(version: VersionJson, onProgress: (Int, Int, String) -> Unit = {_,_,_ -> }): Int = withContext(Dispatchers.IO) {
        val indexFile = downloadAssetIndex(version)
        val json = JsonParser.parseString(indexFile.readText()).asJsonObject
        val objects = json.getAsJsonObject("objects")
        var count = 0
        var total = objects.size()
        var done = 0
        for ((name, elem) in objects.entrySet()) {
            val hash = elem.asJsonObject.get("hash").asString
            val size = elem.asJsonObject.get("size").asLong
            val prefix = hash.substring(0, 2)
            val dest = File(storage.assetsDir, "objects/$prefix/$hash")
            if (!dest.exists()) {
                val url = "https://resources.download.minecraft.net/$prefix/$hash"
                downloadEngine.download(DownloadTask(url, dest, hash, size))
                count++
            }
            done++
            if (done % 20 == 0) onProgress(done, total, name)
        }
        FlintLogger.i("AssetManager", "Assets done $done / $total, downloaded $count")
        count
    }

    // Phase 6: ensureAssets - wrapper used by LaunchManager. Downloads index + all objects if missing.
    suspend fun ensureAssets(version: VersionJson): Int {
        if (version.assetIndex == null) { FlintLogger.w("Assets", "No assetIndex for ${version.id}, skipping"); return 0 }
        return downloadAssets(version)
    }
}
