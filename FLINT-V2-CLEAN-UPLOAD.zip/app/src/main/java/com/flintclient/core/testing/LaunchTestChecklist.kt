package com.flintclient.core.testing

// TEST CHECKLIST - Buat lo test nanti, Part 6
// Jalankan checklist ini satu-satu, centang kalau lolos, screenshot kalau crash.

object LaunchTestChecklist {
    data class TestCase(val id: String, val title: String, val steps: List<String>, val expected: String)
    fun getAllTests(): List<TestCase> = listOf(
        TestCase("T01", "Buka Launcher", listOf("Install APK", "Buka FLINT", "Tunggu 3 detik"), "Main Menu muncul, tidak crash, RAM aman"),
        TestCase("T02", "Auto Update Snapshot", listOf("Buka Version Manager", "Pilih filter Snapshot", "Lihat latest snapshot"), "Snapshot terbaru Mojang muncul, ada badge NEW kalau ada yang baru"),
        TestCase("T03", "Install Release 1.21.10", listOf("Pilih 1.21.10", "Install", "Tunggu download selesai"), "Download 100%, tidak corrupt, bisa PLAY"),
        TestCase("T04", "PLAY 1.21.10", listOf("Klik PLAY 1.21.10", "Tunggu JVM + renderer load", "Masuk Title Screen"), "Title Screen muncul, bisa klik Singleplayer"),
        TestCase("T05", "Masuk World", listOf("Create New World", "Masuk world", "Jalan 30 detik"), "World ke-render, FPS >20, tidak crash"),
        TestCase("T06", "Snapshot Terbaru", listOf("Install snapshot terbaru", "PLAY snapshot"), "Snapshot jalan, warning backup muncul"),
        TestCase("T07", "Beta b1.7.3", listOf("Install b1.7.3", "PLAY"), "Beta jalan, LWJGL 2, suara mungkin hilang - wajar"),
        TestCase("T08", "Modrinth Live", listOf("Buka Mod Menu", "Search 'sodium'", "Download Sodium"), "Hasil search dari Modrinth API, bukan dummy, download sukses"),
        TestCase("T09", "Fabric Mod", listOf("Install Fabric 1.21.10", "Install Sodium via Modrinth", "PLAY"), "Game jalan dengan Sodium, FPS naik"),
        TestCase("T10", "Controller PS/Xbox", listOf("Connect controller Bluetooth", "Buka game", "Gerak pakai stick"), "Left stick = WASD, Right stick = mouse, A = klik"),
        TestCase("T11", "Keyboard + Mouse BT", listOf("Connect keyboard + mouse BT", "Main game"), "WASD + mouse jalan, tidak double input"),
        TestCase("T12", "Renderer", listOf("Settings > Renderer", "Ganti MobileGLUES / Angle / GL4ES", "Relaunch"), "Tiap renderer bisa jalan, tidak black screen"),
        TestCase("T13", "Low End HP", listOf("HP RAM 3GB", "PLAY 1.21.10"), "RAM auto max 1GB, tidak OOM crash"),
        TestCase("T14", "Relaunch Stabil", listOf("Keluar game", "PLAY lagi 3x"), "Tidak crash di launch ke-2 / ke-3"),
        TestCase("T15", "Offline", listOf("Matikan internet", "Buka launcher", "PLAY versi yang sudah di-install"), "Bisa PLAY offline dari cache")
    )
    fun getTestReportTemplate(): String {
        val sb = StringBuilder()
        sb.appendLine("FLINT TEST REPORT - Tanggal: __________ - HP: __________ - Android: __________ - RAM: __________")
        sb.appendLine("")
        getAllTests().forEach { t ->
            sb.appendLine("[ ] ${t.id} ${t.title} - PASS / FAIL - Catatan: __________")
        }
        sb.appendLine("")
        sb.appendLine("Crash log (kalau ada): copy dari Logcat / CrashReporter")
        return sb.toString()
    }
}
