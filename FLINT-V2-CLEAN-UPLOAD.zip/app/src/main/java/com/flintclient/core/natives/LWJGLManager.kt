package com.flintclient.core.natives
import com.flintclient.core.download.DownloadEngine
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
// LWJGL Android Pojav: lwjgl3 Android patch. HARUS pertama di classpath.
// FIX REAL: sebelumnya pakai URL.readText() (blocking, tanpa User-Agent -> GitHub 403 rate-limit) + parse string rapuh.
// Sekarang: OkHttp + JSON parse + fallback URL hardcoded kalau API gagal.
class LWJGLManager(private val storage: StorageManager) {
    private val downloadEngine = DownloadEngine()
    companion object {
        const val LWJGL_ANDROID_RELEASES_API = "https://api.github.com/repos/PojavLauncherTeam/lwjgl3/releases"
        const val LWJGL_ANDROID_JAR_NAME = "lwjgl-android.jar"
        // Fallback kalau GitHub API gagal (rate-limit / offline). Coba satu-satu, jangan langsung fail.
        val FALLBACK_URLS = listOf(
            "https://github.com/PojavLauncherTeam/lwjgl3/releases/download/3.3.3/lwjgl-3.3.3-android.jar",
            "https://github.com/PojavLauncherTeam/lwjgl3/releases/download/3.3.1/lwjgl-3.3.1-android.jar"
        )
    }
    fun lwjglAndroidJar(): File = File(storage.librariesDir, "lwjgl-android/" + LWJGL_ANDROID_JAR_NAME)
    fun isLWJGLAndroidInstalled(): Boolean { val f = lwjglAndroidJar(); return f.exists() && f.length() > 100000 }
    suspend fun ensureLWJGLAndroid(onProgress: (Int) -> Unit = {}): Boolean {
        if (isLWJGLAndroidInstalled()) { FlintLogger.i("LWJGL", "LWJGL Android sudah ada"); return true }
        val urls = mutableListOf<String>()
        resolveLWJGLAndroidUrl()?.let { urls.add(it) }
        urls.addAll(FALLBACK_URLS)
        for (url in urls.distinct()) {
            FlintLogger.i("LWJGL", "Coba download LWJGL Android dari $url")
            val dest = lwjglAndroidJar(); dest.parentFile?.mkdirs()
            if (downloadEngine.download(DownloadTask(url, dest, null, 0)) && isLWJGLAndroidInstalled()) {
                FlintLogger.i("LWJGL", "LWJGL Android OK: " + dest.absolutePath); return true
            }
            try { dest.delete() } catch (_: Exception) {}
        }
        FlintLogger.e("LWJGL", "Download LWJGL Android GAGAL semua URL - cek https://github.com/PojavLauncherTeam/lwjgl3/releases - BLOCKED")
        return false
    }
    suspend fun resolveLWJGLAndroidUrl(): String? {
        return try {
            val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(LWJGL_ANDROID_RELEASES_API).header("User-Agent", "FLINT-CLIENT").header("Accept", "application/vnd.github+json").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) { FlintLogger.w("LWJGL", "GitHub API LWJGL ${resp.code} - pakai fallback"); return null }
                val body = resp.body?.string() ?: return null
                // API return array, ambil release pertama yang punya asset .jar
                val arr = org.json.JSONArray(body)
                for (i in 0 until arr.length()) {
                    val rel = arr.getJSONObject(i)
                    val assets = rel.optJSONArray("assets") ?: continue
                    for (j in 0 until assets.length()) {
                        val a = assets.getJSONObject(j)
                        val url = a.optString("browser_download_url", "")
                        val name = a.optString("name", "")
                        if (url.endsWith(".jar") && (name.contains("lwjgl", ignoreCase = true) || name.contains("android", ignoreCase = true))) return url
                    }
                }
                null
            }
        } catch (e: Exception) { FlintLogger.e("LWJGL", "GitHub API LWJGL gagal: " + (e.message ?: "")); null }
    }
    fun buildClasspathWithLWJGLAndroidFirst(baseClasspath: List<File>): List<File> {
        val androidJar = lwjglAndroidJar()
        if (!androidJar.exists()) return baseClasspath
        val filtered = baseClasspath.filter { f -> val n = f.name; !(n.startsWith("lwjgl-") && !n.contains("android")) }
        return listOf(androidJar) + filtered
    }
}
