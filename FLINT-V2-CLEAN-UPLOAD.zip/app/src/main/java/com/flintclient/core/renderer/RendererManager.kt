package com.flintclient.core.renderer

import android.content.Context
import com.flintclient.core.logging.FlintLogger

// RENDERER MANAGER - FLINT Part 6
// Minecraft Java butuh OpenGL desktop, HP Android cuma punya OpenGL ES / Vulkan.
// Makanya butuh translator: MobileGLUES (paling baru, dipakai Zenith) / Angle (Vulkan) / GL4ES (lama, dipakai Pojav awal)
// FLINT pilih otomatis berdasarkan GPU + Android version.

enum class RendererType { MOBILE_GLUES, ANGLE, GL4ES, AUTO, GLES_DIRECT }

data class RendererInfo(val type: RendererType, val libName: String, val soFile: String, val minAndroid: Int, val notes: String)

object RendererManager {
    fun getAvailableRenderers(): List<RendererInfo> = listOf(
        RendererInfo(RendererType.MOBILE_GLUES, "MobileGLUES", "libMobileGLUES.so", 21, "Paling baru, paling stabil di 1.21+, dipakai Zenith 1.0.3. Rekomendasi FLINT."),
        RendererInfo(RendererType.ANGLE, "Angle", "libangle.so", 26, "Pakai Vulkan, paling kenceng di HP Snapdragon baru, tapi boros baterai."),
        RendererInfo(RendererType.GL4ES, "GL4ES", "libGL.so", 21, "Legacy, cocok untuk 1.12 ke bawah & HP lama, tapi lambat di 1.21.")
    )
    fun pickBestRenderer(context: Context, minecraftVersion: String, isLowEnd: Boolean): RendererType {
        // 1.21+ -> MobileGLUES, 1.12 ke bawah -> GL4ES, HP Snapdragon 8 Gen -> Angle bisa dipilih manual
        return when {
            isLowEnd -> RendererType.GL4ES
            minecraftVersion.startsWith("1.12") || minecraftVersion.startsWith("1.8") || minecraftVersion.startsWith("b1.") -> RendererType.GL4ES
            else -> RendererType.MOBILE_GLUES
        }
    }
    fun getRendererEnv(type: RendererType, nativeLibDir: String): Map<String, String> {
        return when (type) {
            RendererType.MOBILE_GLUES -> mapOf(
                "LIBGL_ES" to "2",
                "LIBGL_GL" to "21",
                "MOBILEGLUES_DEBUG" to "0",
                "LD_LIBRARY_PATH" to "$nativeLibDir:/vendor/lib64:/system/lib64"
            )
            RendererType.ANGLE -> mapOf("ANGLE_DEFAULT_PLATFORM" to "vulkan", "LIBGL_ES" to "2")
            RendererType.GL4ES -> mapOf("LIBGL_ES" to "2", "LIBGL_GL" to "21", "LIBGL_FB" to "3")
            RendererType.AUTO -> getRendererEnv(RendererType.MOBILE_GLUES, nativeLibDir)
            RendererType.GLES_DIRECT -> mapOf("LIBGL_ES" to "2")
        }
    }
    fun getNativeLibsForRenderer(type: RendererType): List<String> {
        return when (type) {
            RendererType.MOBILE_GLUES -> listOf("MobileGLUES", "vulkan_wrapper")
            RendererType.ANGLE -> listOf("angle", "vulkan")
            RendererType.GL4ES -> listOf("GL", "EGL")
            RendererType.AUTO -> getNativeLibsForRenderer(RendererType.MOBILE_GLUES)
            RendererType.GLES_DIRECT -> emptyList()
        }
    }
    fun logRendererChoice(type: RendererType, mcVersion: String) {
        FlintLogger.i("Renderer", "Minecraft $mcVersion -> Renderer $type")
    }
}
