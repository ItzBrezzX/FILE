package com.flintclient.core.launch

import com.flintclient.core.auth.MinecraftAccount
import com.flintclient.core.config.FlintConfig
import com.flintclient.core.instance.GameInstance
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.VersionJson
import java.io.File

object LaunchArguments {
    fun buildJvmArgs(config: FlintConfig, instance: GameInstance, version: VersionJson, nativesDir: File, classpath: String, storage: StorageManager): List<String> {
        val args = mutableListOf<String>()
        args.add("-Xms${config.ramMb / 2}m")
        args.add("-Xmx${config.ramMb}m")
        args.add("-Djava.library.path=${nativesDir.absolutePath}")
        args.add("-Dminecraft.launcher.brand=FLINT-CLIENT")
        args.add("-Dminecraft.launcher.version=1.0.0-flint")
        args.add("-Dorg.lwjgl.librarypath=${nativesDir.absolutePath}")
        args.add("-Dorg.lwjgl.util.Debug=false")
        args.add("-Dflint.renderer=${config.renderer}")
        args.add("-Dflint.fullbright=${config.fullbright}")
        args.add("-Dflint.fov=${config.fov}")
        // Split custom JVM args by space respecting quotes
        if (config.jvmArgs.isNotBlank()) {
            args.addAll(splitArgs(config.jvmArgs))
        }
        // Mojang JVM args from version.json with placeholder replacement
        version.arguments?.jvm?.forEach { arg ->
            when (arg) {
                is String -> args.add(replacePlaceholders(arg, config, version, nativesDir, classpath, storage))
                is Map<*, *> -> {
                    // Rule-based JVM arg - check rules
                    val rules = arg["rules"] as? List<Map<String, Any>>
                    var allowed = true
                    if (rules != null) {
                        allowed = rules.any { (it["action"] as? String) == "allow" }
                    }
                    if (allowed) {
                        val value = arg["value"]
                        when (value) {
                            is String -> args.add(replacePlaceholders(value, config, version, nativesDir, classpath, storage))
                            is List<*> -> value.forEach { v -> if (v is String) args.add(replacePlaceholders(v, config, version, nativesDir, classpath, storage)) }
                        }
                    }
                }
            }
        }
        args.add("-cp")
        args.add(classpath)
        args.add(version.mainClass)
        return args
    }
    fun buildGameArgs(config: FlintConfig, instance: GameInstance, version: VersionJson, account: MinecraftAccount, gameDir: File, assetsDir: File, assetsIndex: String): List<String> {
        val placeholders = mapOf(
            "\${auth_player_name}" to account.username,
            "\${version_name}" to version.id,
            "\${game_directory}" to gameDir.absolutePath,
            "\${assets_root}" to assetsDir.absolutePath,
            "\${assets_index_name}" to assetsIndex,
            "\${auth_uuid}" to account.uuid,
            "\${auth_access_token}" to account.accessToken,
            "\${clientid}" to "flint-client",
            "\${auth_xuid}" to "",
            "\${user_type}" to if (account.isOffline()) "legacy" else "mojang",
            "\${version_type}" to version.type,
            "\${resolution_width}" to config.width.toString(),
            "\${resolution_height}" to config.height.toString(),
            "\${user_properties}" to "{}",
            "\${quickPlayPath}" to "",
            "\${quickPlaySingleplayer}" to "",
            "\${quickPlayMultiplayer}" to "",
            "\${quickPlayRealms}" to ""
        )
        val args = mutableListOf<String>()
        if (version.minecraftArguments != null) {
            splitArgs(version.minecraftArguments).forEach { raw ->
                args.add(placeholders.entries.fold(raw) { acc, e -> acc.replace(e.key, e.value) })
            }
        } else {
            version.arguments?.game?.forEach { arg ->
                when (arg) {
                    is String -> args.add(placeholders.entries.fold(arg) { acc, e -> acc.replace(e.key, e.value) })
                    is Map<*, *> -> {
                        val rules = arg["rules"] as? List<Map<String, Any>>
                        val hasQuickPlay = (arg["value"] as? Any)?.toString()?.contains("quickPlay") == true
                        if (!hasQuickPlay) {
                            val value = arg["value"]
                            when (value) {
                                is String -> args.add(placeholders.entries.fold(value) { acc, e -> acc.replace(e.key, e.value) })
                                is List<*> -> value.forEach { v -> if (v is String) args.add(placeholders.entries.fold(v) { acc, e -> acc.replace(e.key, e.value) }) }
                            }
                        }
                    }
                }
            }
        }
        if (config.gameArgs.isNotBlank()) args.addAll(splitArgs(config.gameArgs))
        return args
    }
    fun replacePlaceholders(input: String, config: FlintConfig, version: VersionJson, nativesDir: File, classpath: String, storage: StorageManager): String {
        return input
            .replace("\${natives_directory}", nativesDir.absolutePath)
            .replace("\${launcher_name}", "FLINT-CLIENT")
            .replace("\${launcher_version}", "1.0.0-flint")
            .replace("\${classpath}", classpath)
            .replace("\${library_directory}", storage.librariesDir.absolutePath)
            .replace("\${classpath_separator}", ":")
    }
    fun splitArgs(input: String): List<String> {
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var inQuote = false
        var quoteChar = '"'
        for (c in input) {
            when {
                (c == '"' || c == '\'') && !inQuote -> { inQuote = true; quoteChar = c }
                c == quoteChar && inQuote -> { inQuote = false }
                c == ' ' && !inQuote -> { if (current.isNotEmpty()) { result.add(current.toString()); current = StringBuilder() } }
                else -> current.append(c)
            }
        }
        if (current.isNotEmpty()) result.add(current.toString())
        return result
    }
}
