package com.flintclient.core.launch

import com.flintclient.core.config.FlintConfig
import com.flintclient.core.instance.GameInstance
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.LegacyVersionSupport
import com.flintclient.core.version.SnapshotManager
import com.flintclient.core.version.VersionCompatibility
import com.flintclient.core.version.VersionJson
import java.io.File

object AllVersionLaunchHandler {
    // Entry point baru: handle SEMUA tipe versi dalam satu tempat
    fun prepareForVersion(config: FlintConfig, instance: GameInstance, version: VersionJson, storage: StorageManager): VersionLaunchPlan {
        val versionId = version.id
        val compat = VersionCompatibility.getCompatibility(versionId)
        FlintLogger.i("AllVersion", "Launching $versionId era=${compat.era} java=${compat.javaMajor} lwjgl=${compat.lwjglVersion} modernArgs=${compat.useModernArguments}")
        if (VersionCompatibility.isSnapshot(versionId)) {
            SnapshotManager.logSnapshotWarning(versionId)
        }
        val (canRun, msg) = LegacyVersionSupport.canRunOnAndroid(versionId)
        FlintLogger.i("AllVersion", "CanRun=$canRun : $msg")
        val gameDir = storage.instanceDir(instance.id)
        if (compat.needsLegacyFix) {
            LegacyVersionSupport.prepareLegacyGameDir(gameDir)
        }
        // Tentukan natives dir
        val nativesDir = if (compat.needsLegacyFix) {
            LegacyVersionSupport.getLegacyNativesDir(storage, versionId)
        } else {
            File(storage.nativesDir, versionId)
        }
        // JVM extra args dari compatibility
        val extraJvm = compat.jvmArgsExtra
        // Game args: modern vs legacy
        val useLegacyArgs = !compat.useModernArguments
        return VersionLaunchPlan(
            versionId = versionId,
            era = compat.era,
            javaMajor = compat.javaMajor,
            lwjglVersion = compat.lwjglVersion,
            nativesDir = nativesDir,
            extraJvmArgs = extraJvm,
            useLegacyArgs = useLegacyArgs,
            needsLegacyFix = compat.needsLegacyFix,
            warning = if (!canRun) msg else null
        )
    }
    data class VersionLaunchPlan(
        val versionId: String,
        val era: com.flintclient.core.version.MinecraftEra,
        val javaMajor: Int,
        val lwjglVersion: String,
        val nativesDir: File,
        val extraJvmArgs: List<String>,
        val useLegacyArgs: Boolean,
        val needsLegacyFix: Boolean,
        val warning: String?
    )
}
