package com.flintclient.core.update

import android.content.Context
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.VersionManager
import com.flintclient.core.version.VersionEntry
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// FLINT AUTO-UPDATE - Snapshot / Release baru otomatis muncul tanpa update APK
// Cara kerja: tiap buka launcher + tiap 6 jam (WorkManager), fetch version_manifest_v2.json dari Mojang
// Kalau latest.release / latest.snapshot berubah -> simpan cache, tampilkan badge NEW, notifikasi

data class NewVersionAlert(
    val type: String, // release / snapshot
    val versionId: String,
    val previousId: String?,
    val releaseTime: String,
    val isNew: Boolean
)

object AutoUpdateManager {
    private const val PREF_FILE = "flint_auto_update.json"
    private const val CACHE_MANIFEST = "version_manifest_cache.json"
    private val gson = Gson()

    data class CachedState(val lastRelease: String?, val lastSnapshot: String?, val lastCheck: Long, val seenVersions: Set<String>)

    fun getCacheFile(storage: StorageManager): File = File(storage.cacheDir, CACHE_MANIFEST)

    // Dipanggil di MainActivity.onCreate + di WorkManager tiap 6 jam
    suspend fun checkForNewVersions(context: Context, storage: StorageManager): List<NewVersionAlert> = withContext(Dispatchers.IO) {
        try {
            val versionManager = VersionManager(storage)
            val manifest = versionManager.fetchManifest()
            // Simpan cache manifest biar offline tetap bisa lihat list
            getCacheFile(storage).writeText(gson.toJson(manifest))
            val prev = loadState(storage)
            val alerts = mutableListOf<NewVersionAlert>()
            if (prev.lastRelease != null && manifest.latest.release != prev.lastRelease) {
                alerts.add(NewVersionAlert("release", manifest.latest.release, prev.lastRelease, "", true))
                FlintLogger.i("AutoUpdate", "NEW RELEASE: ${manifest.latest.release} (dulu ${prev.lastRelease})")
            }
            if (prev.lastSnapshot != null && manifest.latest.snapshot != prev.lastSnapshot) {
                alerts.add(NewVersionAlert("snapshot", manifest.latest.snapshot, prev.lastSnapshot, "", true))
                FlintLogger.i("AutoUpdate", "NEW SNAPSHOT: ${manifest.latest.snapshot} (dulu ${prev.lastSnapshot})")
            }
            // Pertama kali install: jangan anggap semua baru
            val isFirst = prev.lastRelease == null && prev.lastSnapshot == null
            val newState = CachedState(manifest.latest.release, manifest.latest.snapshot, System.currentTimeMillis(), (prev.seenVersions + manifest.versions.map { it.id }).toSet())
            saveState(storage, newState)
            if (isFirst) return@withContext emptyList<NewVersionAlert>()
            return@withContext alerts
        } catch (e: Exception) {
            FlintLogger.e("AutoUpdate", "Check gagal: ${e.message} - pakai cache lama")
            // Fallback: pakai cache manifest
            return@withContext emptyList()
        }
    }

    // Ambil list versi dari cache kalau offline
    fun getCachedManifest(storage: StorageManager): String? {
        val f = getCacheFile(storage)
        return if (f.exists()) f.readText() else null
    }

    // Badge NEW untuk versi yang belum pernah dilihat user
    fun isNewVersion(storage: StorageManager, versionId: String): Boolean {
        val state = loadState(storage)
        return !state.seenVersions.contains(versionId)
    }

    fun markVersionSeen(storage: StorageManager, versionId: String) {
        val s = loadState(storage)
        saveState(storage, s.copy(seenVersions = s.seenVersions + versionId))
    }

    private fun loadState(storage: StorageManager): CachedState {
        val f = File(storage.cacheDir, PREF_FILE)
        if (!f.exists()) return CachedState(null, null, 0L, emptySet())
        return try { gson.fromJson(f.readText(), CachedState::class.java) } catch (e: Exception) { CachedState(null, null, 0L, emptySet()) }
    }
    private fun saveState(storage: StorageManager, state: CachedState) {
        val f = File(storage.cacheDir, PREF_FILE)
        f.parentFile?.mkdirs()
        f.writeText(gson.toJson(state))
    }

    // Untuk UI: filter "Hanya yang baru" + "Snapshot terbaru"
    fun getLatestSnapshotFirst(versions: List<VersionEntry>): List<VersionEntry> {
        return versions.sortedWith(compareByDescending<VersionEntry> { it.type == "snapshot" }.thenByDescending { it.releaseTime })
    }
}
