package com.flintclient.core.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun FlintHUDOverlay(state: HUDState, showFps: Boolean = true, showCps: Boolean = true, showCoords: Boolean = true, showKeystrokes: Boolean = true) {
    Column(modifier = Modifier.padding(8.dp)) {
        if (showFps) Text("FPS: ${state.fps} | Ping: ${state.ping}ms | Mem: ${state.memoryUsedMb}/${state.memoryMaxMb} MB", color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Color.Black.copy(alpha = 0.5f)).padding(4.dp))
        if (showCoords) Text("XYZ: ${String.format("%.1f / %.1f / %.1f", state.x, state.y, state.z)} | ${state.direction}", color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Color.Black.copy(alpha = 0.5f)).padding(4.dp))
        if (showCps) Text("CPS: ${state.cps} | Armor: ${state.armor} | HP: ${state.health}", color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Color.Black.copy(alpha = 0.5f)).padding(4.dp))
        if (showKeystrokes) Text("W A S D  SPACE  SHIFT", color = Color.White, fontSize = 11.sp, modifier = Modifier.background(Color.Black.copy(alpha = 0.5f)).padding(4.dp))
    }
}
