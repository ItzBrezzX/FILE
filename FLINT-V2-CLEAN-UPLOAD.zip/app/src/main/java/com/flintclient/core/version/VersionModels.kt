package com.flintclient.core.version

import com.google.gson.annotations.SerializedName

data class VersionManifest(val latest: Latest, val versions: List<VersionEntry>)
data class Latest(val release: String, val snapshot: String, val releaseTime: String? = null, val snapshotTime: String? = null)
data class VersionEntry(val id: String, val type: String, val url: String, val time: String, val releaseTime: String, val sha1: String, val complianceLevel: Int)

data class VersionJson(
    val id: String,
    val type: String,
    val time: String,
    val releaseTime: String,
    @SerializedName("inheritsFrom") val inheritsFrom: String? = null,
    val arguments: Arguments? = null,
    val minecraftArguments: String? = null,
    val assetIndex: AssetIndexRef,
    val assets: String,
    val complianceLevel: Int = 0,
    val downloads: Downloads,
    val libraries: List<Library>,
    val logging: LoggingConfig? = null,
    val mainClass: String,
    val minimumLauncherVersion: Int = 0,
    val javaVersion: JavaVersionInfo? = null
)
data class JavaVersionInfo(val component: String, val majorVersion: Int)
data class AssetIndexRef(val id: String, val sha1: String, val size: Long, val totalSize: Long, val url: String)
data class Downloads(val client: DownloadInfo, val client_mappings: DownloadInfo? = null, val server: DownloadInfo? = null)
data class DownloadInfo(val sha1: String, val size: Long, val url: String)
data class Arguments(val game: List<Any>, val jvm: List<Any>)
data class LoggingConfig(val client: LoggingFile)
data class LoggingFile(val argument: String, val file: LoggingFileInfo, val type: String)
data class LoggingFileInfo(val id: String, val sha1: String, val size: Long, val url: String)

data class Library(
    val name: String,
    val downloads: LibraryDownloads? = null,
    val rules: List<Rule>? = null,
    val natives: Map<String, String>? = null,
    val extract: ExtractRule? = null,
    val url: String? = null
)
data class LibraryDownloads(val artifact: Artifact? = null, val classifiers: Map<String, Artifact>? = null)
data class Artifact(val path: String, val sha1: String, val size: Long, val url: String)
data class Rule(val action: String, val os: OsRule? = null, val features: Map<String, Boolean>? = null)
data class OsRule(val name: String? = null, val arch: String? = null, val version: String? = null)
data class ExtractRule(val exclude: List<String>? = null)
