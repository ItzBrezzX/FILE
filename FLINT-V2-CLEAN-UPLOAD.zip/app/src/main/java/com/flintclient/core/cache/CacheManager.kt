package com.flintclient.core.cache

import com.flintclient.core.storage.StorageManager
import java.io.File

class CacheManager(private val storage: StorageManager) {
    fun getCacheSize(): Long = storage.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun clearCache(): Boolean { storage.cacheDir.deleteRecursively(); storage.cacheDir.mkdirs(); return true }
    fun clearDownloads(): Boolean { storage.downloadsDir.listFiles()?.forEach { it.delete() }; return true }
    fun cleanupOldLogs(days: Int = 7) {
        val cutoff = System.currentTimeMillis() - days * 24L * 3600L * 1000L
        storage.logsDir.listFiles()?.filter { it.lastModified() < cutoff }?.forEach { it.delete() }
    }
    fun cacheFile(key: String): File = File(storage.cacheDir, key)
}
