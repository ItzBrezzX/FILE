package com.flintclient.core.java

import com.flintclient.core.download.DownloadEngine
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import com.flintclient.core.download.DownloadTask
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.*

data class JavaRuntime(val id: String, val version: Int, val path: File, val isInstalled: Boolean, val libJvmSo: File? = null)

class JavaRuntimeManager(private val storage: StorageManager) {
    private val downloadEngine = DownloadEngine()
    companion object {
        const val POJAV_JRE_RELEASES_API = "https://api.github.com/repos/PojavLauncherTeam/android-openjdk-build/releases"
    }
    fun libJvmSoFor(javaMajor: Int): File? {
        val candidates = listOf(
            File(storage.runtimesDir, "java-" + javaMajor + "/lib/server/libjvm.so"),
            File(storage.runtimesDir, "java-" + javaMajor + "/jre/lib/aarch64/server/libjvm.so"),
            File(storage.runtimesDir, "java-" + javaMajor + "/lib/aarch64/server/libjvm.so")
        )
        return candidates.firstOrNull { it.exists() && it.length() > 1000000 && isBionicJvm(it) }
    }
    fun isBionicJvm(libJvmSo: File): Boolean {
        return try {
            val release = File(libJvmSo.parentFile?.parentFile?.parentFile, "release")
            if (release.exists() && release.readText().contains("Adoptium", ignoreCase = true)) {
                FlintLogger.e("JavaRuntime", "REJECTED Adoptium libjvm.so - glibc, tidak kompatibel Bionic.")
                return false
            }
            FileInputStream(libJvmSo).use { fis ->
                val magic = ByteArray(4); fis.read(magic)
                magic[0]==0x7f.toByte() && magic[1]==69.toByte() && magic[2]==76.toByte() && magic[3]==70.toByte()
            }
        } catch (e: Exception) { false }
    }
    fun isRuntimeInstalled(javaMajor: Int): Boolean = libJvmSoFor(javaMajor) != null
    fun listRuntimes(): List<JavaRuntime> = listOf(8,17,21).map { v ->
        val so = libJvmSoFor(v)
        JavaRuntime("java-" + v, v, File(storage.runtimesDir, "java-" + v), so != null, so)
    }
    fun getJavaForVersion(minecraftVersion: String, javaMajor: Int): JavaRuntime = listRuntimes().first { it.version == javaMajor }
    suspend fun downloadRuntime(javaMajor: Int, onProgress: (Int) -> Unit = {}): Boolean {
        try {
            FlintLogger.i("JavaRuntime", "Download Pojav Android JRE " + javaMajor + " (Bionic) - BUKAN Adoptium")
            val url = resolvePojavJreUrl(javaMajor)
            if (url == null) { FlintLogger.e("JavaRuntime", "Gagal resolve URL Pojav JRE " + javaMajor + " - cek https://github.com/PojavLauncherTeam/android-openjdk-build/releases"); return false }
            val dest = File(storage.downloadsDir, "jre-" + javaMajor + "-android-aarch64.tar.xz")
            FlintLogger.i("JavaRuntime", "Download dari " + url)
            downloadEngine.download(DownloadTask(url, dest, null, 0))
            val ok = extractTarXz(dest, File(storage.runtimesDir, "java-" + javaMajor))
            if (!ok) { FlintLogger.e("JavaRuntime", "Extract Pojav JRE FAILED"); return false }
            val so = libJvmSoFor(javaMajor)
            if (so == null) { FlintLogger.e("JavaRuntime", "libjvm.so Pojav TIDAK DITEMUKAN / masih glibc - BLOCKED"); return false }
            FlintLogger.i("JavaRuntime", "Pojav JRE " + javaMajor + " OK: " + so.absolutePath)
            return true
        } catch (e: Exception) { FlintLogger.e("JavaRuntime", "downloadRuntime Pojav FAILED: " + (e.message ?: "")); return false }
    }
    suspend fun resolvePojavJreUrl(javaMajor: Int): String? {
        return try {
            val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(POJAV_JRE_RELEASES_API).header("User-Agent", "FLINT-CLIENT").header("Accept", "application/vnd.github+json").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) { FlintLogger.w("JavaRuntime", "GitHub API Pojav JRE ${resp.code}"); return null }
                val body = resp.body?.string() ?: return null
                val needle = "jre-" + javaMajor
                val arr = org.json.JSONArray(body)
                for (i in 0 until arr.length()) {
                    val assets = arr.getJSONObject(i).optJSONArray("assets") ?: continue
                    for (j in 0 until assets.length()) {
                        val url = assets.getJSONObject(j).optString("browser_download_url", "")
                        val name = assets.getJSONObject(j).optString("name", "")
                        if (url.endsWith(".tar.xz") && name.contains(needle) && (name.contains("aarch64") || name.contains("arm64"))) return url
                    }
                }
                // Fallback: cari .tar.xz apapun yang mengandung jre-<major>
                for (i in 0 until arr.length()) {
                    val assets = arr.getJSONObject(i).optJSONArray("assets") ?: continue
                    for (j in 0 until assets.length()) {
                        val url = assets.getJSONObject(j).optString("browser_download_url", "")
                        if (url.endsWith(".tar.xz") && url.contains(needle)) return url
                    }
                }
                null
            }
        } catch (e: Exception) {
            FlintLogger.w("JavaRuntime", "GitHub API gagal: " + (e.message ?: ""))
            null
        }
    }
    fun extractTarXz(tarXz: File, destDir: File): Boolean {
        destDir.mkdirs()
        // REAL FIX: sebelumnya pakai ProcessBuilder("tar",...) - binary tar tidak dijamin ada di HP Android (toybox tar tanpa -J di banyak ROM).
        // Sekarang: pure-Java via XZInputStream (org.tukaani:xz) + TarArchiveInputStream (commons-compress). Fallback ke binary tar kalau lib tidak ada.
        return try {
            val xzIn = org.tukaani.xz.XZInputStream(java.io.FileInputStream(tarXz))
            val tarIn = org.apache.commons.compress.archivers.tar.TarArchiveInputStream(xzIn)
            var count = 0
            while (true) {
                val entry = tarIn.nextTarEntry ?: break
                // strip-components=1: buang komponen pertama (misal jre-17/...)
                val name = entry.name.substringAfter("/", entry.name)
                if (name.isEmpty()) continue
                val out = File(destDir, name)
                if (entry.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                out.outputStream().use { o -> tarIn.copyTo(o) }
                if (entry.mode and 0b111000000 != 0) out.setExecutable(true)
                count++
            }
            tarIn.close()
            FlintLogger.i("JavaRuntime", "extract tar.xz pure-Java OK, $count files")
            count > 0
        } catch (e: NoClassDefFoundError) {
            FlintLogger.w("JavaRuntime", "xz/commons-compress tidak ada, fallback ke binary tar: ${e.message}")
            extractViaBinaryTar(tarXz, destDir)
        } catch (e: Exception) {
            FlintLogger.w("JavaRuntime", "extract pure-Java gagal (${e.message}), fallback binary tar")
            extractViaBinaryTar(tarXz, destDir)
        }
    }
    private fun extractViaBinaryTar(tarXz: File, destDir: File): Boolean {
        return try {
            val proc = ProcessBuilder("tar", "-xJf", tarXz.absolutePath, "-C", destDir.absolutePath, "--strip-components=1").redirectErrorStream(true).start()
            val out = proc.inputStream.bufferedReader().readText()
            val code = proc.waitFor()
            if (code == 0) { FlintLogger.i("JavaRuntime", "tar -xJf OK"); return true }
            FlintLogger.e("JavaRuntime", "tar -xJf exit $code: $out")
            false
        } catch (e: Exception) { FlintLogger.e("JavaRuntime", "extractViaBinaryTar FAILED: " + (e.message ?: "")); false }
    }
}
