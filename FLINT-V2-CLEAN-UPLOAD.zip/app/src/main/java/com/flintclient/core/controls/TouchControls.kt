package com.flintclient.core.controls

import com.flintclient.core.config.FlintConfig

data class TouchButton(val id: String, val label: String, val keyCode: Int, val x: Float, val y: Float, val size: Float, val visible: Boolean = true)

object TouchControls {
    fun defaultLayout(): List<TouchButton> = listOf(
        TouchButton("jump", "JUMP", 57, 0.85f, 0.65f, 64f), // SPACE
        TouchButton("sneak", "SNEAK", 42, 0.85f, 0.80f, 56f), // SHIFT
        TouchButton("attack", "ATK", -1, 0.70f, 0.65f, 72f),
        TouchButton("use", "USE", -2, 0.70f, 0.80f, 72f),
        TouchButton("inventory", "E", 18, 0.08f, 0.08f, 48f),
        TouchButton("chat", "CHAT", 20, 0.15f, 0.08f, 48f),
        TouchButton("zoom", "ZOOM", -3, 0.92f, 0.15f, 48f),
        TouchButton("fly", "FLY", 33, 0.92f, 0.30f, 48f)
    )
    fun joystickToMovement(dx: Float, dy: Float): Pair<Boolean, Boolean> {
        // Returns (forward, strafe) thresholds
        val forward = dy < -0.3f
        val back = dy > 0.3f
        val left = dx < -0.3f
        val right = dx > 0.3f
        return Pair(forward || back, left || right)
    }
    fun sensitivityToMouseDelta(config: FlintConfig, dx: Float, dy: Float): Pair<Float, Float> {
        return Pair(dx * config.sensitivity * 0.5f, dy * config.sensitivity * 0.5f)
    }
}
