package com.flintclient.core.storage

import android.content.Context
import java.io.File

class StorageManager(private val context: Context) {
    lateinit var rootDir: File; private set
    lateinit var versionsDir: File; private set
    lateinit var instancesDir: File; private set
    lateinit var librariesDir: File; private set
    lateinit var assetsDir: File; private set
    lateinit var nativesDir: File; private set
    lateinit var runtimesDir: File; private set
    lateinit var modsDir: File; private set
    lateinit var resourcePacksDir: File; private set
    lateinit var shaderPacksDir: File; private set
    lateinit var screenshotsDir: File; private set
    lateinit var logsDir: File; private set
    lateinit var crashReportsDir: File; private set
    lateinit var configsDir: File; private set
    lateinit var accountsDir: File; private set
    lateinit var downloadsDir: File; private set
    lateinit var cacheDir: File; private set
    lateinit var backupsDir: File; private set
    lateinit var skinsDir: File; private set

    fun initialize() {
        val external = context.getExternalFilesDir(null) ?: context.filesDir
        rootDir = File(external, "flint")
        versionsDir = File(rootDir, "versions")
        instancesDir = File(rootDir, "instances")
        librariesDir = File(rootDir, "libraries")
        assetsDir = File(rootDir, "assets")
        nativesDir = File(rootDir, "natives")
        runtimesDir = File(rootDir, "runtimes")
        modsDir = File(rootDir, "mods")
        resourcePacksDir = File(rootDir, "resourcepacks")
        shaderPacksDir = File(rootDir, "shaderpacks")
        screenshotsDir = File(rootDir, "screenshots")
        logsDir = File(rootDir, "logs")
        crashReportsDir = File(rootDir, "crash-reports")
        configsDir = File(rootDir, "configs")
        accountsDir = File(rootDir, "accounts")
        downloadsDir = File(rootDir, "downloads")
        cacheDir = File(rootDir, "cache")
        backupsDir = File(rootDir, "backups")
        skinsDir = File(rootDir, "skins")
        listOf(rootDir, versionsDir, instancesDir, librariesDir, assetsDir, nativesDir, runtimesDir, modsDir, resourcePacksDir, shaderPacksDir, screenshotsDir, logsDir, crashReportsDir, configsDir, accountsDir, downloadsDir, cacheDir, backupsDir, skinsDir).forEach { it.mkdirs() }
    }
    // FIX Phase 6: LaunchManager uses gameDir / nativeLibDir / versionDir / assetsDir - add aliases so it compiles.
    val gameDir: File get() = File(rootDir, "game").apply { mkdirs() }
    val nativeLibDir: String get() = context.applicationInfo.nativeLibraryDir
    fun gameDirFile(): File = gameDir
    fun instanceDir(instanceId: String): File = File(instancesDir, instanceId).apply { mkdirs() }
    fun versionDir(versionId: String): File = File(versionsDir, versionId).apply { mkdirs() }
    fun instanceModsDir(instanceId: String): File = File(instanceDir(instanceId), "mods").apply { mkdirs() }
    fun instanceResourcePacksDir(instanceId: String): File = File(instanceDir(instanceId), "resourcepacks").apply { mkdirs() }
    fun instanceShaderPacksDir(instanceId: String): File = File(instanceDir(instanceId), "shaderpacks").apply { mkdirs() }
    fun instanceScreenshotsDir(instanceId: String): File = File(instanceDir(instanceId), "screenshots").apply { mkdirs() }
    fun instanceLogsDir(instanceId: String): File = File(instanceDir(instanceId), "logs").apply { mkdirs() }
    fun instanceCrashDir(instanceId: String): File = File(instanceDir(instanceId), "crash-reports").apply { mkdirs() }
    fun totalSize(): Long = rootDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun clearCache(): Boolean { cacheDir.deleteRecursively(); cacheDir.mkdirs(); return true }
}
