package com.flintclient.core.logging

import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

object FlintLogger {
    private var logFile: File? = null
    private val lock = ReentrantLock()
    private val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    fun init(logsDir: File) {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        logFile = File(logsDir, "flint-$date.log")
        if (!logFile!!.exists()) logFile!!.createNewFile()
    }
    private fun write(level: String, tag: String, msg: String) {
        val line = "[${sdf.format(Date())}] [$level] [$tag] $msg\n"
        lock.withLock {
            try { logFile?.appendText(line) } catch (e: Exception) { }
        }
        when(level) {
            "E" -> Log.e("FLINT", "[$tag] $msg")
            "W" -> Log.w("FLINT", "[$tag] $msg")
            else -> Log.i("FLINT", "[$tag] $msg")
        }
    }
    fun i(tag: String, msg: String) = write("I", tag, msg)
    fun w(tag: String, msg: String) = write("W", tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) = write("E", tag, msg + (t?.let { " : ${it.message}" } ?: ""))
    fun d(tag: String, msg: String) = write("D", tag, msg)
}
