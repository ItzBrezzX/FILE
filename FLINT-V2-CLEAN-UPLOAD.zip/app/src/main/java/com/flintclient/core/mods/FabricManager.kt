package com.flintclient.core.mods

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.flintclient.core.version.VersionJson
import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

data class FabricLoaderInfo(val loaderVersion: String, val minecraftVersion: String, val stable: Boolean)

class FabricManager(private val storage: StorageManager) {
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val gson = Gson()
    suspend fun getLatestLoader(mcVersion: String): FabricLoaderInfo? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("https://meta.fabricmc.net/v2/versions/loader/$mcVersion").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val arr = JsonParser.parseString(resp.body!!.string()).asJsonArray
                if (arr.size() == 0) return@withContext null
                val obj = arr[0].asJsonObject
                val loader = obj.getAsJsonObject("loader")
                FabricLoaderInfo(loader.get("version").asString, mcVersion, loader.get("stable").asBoolean)
            }
        } catch (e: Exception) { FlintLogger.e("Fabric", "fetch loader failed", e); null }
    }
    suspend fun getProfileJson(mcVersion: String, loaderVersion: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("https://meta.fabricmc.net/v2/versions/loader/$mcVersion/$loaderVersion/profile/json").build()
            client.newCall(req).execute().use { resp -> if (!resp.isSuccessful) return@withContext null; resp.body!!.string() }
        } catch (e: Exception) { FlintLogger.e("Fabric", "profile failed", e); null }
    }
    suspend fun installFabric(mcVersion: String, loaderVersion: String? = null): Boolean {
        val loader = loaderVersion ?: getLatestLoader(mcVersion)?.loaderVersion ?: return false
        val profileJson = getProfileJson(mcVersion, loader) ?: return false
        val versionId = "fabric-loader-$loader-$mcVersion"
        val dir = storage.versionDir(versionId)
        File(dir, "$versionId.json").writeText(profileJson)
        FlintLogger.i("Fabric", "Installed $versionId")
        return true
    }
    fun isFabricInstalled(mcVersion: String): Boolean {
        return storage.versionsDir.listFiles()?.any { it.name.startsWith("fabric-loader-") && it.name.endsWith(mcVersion) } == true
    }
}
