package com.flintclient.core.version

// FLINT CLIENT - Version Compatibility Matrix
// Minecraft berubah total cara launch-nya di tiap era.
// File ini yang bikin semua versi Release / Snapshot / Beta / Alpha bisa jalan.

enum class MinecraftEra {
    ALPHA,      // a1.0 - a1.2.6 : Java 8, LWJGL 2, assets lama, no assetIndex modern
    BETA,       // b1.0 - b1.8.1 : Java 8, LWJGL 2, legacy assets
    LEGACY,     // 1.0 - 1.5.2 : Java 8, LWJGL 2, minecraftArguments lama
    TRANSITION, // 1.6 - 1.12.2 : Java 8, LWJGL 2/3 transisi, arguments baru mulai 1.13
    MODERN,     // 1.13 - 1.16.5 : Java 8/17, LWJGL 3, arguments baru
    JAVA17,     // 1.17 - 1.17.1 : Java 16/17 wajib, LWJGL 3
    JAVA17_PLUS,// 1.18 - 1.20.4 : Java 17
    JAVA21      // 1.20.5+ / 1.21+ : Java 21
}

data class VersionCompatInfo(
    val era: MinecraftEra,
    val javaMajor: Int,
    val lwjglVersion: String,
    val useModernArguments: Boolean,
    val useAssetIndex: Boolean,
    val needsLegacyFix: Boolean,
    val jvmArgsExtra: List<String>,
    val notes: String
)

object VersionCompatibility {
    fun getEra(versionId: String): MinecraftEra {
        val v = versionId.trim()
        // Alpha: a1.x, Alpha 1.x
        if (v.startsWith("a1.") || v.startsWith("alpha") || v.startsWith("a0.")) return MinecraftEra.ALPHA
        // Beta: b1.x, Beta 1.x
        if (v.startsWith("b1.") || v.startsWith("beta")) return MinecraftEra.BETA
        // Snapshot: 24wxx, 25wxx, 23wxx etc - snapshot ikut versi targetnya, tapi treat sebagai MODERN/JAVA21 tergantung tahun
        if (isSnapshot(v)) {
            val year = v.substring(0, 2).toIntOrNull() ?: 24
            return when {
                year >= 24 -> MinecraftEra.JAVA21
                year >= 23 -> MinecraftEra.JAVA17_PLUS
                year >= 22 -> MinecraftEra.JAVA17_PLUS
                else -> MinecraftEra.MODERN
            }
        }
        // Release: 1.x
        val parts = v.split(".")
        if (parts.size < 2 || parts[0] != "1") return MinecraftEra.MODERN
        val minor = parts[1].toIntOrNull() ?: 21
        return when {
            minor <= 5 -> MinecraftEra.LEGACY
            minor <= 12 -> MinecraftEra.TRANSITION
            minor <= 16 -> MinecraftEra.MODERN
            minor == 17 -> MinecraftEra.JAVA17
            minor <= 20 -> {
                // 1.20.5+ butuh Java 21
                val patch = if (parts.size > 2) parts[2].toIntOrNull() ?: 0 else 0
                if (minor == 20 && patch >= 5) MinecraftEra.JAVA21 else MinecraftEra.JAVA17_PLUS
            }
            else -> MinecraftEra.JAVA21
        }
    }
    fun isSnapshot(versionId: String): Boolean {
        // Format snapshot Mojang: 24w14a, 25w02a, 23w07a, dll. Regex: 2 digit tahun + w + 2 digit minggu + huruf
        return Regex("^\\d{2}w\\d{2}[a-z]$").matches(versionId.trim())
    }
    fun isBeta(versionId: String): Boolean = versionId.startsWith("b1.") || versionId.startsWith("beta")
    fun isAlpha(versionId: String): Boolean = versionId.startsWith("a1.") || versionId.startsWith("alpha")
    fun isRelease(versionId: String): Boolean = Regex("^1\\.\\d+(\\.\\d+)?$").matches(versionId.trim())
    fun getCompatibility(versionId: String): VersionCompatInfo {
        return when (getEra(versionId)) {
            MinecraftEra.ALPHA -> VersionCompatInfo(
                era = MinecraftEra.ALPHA,
                javaMajor = 8,
                lwjglVersion = "2.9.4",
                useModernArguments = false,
                useAssetIndex = false,
                needsLegacyFix = true,
                jvmArgsExtra = listOf("-Djava.util.Arrays.useLegacyMergeSort=true", "-Dminecraft.alpha=true"),
                notes = "Alpha: pakai LWJGL 2.9.4, assets di .minecraft/resources, tidak ada assetIndex modern"
            )
            MinecraftEra.BETA -> VersionCompatInfo(
                era = MinecraftEra.BETA,
                javaMajor = 8,
                lwjglVersion = "2.9.4",
                useModernArguments = false,
                useAssetIndex = false,
                needsLegacyFix = true,
                jvmArgsExtra = listOf("-Djava.util.Arrays.useLegacyMergeSort=true"),
                notes = "Beta: LWJGL 2, legacy sound system, butuh legacy natives"
            )
            MinecraftEra.LEGACY -> VersionCompatInfo(
                era = MinecraftEra.LEGACY,
                javaMajor = 8,
                lwjglVersion = "2.9.4",
                useModernArguments = false,
                useAssetIndex = true,
                needsLegacyFix = true,
                jvmArgsExtra = listOf("-Djava.util.Arrays.useLegacyMergeSort=true"),
                notes = "1.0-1.5.2: minecraftArguments lama, LWJGL 2"
            )
            MinecraftEra.TRANSITION -> VersionCompatInfo(
                era = MinecraftEra.TRANSITION,
                javaMajor = 8,
                lwjglVersion = "2.9.4",
                useModernArguments = false,
                useAssetIndex = true,
                needsLegacyFix = false,
                jvmArgsExtra = emptyList(),
                notes = "1.6-1.12.2: Java 8, LWJGL 2, mulai pakai assetIndex"
            )
            MinecraftEra.MODERN -> VersionCompatInfo(
                era = MinecraftEra.MODERN,
                javaMajor = 8,
                lwjglVersion = "3.3.1",
                useModernArguments = true,
                useAssetIndex = true,
                needsLegacyFix = false,
                jvmArgsExtra = emptyList(),
                notes = "1.13-1.16.5: LWJGL 3, arguments baru"
            )
            MinecraftEra.JAVA17 -> VersionCompatInfo(
                era = MinecraftEra.JAVA17,
                javaMajor = 17,
                lwjglVersion = "3.3.1",
                useModernArguments = true,
                useAssetIndex = true,
                needsLegacyFix = false,
                jvmArgsExtra = listOf("--add-opens", "java.base/java.lang=ALL-UNNAMED"),
                notes = "1.17: Java 17 wajib, butuh --add-opens"
            )
            MinecraftEra.JAVA17_PLUS -> VersionCompatInfo(
                era = MinecraftEra.JAVA17_PLUS,
                javaMajor = 17,
                lwjglVersion = "3.3.2",
                useModernArguments = true,
                useAssetIndex = true,
                needsLegacyFix = false,
                jvmArgsExtra = listOf("--add-opens", "java.base/java.lang=ALL-UNNAMED"),
                notes = "1.18-1.20.4: Java 17"
            )
            MinecraftEra.JAVA21 -> VersionCompatInfo(
                era = MinecraftEra.JAVA21,
                javaMajor = 21,
                lwjglVersion = "3.3.3",
                useModernArguments = true,
                useAssetIndex = true,
                needsLegacyFix = false,
                jvmArgsExtra = listOf("--add-opens", "java.base/java.lang=ALL-UNNAMED"),
                notes = "1.20.5+ / 1.21+: Java 21"
            )
        }
    }
    fun getJavaForVersion(versionId: String): Int = getCompatibility(versionId).javaMajor
    fun getLWJGLForVersion(versionId: String): String = getCompatibility(versionId).lwjglVersion
    // Filter manifest by type
    fun filterByType(versions: List<VersionEntry>, type: String): List<VersionEntry> {
        return when (type.lowercase()) {
            "release" -> versions.filter { it.type == "release" }
            "snapshot" -> versions.filter { it.type == "snapshot" }
            "beta" -> versions.filter { it.type == "old_beta" }
            "alpha" -> versions.filter { it.type == "old_alpha" }
            "all" -> versions
            else -> versions
        }
    }
    fun getTypeLabel(type: String): String = when (type) {
        "release" -> "Release"
        "snapshot" -> "Snapshot"
        "old_beta" -> "Beta"
        "old_alpha" -> "Alpha"
        else -> type
    }
}


