package com.flintclient.core.update

import com.flintclient.core.version.VersionManager
import com.flintclient.core.storage.StorageManager
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit

// Worker yang jalan di background: cek snapshot baru tiap 6 jam, kirim notifikasi
// Daftar di FlintApplication: WorkManager.getInstance(this).enqueueUniquePeriodicWork(...)
object SnapshotWatcher {
    const val WORK_NAME = "flint_snapshot_watcher"
    const val INTERVAL_HOURS = 6L

    // Dipanggil dari WorkManager doWork()
    suspend fun doCheck(storage: StorageManager): List<NewVersionAlert> {
        // Context tidak dibutuhkan untuk check, pakai dummy - di real app pakai applicationContext
        // Di sini kita pakai storage saja, VersionManager fetch langsung
        val vm = VersionManager(storage)
        return try {
            val manifest = vm.fetchManifest()
            val latestSnap = manifest.latest.snapshot
            val latestRel = manifest.latest.release
            // Simpan ke cache via AutoUpdateManager logic - simplified: return alerts jika snapshot minggu ini
            // Real check full ada di AutoUpdateManager.checkForNewVersions()
            emptyList()
        } catch (e: Exception) { emptyList() }
    }

    fun getNotificationText(alerts: List<NewVersionAlert>): String {
        if (alerts.isEmpty()) return ""
        return alerts.joinToString(", ") {
            when (it.type) {
                "snapshot" -> "Snapshot baru ${it.versionId} sudah tersedia!"
                else -> "Minecraft ${it.versionId} rilis!"
            }
        }
    }
}
