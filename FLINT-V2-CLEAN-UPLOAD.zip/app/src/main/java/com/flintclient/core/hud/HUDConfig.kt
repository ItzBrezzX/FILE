package com.flintclient.core.hud

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.flintclient.core.logging.FlintLogger

data class HUDState(var fps: Int = 0, var cps: Int = 0, var x: Double = 0.0, var y: Double = 0.0, var z: Double = 0.0, var direction: String = "North", var ping: Int = 0, var memoryUsedMb: Int = 0, var memoryMaxMb: Int = 0, var armor: Int = 0, var health: Float = 20f)

object HUDDataHolder {
    var state: HUDState = HUDState()
    var listeners: MutableList<(HUDState) -> Unit> = mutableListOf()
    fun update(block: (HUDState) -> Unit) { block(state); listeners.forEach { it(state) } }
}

class HUDOverlayService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        FlintLogger.i("HUD", "HUD Overlay Service started")
        return START_STICKY
    }
}
