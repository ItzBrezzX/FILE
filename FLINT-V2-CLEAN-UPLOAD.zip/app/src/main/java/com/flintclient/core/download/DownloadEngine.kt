package com.flintclient.core.download

import com.flintclient.core.logging.FlintLogger
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class DownloadTask(val url: String, val dest: File, val sha1: String? = null, val size: Long = 0L)
data class DownloadProgress(val downloaded: Long, val total: Long, val fileName: String, val percent: Int)

class DownloadEngine {
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS).build()
    suspend fun download(task: DownloadTask, onProgress: (DownloadProgress) -> Unit = {}): Boolean = withContext(Dispatchers.IO) {
        try {
            if (task.dest.exists() && task.sha1 != null && sha1(task.dest) == task.sha1) { onProgress(DownloadProgress(task.size, task.size, task.dest.name, 100)); return@withContext true }
            task.dest.parentFile?.mkdirs()
            val req = Request.Builder().url(task.url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) { FlintLogger.e("Download", "HTTP ${resp.code} for ${task.url}"); return@withContext false }
                val body = resp.body ?: return@withContext false
                val total = body.contentLength().takeIf { it > 0 } ?: task.size
                var downloaded = 0L
                FileOutputStream(task.dest).use { out ->
                    body.byteStream().use { input ->
                        val buf = ByteArray(8192)
                        while (true) {
                            val read = input.read(buf)
                            if (read == -1) break
                            out.write(buf, 0, read)
                            downloaded += read
                            if (total > 0) onProgress(DownloadProgress(downloaded, total, task.dest.name, ((downloaded * 100) / total).toInt()))
                        }
                    }
                }
                if (task.sha1 != null && sha1(task.dest) != task.sha1) { FlintLogger.e("Download", "SHA1 mismatch ${task.dest.name}"); task.dest.delete(); return@withContext false }
                FlintLogger.i("Download", "OK ${task.dest.name} $downloaded bytes")
                return@withContext true
            }
        } catch (e: Exception) { FlintLogger.e("Download", "Failed ${task.url}", e); false }
    }
    suspend fun downloadAll(tasks: List<DownloadTask>, onProgress: (DownloadProgress) -> Unit = {}): Boolean {
        var ok = true
        for (t in tasks) { if (!download(t, onProgress)) ok = false }
        return ok
    }
    fun sha1(file: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        file.inputStream().use { ins -> val buf = ByteArray(8192); var r: Int; while (ins.read(buf).also { r = it } != -1) md.update(buf, 0, r) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
    fun sha1Hex(bytes: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-1"); md.update(bytes); return md.digest().joinToString("") { "%02x".format(it) }
    }
}
