package com.flintclient.core.skin

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

class SkinManager(private val storage: StorageManager) {
    private val client = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    suspend fun downloadSkin(uuid: String): File? = withContext(Dispatchers.IO) {
        try {
            // Via session server / profile API - requires auth token in real flow, this is public skin URL pattern
            val req = Request.Builder().url("https://sessionserver.mojang.com/session/minecraft/profile/$uuid").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val json = org.json.JSONObject(resp.body!!.string())
                val props = json.getJSONArray("properties")
                for (i in 0 until props.length()) {
                    val p = props.getJSONObject(i)
                    if (p.getString("name") == "textures") {
                        val decoded = String(android.util.Base64.decode(p.getString("value"), android.util.Base64.DEFAULT))
                        val tex = org.json.JSONObject(decoded).getJSONObject("textures")
                        val skinUrl = tex.getJSONObject("SKIN").getString("url")
                        val dest = File(storage.skinsDir, "$uuid.png")
                        val req2 = Request.Builder().url(skinUrl).build()
                        client.newCall(req2).execute().use { r2 ->
                            if (!r2.isSuccessful) return@withContext null
                            dest.writeBytes(r2.body!!.bytes())
                            FlintLogger.i("Skin", "Downloaded skin $uuid")
                            return@withContext dest
                        }
                    }
                }
                null
            }
        } catch (e: Exception) { FlintLogger.e("Skin", "Download failed", e); null }
    }
    fun listSkins(): List<File> = storage.skinsDir.listFiles()?.toList() ?: emptyList()
}
