package com.flintclient.core.crash

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class CrashReport(val file: File, val timestamp: Long, val reason: String, val stacktrace: String)

class CrashReporter(private val storage: StorageManager) {
    fun saveCrash(instanceId: String, reason: String, stacktrace: String): File {
        val dir = storage.instanceCrashDir(instanceId)
        val date = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val file = File(dir, "crash-$date.txt")
        val content = StringBuilder()
        content.appendLine("---- FLINT CLIENT Crash Report ----")
        content.appendLine("Time: $date")
        content.appendLine("Instance: $instanceId")
        content.appendLine("Reason: $reason")
        content.appendLine()
        content.appendLine("Stacktrace:")
        content.appendLine(stacktrace)
        content.appendLine()
        content.appendLine("-- System Details --")
        content.appendLine("OS: Android ${android.os.Build.VERSION.RELEASE} SDK ${android.os.Build.VERSION.SDK_INT}")
        content.appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} ${android.os.Build.DEVICE}")
        content.appendLine("ABI: ${android.os.Build.SUPPORTED_ABIS.joinToString(",")}")
        file.writeText(content.toString())
        FlintLogger.e("CrashReporter", "Saved crash $file")
        return file
    }
    fun listCrashes(instanceId: String): List<CrashReport> {
        val dir = storage.instanceCrashDir(instanceId)
        return dir.listFiles()?.map { CrashReport(it, it.lastModified(), "Crash", it.readText().take(500)) }?.sortedByDescending { it.timestamp } ?: emptyList()
    }
    fun parseLatestLogForCrash(logText: String): String? {
        if (logText.contains("Exception") || logText.contains("Caused by") || logText.contains("crash")) return logText
        return null
    }
}
