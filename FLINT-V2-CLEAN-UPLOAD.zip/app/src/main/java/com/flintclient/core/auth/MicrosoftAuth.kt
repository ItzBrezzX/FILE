package com.flintclient.core.auth

import com.flintclient.core.logging.FlintLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object MicrosoftAuth {
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    suspend fun exchangeCodeForToken(code: String, clientId: String, redirectUri: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val body = FormBody.Builder().add("client_id", clientId).add("code", code).add("grant_type", "authorization_code").add("redirect_uri", redirectUri).build()
            val req = Request.Builder().url("https://login.live.com/oauth20_token.srf").post(body).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) { FlintLogger.e("MSAuth", "Token exchange HTTP ${resp.code}"); return@withContext null }
                JSONObject(resp.body!!.string())
            }
        } catch (e: Exception) { FlintLogger.e("MSAuth", "Exchange failed", e); null }
    }
    suspend fun xboxLiveAuth(msAccessToken: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("Properties", JSONObject().put("AuthMethod", "RPS").put("SiteName", "user.auth.xboxlive.com").put("RpsTicket", "d=$msAccessToken")).put("RelyingParty", "http://auth.xboxlive.com").put("TokenType", "JWT")
            val req = Request.Builder().url("https://user.auth.xboxlive.com/user/authenticate").post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), payload.toString())).addHeader("Content-Type", "application/json").addHeader("Accept", "application/json").build()
            client.newCall(req).execute().use { resp -> if (!resp.isSuccessful) return@withContext null; JSONObject(resp.body!!.string()) }
        } catch (e: Exception) { FlintLogger.e("MSAuth", "XBL failed", e); null }
    }
    suspend fun xstsAuth(xblToken: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("Properties", JSONObject().put("SandboxId", "RETAIL").put("UserTokens", org.json.JSONArray().put(xblToken))).put("RelyingParty", "rp://api.minecraftservices.com/").put("TokenType", "JWT")
            val req = Request.Builder().url("https://xsts.auth.xboxlive.com/xsts/authorize").post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), payload.toString())).addHeader("Content-Type", "application/json").build()
            client.newCall(req).execute().use { resp -> if (!resp.isSuccessful) return@withContext null; JSONObject(resp.body!!.string()) }
        } catch (e: Exception) { FlintLogger.e("MSAuth", "XSTS failed", e); null }
    }
    suspend fun minecraftLogin(xstsToken: String, xstsUhs: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().put("identityToken", "XBL3.0 x=$xstsUhs;$xstsToken")
            val req = Request.Builder().url("https://api.minecraftservices.com/authentication/login_with_xbox").post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), payload.toString())).addHeader("Content-Type", "application/json").build()
            client.newCall(req).execute().use { resp -> if (!resp.isSuccessful) return@withContext null; JSONObject(resp.body!!.string()) }
        } catch (e: Exception) { FlintLogger.e("MSAuth", "MC login failed", e); null }
    }
    suspend fun getProfile(mcAccessToken: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("https://api.minecraftservices.com/minecraft/profile").addHeader("Authorization", "Bearer $mcAccessToken").build()
            client.newCall(req).execute().use { resp -> if (!resp.isSuccessful) return@withContext null; JSONObject(resp.body!!.string()) }
        } catch (e: Exception) { FlintLogger.e("MSAuth", "Profile failed", e); null }
    }

    suspend fun refreshAccessToken(refreshToken: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val clientId = "00000000402b5328"
        val body = FormBody.Builder().add("client_id", clientId).add("refresh_token", refreshToken).add("grant_type", "refresh_token").add("scope", "XboxLive.signin offline_access").build()
        val req = Request.Builder().url("https://login.live.com/oauth20_token.srf").post(body).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("Refresh HTTP ${resp.code}")
            val json = JSONObject(resp.body!!.string())
            val at = json.optString("access_token"); val rt = json.optString("refresh_token")
            if (at.isBlank()) throw Exception("Refresh returned empty access_token")
            Pair(at, if (rt.isBlank()) refreshToken else rt)
        }
    }
}
