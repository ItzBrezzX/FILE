package com.flintclient.core.storage

import java.io.File

object FileManager {
    fun copyFile(src: File, dest: File): Boolean = try { src.copyTo(dest, overwrite = true); true } catch (e: Exception) { false }
    fun deleteRecursively(file: File): Boolean = try { file.deleteRecursively(); true } catch (e: Exception) { false }
    fun ensureDir(file: File): File { file.mkdirs(); return file }
    fun listFilesRecursive(dir: File): List<File> = dir.walkTopDown().filter { it.isFile }.toList()
    fun humanSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB","MB","GB","TB")
        var size = bytes.toDouble()
        var idx = -1
        while (size >= 1024 && idx < units.size - 1) { size /= 1024; idx++ }
        return String.format("%.1f %s", size, units[idx])
    }
}
