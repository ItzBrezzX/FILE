package com.flintclient.core.version

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import java.io.File

object LibraryResolver {
    fun isAllowed(rule: Rule): Boolean {
        if (rule.os?.name != null) {
            // Mojang rules: os.name = windows / osx / linux . On Android we treat as linux.
            if (rule.os.name == "windows" || rule.os.name == "osx") return false
            if (rule.os.name == "linux") return true
        }
        return true
    }
    fun isLibraryAllowed(lib: Library): Boolean {
        val rules = lib.rules ?: return true
        var allowed = false
        for (rule in rules) {
            val applies = isAllowed(rule)
            if (rule.action == "allow" && applies) allowed = true
            if (rule.action == "disallow" && applies) allowed = false
        }
        return allowed
    }
    fun libraryFile(storage: StorageManager, lib: Library): File? {
        val artifact = lib.downloads?.artifact ?: return null
        return File(storage.librariesDir, artifact.path)
    }
    fun buildClasspath(storage: StorageManager, version: VersionJson, versionId: String, extraJars: List<File> = emptyList()): String {
        val parts = mutableListOf<String>()
        for (lib in version.libraries) {
            if (!isLibraryAllowed(lib)) continue
            val f = libraryFile(storage, lib) ?: continue
            if (f.exists()) parts.add(f.absolutePath)
        }
        val clientJar = File(storage.versionDir(versionId), "$versionId.jar")
        parts.add(clientJar.absolutePath)
        extraJars.forEach { parts.add(it.absolutePath) }
        // Flint replaces LWJGL with our Android build - handled by NativeLibraryManager: ensure our lwjgl jars are first if present
        return parts.joinToString(":")
    }
    fun nativeClassifier(lib: Library): String? {
        val natives = lib.natives ?: return null
        // Android uses linux-arm64 classifier mapping
        return natives["linux"] ?: natives["linux-arm64"] ?: natives["natives-linux"]
    }
    fun getNativeArtifact(lib: Library): Artifact? {
        val classifier = nativeClassifier(lib) ?: return null
        return lib.downloads?.classifiers?.get(classifier)
    }
}
