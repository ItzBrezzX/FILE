package com.flintclient.core.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.flintclient.native.FlintInput
import com.flintclient.core.controls.GlfwKeyMapper

// TouchControlsOverlay - REAL View, not just data class.
// Draws joystick + buttons, forwards touch to FlintInput -> GLFW queue -> Minecraft.
// Layout: left joystick (WASD), right side: JUMP, SNEAK, ATK, USE, E, CHAT
class TouchControlsOverlay(context: Context) : View(context) {
    var onInput: ((String, Float, Float, Int, Int) -> Unit)? = null
    private val paint = Paint().apply { color = Color.argb(120, 255, 255, 255); style = Paint.Style.FILL }
    private val textPaint = Paint().apply { color = Color.WHITE; textSize = 28f; textAlign = Paint.Align.CENTER }
    private var joystickX = 0.15f
    private var joystickY = 0.75f
    private var joystickDX = 0f
    private var joystickDY = 0f
    private var joystickActive = false

    fun forwardToNative(type: String, x: Float, y: Float, button: Int, action: Int) {
        try {
            when (type) {
                "mouse" -> FlintInput.nativeSendMouse(x, y, button, action)
                "key" -> FlintInput.nativeSendKey(if (button in 65..301 || button == 32) button else GlfwKeyMapper.androidToGlfw(button), action)
                "touch" -> FlintInput.nativeSendTouch(x, y, action)
            }
        } catch (e: Exception) { android.util.Log.e("FLINT-TOUCH", "forward failed: ${e.message}") }
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        // Joystick base
        canvas.drawCircle(w*joystickX, h*joystickY, 110f, paint)
        canvas.drawCircle(w*joystickX + joystickDX*50, h*joystickY + joystickDY*50, 50f, paint)
        // Buttons
        drawButton(canvas, w*0.85f, h*0.65f, 70f, "JUMP")
        drawButton(canvas, w*0.85f, h*0.82f, 60f, "SNEAK")
        drawButton(canvas, w*0.70f, h*0.65f, 75f, "ATK")
        drawButton(canvas, w*0.70f, h*0.82f, 75f, "USE")
        drawButton(canvas, w*0.08f, h*0.08f, 45f, "E")
    }
    private fun drawButton(canvas: Canvas, x: Float, y: Float, r: Float, label: String) {
        canvas.drawCircle(x, y, r, paint)
        canvas.drawText(label, x, y+10, textPaint)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x / width.toFloat()
        val y = event.y / height.toFloat()
        val action = when (event.action) { MotionEvent.ACTION_DOWN -> 1; MotionEvent.ACTION_UP -> 0; MotionEvent.ACTION_MOVE -> 2; else -> 2 }
        // Joystick zone: left 30% bottom
        if (x < 0.35f && y > 0.55f) {
            joystickActive = event.action != MotionEvent.ACTION_UP
            joystickDX = ((x - joystickX) * 3).coerceIn(-1f, 1f)
            joystickDY = ((y - joystickY) * 3).coerceIn(-1f, 1f)
            // Convert joystick to WASD keys: forward = W (51), back = S (47), left = A (29), right = D (32) - Android keycodes, mapped in native to GLFW
            val forward = joystickDY < -0.3f
            val back = joystickDY > 0.3f
            val left = joystickDX < -0.3f
            val right = joystickDX > 0.3f
            forwardToNative("key", 0f, 0f, GlfwKeyMapper.wasdGlfw("forward"), if (forward) 1 else 0)
            forwardToNative("key", 0f, 0f, GlfwKeyMapper.wasdGlfw("back"), if (back) 1 else 0)
            forwardToNative("key", 0f, 0f, GlfwKeyMapper.wasdGlfw("left"), if (left) 1 else 0)
            forwardToNative("key", 0f, 0f, GlfwKeyMapper.wasdGlfw("right"), if (right) 1 else 0)
            invalidate()
            return true
        }
        // Buttons: JUMP zone
        if (x > 0.78f && x < 0.92f && y > 0.58f && y < 0.72f) { forwardToNative("key", 0f, 0f, GlfwKeyMapper.wasdGlfw("jump"), action); return true }
        if (x > 0.78f && x < 0.92f && y > 0.75f && y < 0.89f) { forwardToNative("key", 0f, 0f, GlfwKeyMapper.wasdGlfw("sneak"), action); return true }
        // ATK / USE = mouse buttons
        if (x > 0.63f && x < 0.77f && y > 0.58f && y < 0.72f) { forwardToNative("mouse", x, y, 0, action); return true }
        if (x > 0.63f && x < 0.77f && y > 0.75f && y < 0.89f) { forwardToNative("mouse", x, y, 1, action); return true }
        // Else: camera drag = mouse move
        forwardToNative("mouse", x*width, y*height, -1, action)
        return true
    }
}
