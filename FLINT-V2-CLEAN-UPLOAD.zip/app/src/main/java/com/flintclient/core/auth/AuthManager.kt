package com.flintclient.core.auth

import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.io.File
import java.util.UUID

data class MinecraftAccount(
    val id: String = UUID.randomUUID().toString(),
    val username: String,
    val uuid: String,
    val accessToken: String,
    val refreshToken: String = "",
    val type: String = "microsoft",
    val expiresAt: Long = 0L,
    val skinUrl: String = "",
    val capeUrl: String = ""
) {
    fun isExpired(): Boolean = System.currentTimeMillis() > expiresAt && expiresAt != 0L
    fun isOffline(): Boolean = type == "offline"
}

class AuthManager(private val storage: StorageManager) {
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val file = File(storage.accountsDir, "accounts.json")
    var accounts: MutableList<MinecraftAccount> = mutableListOf()
        private set
    var selectedAccount: MinecraftAccount? = null
    init { load() }
    fun load() {
        if (file.exists()) {
            try {
                val arr = gson.fromJson(file.readText(), Array<MinecraftAccount>::class.java)
                accounts = arr?.toMutableList() ?: mutableListOf()
            } catch (e: Exception) { accounts = mutableListOf() }
        }
    }
    fun save() { file.writeText(gson.toJson(accounts)) }
    fun addOfflineAccount(username: String): MinecraftAccount {
        // Offline mode only for local testing / LAN. Online servers require Microsoft account.
        val uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).toByteArray()).toString().replace("-", "")
        val acc = MinecraftAccount(username = username, uuid = uuid, accessToken = "offline", type = "offline", expiresAt = 0L)
        accounts.add(acc); save(); selectedAccount = acc; return acc
    }
    fun addMicrosoftAccount(username: String, uuid: String, accessToken: String, refreshToken: String, expiresInSec: Long): MinecraftAccount {
        val acc = MinecraftAccount(username = username, uuid = uuid, accessToken = accessToken, refreshToken = refreshToken, type = "microsoft", expiresAt = System.currentTimeMillis() + expiresInSec * 1000)
        accounts.removeAll { it.uuid == uuid }
        accounts.add(acc); save(); selectedAccount = acc; return acc
    }
    fun removeAccount(id: String) { accounts.removeAll { it.id == id }; if (selectedAccount?.id == id) selectedAccount = accounts.firstOrNull(); save() }
    fun selectAccount(id: String) { selectedAccount = accounts.firstOrNull { it.id == id }; save() }
    fun getActiveToken(): String = selectedAccount?.accessToken ?: "offline"
    fun getActiveUuid(): String = selectedAccount?.uuid ?: UUID.randomUUID().toString().replace("-", "")
    fun getActiveUsername(): String = selectedAccount?.username ?: "Steve"
    // Microsoft OAuth flow is implemented via Custom Tab to login.live.com - token exchange handled in MicrosoftAuth
    fun getMicrosoftAuthUrl(clientId: String, redirectUri: String): String {
        return "https://login.live.com/oauth20_authorize.srf?client_id=$clientId&response_type=code&redirect_uri=$redirectUri&scope=XboxLive.signin%20offline_access&prompt=select_account"
    }
}


// Compatibility layer for LaunchManager (Phase 6) - wraps MinecraftAccount as session, NEVER bypasses auth.
data class FlintSession(val username: String, val uuid: String, val accessToken: String, val expiresAt: Long)
fun AuthManager.getActiveSession(): FlintSession? {
    val acc = selectedAccount ?: accounts.firstOrNull() ?: return null
    if (acc.type == "offline") return FlintSession(acc.username, acc.uuid, "offline", 0L)
    return FlintSession(acc.username, acc.uuid, acc.accessToken, acc.expiresAt)
}
fun AuthManager.isSessionExpired(session: FlintSession): Boolean {
    if (session.accessToken == "offline") return false
    return session.expiresAt != 0L && System.currentTimeMillis() > session.expiresAt
}
fun AuthManager.refreshSession(session: FlintSession): FlintSession? {
    // Real refresh needs MicrosoftAuth.refreshToken() with refreshToken from stored account.
    // If refreshToken missing/expired, return null -> LaunchManager will ask user to login again. Never fabricate a token.
    val acc = accounts.firstOrNull { it.uuid == session.uuid } ?: return null
    if (acc.refreshToken.isBlank()) return null
    return try {
        val newTokens = com.flintclient.core.auth.MicrosoftAuth.refreshAccessToken(acc.refreshToken)
        val updated = acc.copy(accessToken = newTokens.first, refreshToken = newTokens.second, expiresAt = System.currentTimeMillis() + 3600_000)
        accounts.removeAll { it.uuid == acc.uuid }; accounts.add(updated); save(); selectedAccount = updated
        FlintSession(updated.username, updated.uuid, updated.accessToken, updated.expiresAt)
    } catch (e: Exception) { null }
}
