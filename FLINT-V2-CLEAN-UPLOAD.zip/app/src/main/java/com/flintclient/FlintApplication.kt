package com.flintclient

import android.app.Application
import com.flintclient.core.config.ConfigManager
import com.flintclient.core.logging.FlintLogger
import com.flintclient.core.storage.StorageManager

class FlintApplication : Application() {
    companion object {
        lateinit var instance: FlintApplication
            private set
    }
    lateinit var storage: StorageManager
    lateinit var config: ConfigManager
    override fun onCreate() {
        super.onCreate()
        instance = this
        storage = StorageManager(this)
        storage.initialize()
        config = ConfigManager(this, storage)
        FlintLogger.init(storage.logsDir)
        FlintLogger.i("FlintApplication", "FLINT CLIENT started v1.0.0-flint")
    }
}
