package com.flintclient.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable fun FlintBottomNav(currentRoute: String, onNavigate: (String) -> Unit) {
    val items = listOf("home" to "🏠 Home", "play" to "▶ Play", "versions" to "📦 Versions", "mods" to "🧩 Mods", "servers" to "🌐 Servers", "settings" to "⚙ Settings")
    Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF111827)).padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        items.forEach { (route, label) ->
            Text(text = label, color = if (route == currentRoute) Color(0xFF4ADE80) else Color.White, fontSize = 12.sp, modifier = Modifier.clickable { onNavigate(route) }.padding(8.dp))
        }
    }
}
