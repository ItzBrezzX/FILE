package com.flintclient.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val FlintDark = darkColorScheme(
    primary = Color(0xFF4ADE80),
    secondary = Color(0xFF22D3EE),
    background = Color(0xFF0B0F14),
    surface = Color(0xFF111827),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)
@Composable fun FlintTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = FlintDark, content = content) }
