package com.flintclient.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flintclient.FlintApplication
import com.flintclient.core.instance.GameInstanceManager
import com.flintclient.core.version.VersionManager

@Composable fun HomeScreen(app: FlintApplication, onNavigate: (String) -> Unit, onPlay: () -> Unit) {
    val config = app.config.config
    val instanceManager = remember { GameInstanceManager(app.storage) }
    val instances = remember { instanceManager.listInstances() }
    val versionManager = remember { VersionManager(app.storage) }
    val installed = remember { versionManager.listInstalledVersions() }
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F14)).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("FLINT CLIENT", color = Color(0xFF4ADE80), fontSize = 28.sp)
        Text("Minecraft Java Edition di Android • Legal • Open Source", color = Color.Gray, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Dashboard", color = Color.White, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Version: ${config.selectedVersionId}", color = Color.White)
                Text("Java: ${config.selectedJavaId} • RAM: ${config.ramMb} MB", color = Color.White)
                Text("Renderer: ${config.renderer.uppercase()} • FOV: ${config.fov} • Render Distance: ${config.renderDistance}", color = Color.White)
                Text("Installed Versions: ${installed.joinToString(", ").ifEmpty { "Belum ada" }}", color = Color.White)
                Text("Instances: ${instances.size}", color = Color.White)
                Text("Storage: ${String.format("%.1f", app.storage.totalSize() / 1024.0 / 1024.0)} MB", color = Color.White)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4ADE80))) { Text("▶ PLAY MINECRAFT", color = Color.Black) }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onNavigate("versions") }) { Text("Versions") }
            Button(onClick = { onNavigate("mods") }) { Text("Mods") }
            Button(onClick = { onNavigate("servers") }) { Text("Servers") }
            Button(onClick = { onNavigate("settings") }) { Text("Settings") }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text("HUD Aktif: FPS=${config.showFps} CPS=${config.showCps} Coords=${config.showCoords} Keystrokes=${config.showKeystrokes}", color = Color.Gray, fontSize = 12.sp)
        Text("Fullbright: ${config.fullbright} • Zoom: ${config.zoomEnabled} • Shaders: ${config.enableShaders}", color = Color.Gray, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Catatan: Login pakai akun Microsoft yang punya lisensi Minecraft Java. FLINT tidak menyertakan game / aset Mojang.", color = Color(0xFFF59E0B), fontSize = 11.sp)
    }
}
