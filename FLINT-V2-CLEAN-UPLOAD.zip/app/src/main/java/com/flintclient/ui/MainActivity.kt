package com.flintclient.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.flintclient.FlintApplication
import com.flintclient.ui.screens.*
import com.flintclient.ui.theme.FlintTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as FlintApplication
        setContent {
            FlintTheme {
                Surface(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F14)), color = Color(0xFF0B0F14)) {
                    val nav = rememberNavController()
                    var currentRoute by remember { mutableStateOf("home") }
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.weight(1f)) {
                            NavHost(navController = nav, startDestination = "home") {
                                composable("home") { HomeScreen(app = app, onNavigate = { nav.navigate(it) }, onPlay = { startGame() }) }
                                composable("play") { PlayScreen(app = app, onPlay = { startGame() }) }
                                composable("versions") { VersionScreen(app = app) }
                                composable("accounts") { AccountScreen(app = app) }
                                composable("servers") { ServerScreen(app = app) }
                                composable("mods") { ModScreen(app = app) }
                                composable("resourcepacks") { ResourcePackScreen(app = app) }
                                composable("shaders") { ShaderScreen(app = app) }
                                composable("skins") { SkinScreen(app = app) }
                                composable("settings") { SettingsScreen(app = app) }
                                composable("performance") { PerformanceScreen(app = app) }
                                composable("controls") { ControlsScreen(app = app) }
                                composable("about") { AboutScreen() }
                            }
                        }
                        FlintBottomNav(currentRoute = currentRoute, onNavigate = { route -> currentRoute = route; nav.navigate(route) { popUpTo("home") { saveState = true }; launchSingleTop = true } })
                    }
                }
            }
        }
    }
    private fun startGame() {
        val intent = Intent(this, GameActivity::class.java)
        startActivity(intent)
    }
}
