package com.flintclient.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flintclient.FlintApplication
import com.flintclient.core.instance.GameInstanceManager
import com.flintclient.core.launch.LaunchState
import com.flintclient.core.assets.AssetManager
import com.flintclient.core.auth.AuthManager
import com.flintclient.core.java.JavaRuntimeManager
import com.flintclient.core.launch.LaunchManager
import com.flintclient.core.natives.NativeLibraryManager
import com.flintclient.core.version.VersionManager
import kotlinx.coroutines.launch

@Composable fun PlayScreen(app: FlintApplication, onPlay: () -> Unit) {
    var status by remember { mutableStateOf("Siap") }
    var progress by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val instanceManager = remember { GameInstanceManager(app.storage) }
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F14)).padding(16.dp)) {
        Text("PLAY", color = Color.White, fontSize = 24.sp)
        Text("Instance: ${app.config.config.selectedInstanceId} • Version: ${app.config.config.selectedVersionId}", color = Color.Gray)
        Spacer(modifier = Modifier.height(16.dp))
        LinearProgressIndicator(progress = progress / 100f, modifier = Modifier.fillMaxWidth())
        Text(status, color = Color.White)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onPlay) { Text("▶ LAUNCH VIA GAME ACTIVITY (EGL)") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            scope.launch {
                val lm = LaunchManager(app, app.storage, app.config, VersionManager(app.storage), AuthManager(app.storage), instanceManager, JavaRuntimeManager(app.storage), AssetManager(app.storage), NativeLibraryManager(app.storage))
                lm.onState = { s -> when (s) { is LaunchState.Preparing -> { status = s.step; progress = s.progress } is LaunchState.Running -> { status = "Running PID ${s.pid}"; progress = 100 } is LaunchState.Failed -> { status = "Gagal: ${s.error}" } else -> {} } }
                lm.prepareAndLaunch(app.config.config.selectedInstanceId)
            }
        }) { Text("▶ LAUNCH HEADLESS (Test JVM - butuh Surface, akan gagal tanpa GameActivity)") }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Alur Launch: Manifest → Version JSON → Client JAR → Libraries → Natives → Assets → Java Runtime → Classpath → JVM Args → Game Args → Process", color = Color.Gray, fontSize = 12.sp)
    }
}
