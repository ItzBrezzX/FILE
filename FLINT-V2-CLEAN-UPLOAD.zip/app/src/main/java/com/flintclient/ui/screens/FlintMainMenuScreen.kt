package com.flintclient.ui.screens
// FLINT Main Menu persis foto: Sidebar + Search + Filter + Banner + Cards, semua tombol hidup, optimasi Lazy + paginate
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flintclient.FlintApplication
import com.flintclient.core.performance.PerformanceOptimizer
data class FlintModCard(val name: String, val desc: String, val downloads: String, val rating: String, val category: String, val tags: List<String>)
@Composable fun FlintMainMenuScreen(app: FlintApplication, onNavigate: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("All") }
    var downloadQueue by remember { mutableStateOf(0) }
    var downloaded by remember { mutableStateOf(setOf<String>()) }
    val allMods = remember { listOf(
        FlintModCard("Sodium","A powerful performance mod.","7.5M","4.8","Mods",listOf("1.21.x","Performance")),
        FlintModCard("Iris Shaders","A modern shader mod.","5.0M","4.7","Shaders",listOf("Fabric","Shaders")),
        FlintModCard("OptiFine","Boost Your Minecraft performance.","4.9M","4.6","Mods",listOf("Forge","Performance")),
        FlintModCard("Backpack","A simple backpack mod.","3.1M","4.5","Mods",listOf("Fabric","Utility")),
        FlintModCard("Fabric API","The essential API for Fabric mods.","205.4M","4.9","Mods",listOf("Fabric","Library")),
        FlintModCard("Xaero's Minimap","A minimap for your world.","73.6M","4.5","Mods",listOf("Forge","Utility"))
    ) }
    val filtered = allMods.filter { (selectedTab=="All" || it.category==selectedTab) && (search.isBlank() || it.name.contains(search, ignoreCase=true)) }
    Row(modifier = Modifier.fillMaxSize().background(Color(0xFF0A0F0A))) {
        Column(modifier = Modifier.width(220.dp).fillMaxHeight().background(Color(0xFF0B120B)).padding(12.dp)) {
            Text("Flint-Launcher", color = Color.White, fontSize = 18.sp); Text("Play without limits", color = Color.Gray, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(20.dp))
            listOf("Home" to "home","Instances" to "instances","Mod Menu" to "modmenu","Settings" to "settings","About" to "about").forEach { (label, route) ->
                val active = route=="modmenu"
                Text(label, color = if(active) Color.White else Color.Gray, modifier = Modifier.fillMaxWidth().background(if(active) Color(0xFF4ADE80) else Color.Transparent, RoundedCornerShape(8.dp)).clickable{ onNavigate(route) }.padding(12.dp))
            }
            Spacer(modifier = Modifier.weight(1f))
            Text("Minecraft 1.21.10", color = Color.White); Text("Online - Ready to play", color = Color(0xFF4ADE80), fontSize = 12.sp)
        }
        Column(modifier = Modifier.weight(1f).padding(16.dp)) {
            OutlinedTextField(value = search, onValueChange = { search = it }, placeholder = { Text("Search mods, shaders, resource packs...") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("All","Mods","Shaders","Resource Packs","Add-Ons","Data Packs","Maps").forEach { tab -> Button(onClick = { selectedTab = tab }, colors = ButtonDefaults.buttonColors(containerColor = if(selectedTab==tab) Color(0xFF4ADE80) else Color(0xFF1A221A))) { Text(tab, color = Color.White, fontSize = 12.sp) } } }
            Spacer(modifier = Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF22C55E))) { Column(modifier = Modifier.padding(20.dp)) { Text("MINECRAFT MOD MENU", color = Color.White, fontSize = 24.sp); Text("Download the best mods, shaders and more!", color = Color.White); Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))) { Text("Explore Now") } } }
            Spacer(modifier = Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(PerformanceOptimizer.paginate(filtered, 0, 20)) { mod -> Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A221A))) { Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(modifier = Modifier.weight(1f)) { Text(mod.name, color = Color.White); Text(mod.desc, color = Color.Gray, fontSize = 12.sp); Text("${mod.downloads}  ${mod.rating}  ${mod.tags.joinToString(" • ")}", color = Color.Gray, fontSize = 11.sp) }; Button(onClick = { if(!downloaded.contains(mod.name)){ downloadQueue++; downloaded = downloaded + mod.name } }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4ADE80))) { Text(if(downloaded.contains(mod.name)) "Downloaded" else "Download", color = Color.Black) } } } } } }
            Spacer(modifier = Modifier.height(8.dp)); Text("Download Queue ($downloadQueue)", color = Color.White)
        }
    }
}
