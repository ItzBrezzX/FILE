package com.flintclient.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flintclient.FlintApplication
import com.flintclient.core.version.SnapshotManager
import com.flintclient.core.version.VersionCompatibility
import com.flintclient.core.version.VersionManager
import kotlinx.coroutines.launch

@Composable fun VersionFilterScreen(app: FlintApplication) {
    var selectedType by remember { mutableStateOf("all") }
    var versions by remember { mutableStateOf(listOf<String>()) }
    var status by remember { mutableStateOf("Pilih filter, lalu Fetch Manifest") }
    val scope = rememberCoroutineScope()
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F14)).padding(16.dp)) {
        Text("SEMUA VERSI - Release / Snapshot / Beta / Alpha", color = Color.White, fontSize = 20.sp)
        Text("FLINT mendukung semua tipe versi Mojang. Snapshot = versi percobaan mingguan, Beta = b1.x, Alpha = a1.x", color = Color.Gray, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("all" to "Semua", "release" to "Release", "snapshot" to "Snapshot", "beta" to "Beta", "alpha" to "Alpha").forEach { (type, label) ->
                Button(onClick = { selectedType = type }, colors = ButtonDefaults.buttonColors(containerColor = if (selectedType == type) Color(0xFF4ADE80) else Color(0xFF1F2937))) { Text(label, color = Color.White) }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {
            scope.launch {
                try {
                    val manifest = VersionManager(app.storage).fetchManifest()
                    val filtered = VersionCompatibility.filterByType(manifest.versions, selectedType)
                    versions = filtered.take(50).map { "${it.id} [${VersionCompatibility.getTypeLabel(it.type)}] - Java ${VersionCompatibility.getJavaForVersion(it.id)} - LWJGL ${VersionCompatibility.getLWJGLForVersion(it.id)}" }
                    status = "Ditemukan ${filtered.size} versi untuk filter $selectedType. Latest: Release ${manifest.latest.release}, Snapshot ${manifest.latest.snapshot}"
                } catch (e: Exception) { status = "Gagal: ${e.message}" }
            }
        }) { Text("Fetch Manifest Mojang") }
        Text(status, color = Color.White)
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn { items(versions) { v -> Text(v, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) } }
        Spacer(modifier = Modifier.height(12.dp))
        Text("Contoh yang bisa jalan:", color = Color(0xFF4ADE80))
        Text("• Release: 1.21.1 (Java 21), 1.20.1 (Java 17), 1.16.5 (Java 8), 1.12.2 (Java 8)", color = Color.Gray, fontSize = 12.sp)
        Text("• Snapshot: 24w14a, 25w02a (Java 21, bisa crash, backup world!)", color = Color.Gray, fontSize = 12.sp)
        Text("• Beta: b1.7.3 (paling stabil, nostalgia), b1.8.1", color = Color.Gray, fontSize = 12.sp)
        Text("• Alpha: a1.2.6 (tanpa suara, glitch, tapi jalan)", color = Color.Gray, fontSize = 12.sp)
    }
}
