package com.flintclient.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flintclient.FlintApplication
import com.flintclient.core.auth.AuthManager
import com.flintclient.core.instance.GameInstance
import com.flintclient.core.instance.GameInstanceManager
import com.flintclient.core.mods.ModManager
import com.flintclient.core.server.ServerManager
import com.flintclient.core.server.FlintServer
import com.flintclient.core.version.VersionManager
import kotlinx.coroutines.launch

@Composable fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F14)).padding(16.dp)) {
        Text(title, color = Color.White, fontSize = 22.sp)
        Spacer(modifier = Modifier.height(12.dp))
        content()
    }
}

@Composable fun VersionScreen(app: FlintApplication) {
    var versions by remember { mutableStateOf(listOf<String>()) }
    var manifest by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { versions = VersionManager(app.storage).listInstalledVersions() }
    Section("Version Manager") {
        Text("Installed: ${versions.joinToString(", ").ifEmpty { "Belum ada" }}", color = Color.White)
        Button(onClick = { scope.launch { try { val m = VersionManager(app.storage).fetchManifest(); manifest = "Latest Release: ${m.latest.release} • Snapshot: ${m.latest.snapshot} • Total: ${m.versions.size}"; versions = VersionManager(app.storage).listInstalledVersions() } catch (e: Exception) { manifest = "Gagal fetch manifest: ${e.message}" } } }) { Text("Fetch Mojang Manifest") }
        Text(manifest, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Dukung: Vanilla, Fabric, Forge, NeoForge, Quilt via inheritsFrom + loader JSON", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable fun AccountScreen(app: FlintApplication) {
    var username by remember { mutableStateOf("") }
    var accounts by remember { mutableStateOf(AuthManager(app.storage).accounts) }
    val auth = remember { AuthManager(app.storage) }
    Section("Account Manager") {
        Text("Akun: ${accounts.joinToString { it.username + " (" + it.type + ")" }.ifEmpty { "Belum ada" }}", color = Color.White)
        OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Username Offline (testing)") })
        Button(onClick = { if (username.isNotBlank()) { auth.addOfflineAccount(username); accounts = auth.accounts } }) { Text("Tambah Akun Offline") }
        Text("Untuk server online: Login Microsoft OAuth -> Xbox Live -> XSTS -> Minecraft Services. Lihat MicrosoftAuth.kt", color = Color.Gray, fontSize = 12.sp)
        Button(onClick = { auth.accounts.firstOrNull()?.let { auth.removeAccount(it.id); accounts = auth.accounts } }) { Text("Hapus Akun Pertama") }
    }
}

@Composable fun ServerScreen(app: FlintApplication) {
    var servers by remember { mutableStateOf(ServerManager(app.storage).listServers()) }
    var name by remember { mutableStateOf("") }
    var addr by remember { mutableStateOf("") }
    Section("Server List") {
        LazyColumn { items(servers) { s -> Text("${s.name} - ${s.address}:${s.port}", color = Color.White) } }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Server") })
        OutlinedTextField(value = addr, onValueChange = { addr = it }, label = { Text("Address (mc.hypixel.net)") })
        Button(onClick = { if (name.isNotBlank() && addr.isNotBlank()) { ServerManager(app.storage).addServer(FlintServer(name, addr)); servers = ServerManager(app.storage).listServers() } }) { Text("Add Server") }
    }
}

@Composable fun ModScreen(app: FlintApplication) {
    val modManager = remember { ModManager(app.storage) }
    var mods by remember { mutableStateOf(modManager.listMods(app.config.config.selectedInstanceId)) }
    Section("Mod Manager") {
        Text("Mods di instance ${app.config.config.selectedInstanceId}: ${mods.size}", color = Color.White)
        LazyColumn { items(mods) { m -> Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("${m.name} v${m.version} [${m.loader}]", color = Color.White); Button(onClick = { modManager.setModEnabled(app.config.config.selectedInstanceId, m.fileName, !m.enabled); mods = modManager.listMods(app.config.config.selectedInstanceId) }) { Text(if (m.enabled) "Disable" else "Enable") } } } }
        Text("Mod Loader: Fabric / Forge / NeoForge / Quilt. Mod di-validasi via fabric.mod.json / mods.toml", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable fun ResourcePackScreen(app: FlintApplication) {
    Section("Resource Packs") { Text("Folder: instances/${app.config.config.selectedInstanceId}/resourcepacks", color = Color.White); Text("Letakkan .zip resource pack di folder tersebut. Minecraft akan memuat otomatis.", color = Color.Gray) }
}
@Composable fun ShaderScreen(app: FlintApplication) {
    Section("Shader Packs") { Text("Folder: instances/${app.config.config.selectedInstanceId}/shaderpacks", color = Color.White); Text("Shaders membutuhkan Iris / OptiFine. Aktifkan di Settings > Enable Shaders.", color = Color.Gray) }
}
@Composable fun SkinScreen(app: FlintApplication) {
    Section("Skin Manager") { Text("Skin diambil dari Minecraft Profile API setelah login Microsoft.", color = Color.White); Text("Upload skin via minecraft.net, lalu restart game.", color = Color.Gray) }
}
@Composable fun SettingsScreen(app: FlintApplication) {
    var ram by remember { mutableStateOf(app.config.config.ramMb) }
    var fov by remember { mutableStateOf(app.config.config.fov) }
    var rd by remember { mutableStateOf(app.config.config.renderDistance) }
    var fullbright by remember { mutableStateOf(app.config.config.fullbright) }
    Section("Settings") {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
            Text("RAM: $ram MB", color = Color.White); Slider(value = ram.toFloat(), onValueChange = { ram = it.toInt() }, valueRange = 512f..8192f)
            Text("FOV: $fov", color = Color.White); Slider(value = fov.toFloat(), onValueChange = { fov = it.toInt() }, valueRange = 60f..110f)
            Text("Render Distance: $rd", color = Color.White); Slider(value = rd.toFloat(), onValueChange = { rd = it.toInt() }, valueRange = 2f..16f)
            Row { Checkbox(checked = fullbright, onCheckedChange = { fullbright = it }); Text("Fullbright", color = Color.White) }
            Button(onClick = { app.config.update { it.ramMb = ram; it.fov = fov; it.renderDistance = rd; it.fullbright = fullbright } }) { Text("Simpan Settings") }
            Text("Semua settings disimpan ke configs/flint-config.json dan diterapkan ke JVM + Game Args saat launch.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
@Composable fun PerformanceScreen(app: FlintApplication) {
    Section("Performance") { Text("FPS Counter, Memory, Ping, CPS - di-render via HUD Overlay saat game berjalan.", color = Color.White); Text("Renderer: ${app.config.config.renderer} • JVM Args: ${app.config.config.jvmArgs}", color = Color.Gray, fontSize = 12.sp) }
}
@Composable fun ControlsScreen(app: FlintApplication) {
    Section("Controls") { Text("Touchscreen: Joystick virtual + tombol Aksi", color = Color.White); Text("Keyboard + Mouse: via FlintInput JNI -> GLFW", color = Color.White); Text("Sensitivity: ${app.config.config.sensitivity} • GUI Scale: ${app.config.config.guiScale}", color = Color.White) }
}
@Composable fun AboutScreen() {
    Section("About FLINT CLIENT") { Text("FLINT CLIENT v1.0.0-flint", color = Color(0xFF4ADE80), fontSize = 20.sp); Text("Launcher Minecraft Java Edition untuk Android. Open source, legal, tidak menyertakan game / aset Mojang. Kamu harus punya lisensi Minecraft Java dan login Microsoft.", color = Color.White); Text("Arsitektur: Version Manifest (Mojang) + Download Engine + Library Resolver + Asset Manager + Native EGL/GLFW + JVM Process Manager", color = Color.Gray, fontSize = 12.sp) }
}
