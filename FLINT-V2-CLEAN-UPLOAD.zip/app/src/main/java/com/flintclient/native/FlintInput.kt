package com.flintclient.native
object FlintInput {
    init { try { System.loadLibrary("flint_input") } catch (e: Throwable) { android.util.Log.e("FLINT-INPUT", "load flint_input failed: ${e.message}") } }
    @JvmStatic external fun nativeSendMouse(x: Float, y: Float, button: Int, action: Int)
    @JvmStatic external fun nativeSendKey(keyCode: Int, action: Int)
    @JvmStatic external fun nativeSendScroll(dx: Float, dy: Float)
    @JvmStatic external fun nativeSendTouch(x: Float, y: Float, action: Int)
    @JvmStatic external fun nativeSendChar(charCode: Int)
    @JvmStatic external fun nativeSendMousePos(x: Float, y: Float)
}
