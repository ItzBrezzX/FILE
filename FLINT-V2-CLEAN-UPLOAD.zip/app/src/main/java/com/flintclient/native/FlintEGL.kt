package com.flintclient.native
import android.view.Surface
object FlintEGL {
    init { try { System.loadLibrary("flint_egl") } catch (e: Throwable) { android.util.Log.e("FLINT-EGL", "load flint_egl failed: " + (e.message ?: "")) } }
    // @JvmStatic WAJIB: C++ memakai jclass (static). Tanpa ini, Kotlin object method = jobject (instance) -> JNI signature mismatch.
    @JvmStatic external fun nativeInitEGL(surface: Surface): Boolean
    @JvmStatic external fun nativeSwapBuffers()
    @JvmStatic external fun nativeDestroyEGL()
    @JvmStatic external fun nativeResize(w: Int, h: Int)
    @JvmStatic external fun nativePause()
    @JvmStatic external fun nativeResume()
    @JvmStatic external fun nativeGetWidth(): Int
    @JvmStatic external fun nativeGetHeight(): Int
    @JvmStatic external fun nativeIsReady(): Boolean
}
