package com.flintclient.native
object FlintGLFW {
    init { try { System.loadLibrary("flint_glfw") } catch (e: Throwable) { android.util.Log.e("FLINT-GLFW", "load flint_glfw failed: ${e.message}") } }
    @JvmStatic external fun nativeGetTime(): Double
    @JvmStatic external fun nativeInit(): Boolean
    @JvmStatic external fun nativePollEvents()
    @JvmStatic external fun nativeTerminate()
    @JvmStatic external fun nativeGetPendingEventCount(): Int
    @JvmStatic external fun nativeSetWindowSize(w: Int, h: Int)
    @JvmStatic external fun nativeShouldClose(): Boolean
    @JvmStatic external fun nativeSetShouldClose(v: Boolean)
    @JvmStatic external fun nativeGetWidth(): Int
    @JvmStatic external fun nativeGetHeight(): Int
}
