package com.flintclient.native
object FlintGL {
    init { try { System.loadLibrary("flint_gl") } catch (e: Throwable) { android.util.Log.e("FLINT-GL", "load flint_gl failed: ${e.message}") } }
    @JvmStatic external fun nativeGetGLVersion(): String
    @JvmStatic external fun nativeSetFullbright(enabled: Boolean)
    @JvmStatic external fun nativeIsFullbright(): Boolean
}
