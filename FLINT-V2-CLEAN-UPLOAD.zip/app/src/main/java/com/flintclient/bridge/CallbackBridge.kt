package com.flintclient.bridge

import com.flintclient.core.logging.FlintLogger
import java.util.ArrayDeque

// FIX 3 - CallbackBridge (Pojav pattern, terbukti jalan)
// Alur BENAR:
//   Touch / Keyboard Android -> TouchControlsOverlay -> FlintInput.nativeSend* (JNI)
//   -> flint_input.cpp -> flint_glfw.cpp -> CallbackBridge.push* (via JNI CallStaticVoidMethod)
//   -> LWJGL Android (org.lwjgl.glfw.GLFW) poll -> CallbackBridge.pollEvents()
//   -> invoke ke callback yang didaftarin Minecraft via glfwSetKeyCallback / glfwSetMouseButtonCallback dll.
// SEBELUMNYA SALAH: flint_glfw.cpp nge-drain queue lalu BUANG event (drained++ tapi tidak di-forward).
//   Hasilnya: Minecraft tidak pernah terima input, karakter tidak jalan, mouse tidak gerak.
// SEKARANG: event TIDAK dibuang, disimpan di queue, lalu di-deliver ke LWJGL callback.
data class FlintEvent(val type: Int, val key: Int, val button: Int, val action: Int, val x: Float, val y: Float, val dx: Float, val dy: Float, val charCode: Int = 0)

object CallbackBridge {
    const val TYPE_MOUSE_BUTTON = 1
    const val TYPE_KEY = 2
    const val TYPE_SCROLL = 3
    const val TYPE_MOUSE_POS = 4
    const val TYPE_CHAR = 5
    const val TYPE_TOUCH = 6

    @Volatile var windowWidth: Int = 1280
    @Volatile var windowHeight: Int = 720
    @Volatile var isGrabbing: Boolean = false
    @Volatile var isWindowReady: Boolean = false

    private val queue = ArrayDeque<FlintEvent>()
    private val lock = Any()

    // Dipanggil dari native via JNI (flint_glfw.cpp). Jangan panggil langsung dari UI thread kecuali via native.
    @JvmStatic fun pushMouseButton(x: Float, y: Float, button: Int, action: Int) {
        synchronized(lock) { if (queue.size > 512) queue.removeFirst(); queue.addLast(FlintEvent(TYPE_MOUSE_BUTTON, 0, button, action, x, y, 0f, 0f)) }
    }
    @JvmStatic fun pushMousePos(x: Float, y: Float) {
        synchronized(lock) { if (queue.size > 512) queue.removeFirst(); queue.addLast(FlintEvent(TYPE_MOUSE_POS, 0, 0, 0, x, y, 0f, 0f)) }
    }
    @JvmStatic fun pushKey(key: Int, action: Int) {
        synchronized(lock) { if (queue.size > 512) queue.removeFirst(); queue.addLast(FlintEvent(TYPE_KEY, key, 0, action, 0f, 0f, 0f, 0f)) }
    }
    @JvmStatic fun pushScroll(dx: Float, dy: Float) {
        synchronized(lock) { if (queue.size > 512) queue.removeFirst(); queue.addLast(FlintEvent(TYPE_SCROLL, 0, 0, 0, 0f, 0f, dx, dy)) }
    }
    @JvmStatic fun pushChar(charCode: Int) {
        synchronized(lock) { if (queue.size > 512) queue.removeFirst(); queue.addLast(FlintEvent(TYPE_CHAR, 0, 0, 0, 0f, 0f, 0f, 0f, charCode)) }
    }
    // Dipanggil LWJGL Android dari JVM thread (org.lwjgl.glfw.GLFW.glfwPollEvents -> CallbackBridge.pollEvents)
    // Mengembalikan list event untuk di-invoke ke callback LWJGL. TIDAK dibuang.
    @JvmStatic fun pollEvents(): List<FlintEvent> {
        synchronized(lock) {
            if (queue.isEmpty()) return emptyList()
            val out = queue.toList()
            queue.clear()
            return out
        }
    }
    @JvmStatic fun getPendingCount(): Int = synchronized(lock) { queue.size }
    @JvmStatic fun setWindowSize(w: Int, h: Int) { windowWidth = w; windowHeight = h; isWindowReady = true; FlintLogger.i("CallbackBridge", "Window " + w + "x" + h) }
    @JvmStatic fun setGrabbing(g: Boolean) { isGrabbing = g }
    fun clear() { synchronized(lock) { queue.clear() } }
}
