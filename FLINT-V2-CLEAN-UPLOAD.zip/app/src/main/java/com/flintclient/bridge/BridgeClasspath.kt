package com.flintclient.bridge
import android.content.Context
import com.flintclient.core.logging.FlintLogger
import java.io.File
// Bridge jar REAL: CallbackBridge + FlintLogger dikemas saat build (Gradle task buildBridgeJar)
// dan disalin ke assets/flint-bridge.jar. Saat first launch, disalin ke filesDir.
// LaunchManager WAJIB prepend ini ke classpath JVM baru, kalau tidak ada -> FAIL, jangan lanjut.
object BridgeClasspath {
    fun bridgeJarInAssets(): String = "flint-bridge.jar"
    fun bridgeJarFile(filesDir: File): File = File(filesDir, "flint-bridge.jar")
    fun isBridgeJarAvailable(filesDir: File): Boolean {
        val f = bridgeJarFile(filesDir)
        return f.exists() && f.length() > 1000
    }
    // Salin dari assets -> filesDir kalau belum ada / assets lebih baru. Return file kalau berhasil.
    fun ensureBridgeJar(context: Context, filesDir: File): File? {
        val dest = bridgeJarFile(filesDir)
        if (isBridgeJarAvailable(filesDir)) return dest
        return try {
            context.assets.open(bridgeJarInAssets()).use { inp ->
                dest.parentFile?.mkdirs()
                dest.outputStream().use { out -> inp.copyTo(out) }
            }
            if (isBridgeJarAvailable(filesDir)) {
                FlintLogger.i("Bridge", "flint-bridge.jar disalin dari assets: ${dest.absolutePath} (${dest.length()} bytes)")
                dest
            } else null
        } catch (e: Exception) {
            FlintLogger.e("Bridge", "flint-bridge.jar TIDAK ADA di assets: ${e.message} - jalankan ./gradlew buildBridgeJar dulu, lalu copy ke app/src/main/assets/")
            null
        }
    }
    // Prepend bridge jar ke classpath. Kalau tidak ada, return null -> caller HARUS fail.
    fun withBridgeJar(classpathFiles: List<File>, filesDir: File, context: Context? = null): List<File>? {
        val bridge = if (isBridgeJarAvailable(filesDir)) bridgeJarFile(filesDir)
            else if (context != null) ensureBridgeJar(context, filesDir) else null
        if (bridge == null) {
            FlintLogger.e("Bridge", "BRIDGE JAR MISSING - LWJGL akan ClassNotFound CallbackBridge. BLOCKED.")
            return null
        }
        // Bridge HARUS pertama, sebelum LWJGL Android, supaya CallbackBridge ke-load dari bridge jar, bukan duplikat.
        return listOf(bridge) + classpathFiles
    }
}
