plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.flintclient"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.flintclient"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.1-flint-repaired"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake { cppFlags += "-std=c++17"; arguments += listOf("-DANDROID_STL=c++_shared") }
        }
        buildFeatures { compose = true; buildConfig = true }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    buildTypes {
        release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") }
        debug { applicationIdSuffix = ".debug"; isDebuggable = true }
    }
    packaging {
        jniLibs { useLegacyPackaging = false }
        // Pojav-style: libjvm.so is loaded manually from files/java/, NOT from APK jniLibs. Exclude duplicates.
        resources { excludes += listOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*") }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.compose.ui:ui:1.7.0")
    implementation("androidx.compose.ui:ui-graphics:1.7.0")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.0")
    implementation("androidx.compose.material3:material3:1.2.1")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.tukaani:xz:1.9")
    implementation("org.apache.commons:commons-compress:1.26.1")
    implementation("org.json:json:20240303")
    // FIX: was missing - WorkManager needed by SnapshotWatcher, AppCompat needed by GameActivity (AppCompatActivity)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}

// FLINT-V2-REAL: Bridge jar untuk JVM baru (lihat BridgeClasspath.kt).
// Minecraft jalan di JVM BARU (JNI_CreateJavaVM). JVM itu TIDAK lihat class APK.
// CallbackBridge + FlintLogger (dependensi CallbackBridge) HARUS dikemas ke flint-bridge.jar.
// Task ini REAL, bukan placeholder: kumpulkan dari Kotlin class output (build/tmp/kotlin-classes/debug)
// + javac output, filter hanya bridge + FlintLogger, lalu copy ke assets.
// Jalankan: ./gradlew buildBridgeJar  ->  app/src/main/assets/flint-bridge.jar
tasks.register<Jar>("buildBridgeJar") {
    archiveFileName.set("flint-bridge.jar")
    destinationDirectory.set(layout.buildDirectory.dir("libs"))
    // Kotlin classes (AGP 8 + Kotlin 1.9): build/tmp/kotlin-classes/debug
    // Java classes: build/intermediates/javac/debug/classes
    // Ambil keduanya, filter hanya yang dibutuhkan supaya jar kecil + tidak duplikat.
    from(layout.buildDirectory.dir("tmp/kotlin-classes/debug")) {
        include("com/flintclient/bridge/**")
        include("com/flintclient/core/logging/FlintLogger*")
    }
    from(layout.buildDirectory.dir("intermediates/javac/debug/classes")) {
        include("com/flintclient/bridge/**")
        include("com/flintclient/core/logging/FlintLogger*")
    }
    // Kalau class belum ada (belum compile), task akan gagal jelas, bukan diam-diam bikin jar kosong.
    // Cek di doFirst: kalau tidak ada file bridge, fail dengan pesan jelas.
    doFirst {
        val kotlinDir = layout.buildDirectory.dir("tmp/kotlin-classes/debug").get().asFile
        val javacDir = layout.buildDirectory.dir("intermediates/javac/debug/classes").get().asFile
        val hasBridge = File(kotlinDir, "com/flintclient/bridge/CallbackBridge.class").exists() ||
            File(javacDir, "com/flintclient/bridge/CallbackBridge.class").exists()
        if (!hasBridge) {
            throw GradleException("buildBridgeJar: CallbackBridge.class tidak ditemukan. Jalankan ./gradlew compileDebugKotlin dulu.")
        }
    }
    // dependsOn compile supaya class sudah ada
    dependsOn("compileDebugKotlin")
}
tasks.register<Copy>("copyBridgeJarToAssets") {
    from(layout.buildDirectory.file("libs/flint-bridge.jar"))
    into("src/main/assets")
    dependsOn("buildBridgeJar")
    doLast { logger.lifecycle("flint-bridge.jar disalin ke app/src/main/assets/flint-bridge.jar") }
}
