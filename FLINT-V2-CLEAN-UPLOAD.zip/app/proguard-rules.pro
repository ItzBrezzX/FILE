# FLINT CLIENT Proguard
-keep class com.flintclient.** { *; }
-keep class com.google.gson.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
