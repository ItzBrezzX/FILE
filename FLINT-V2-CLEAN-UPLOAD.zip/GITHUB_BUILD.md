# FLINT CLIENT - GitHub Build (Cara Pakai)

Lo pake GitHub build, jadi gak perlu Android Studio di PC.

## 1. Push project ini ke GitHub
- Bikin repo baru di github.com (misal `FLINT-CLIENT`)
- Upload / push semua file dari ZIP ini ke repo itu (pastikan folder `.github/` ikut ke-push, jangan ke-ignore)
- Jangan lupa: file `.github/workflows/build.yml` HARUS ada di repo

## 2. Jalanin Build
- Buka repo lo di GitHub > tab **Actions**
- Pilih workflow **"FLINT CLIENT - Build APK"**
- Kalo gak jalan otomatis, klik **Run workflow** > **Run workflow**
- Tunggu 5-15 menit (pertama kali download SDK + NDK + dependencies, agak lama)

## 3. Download APK
- Kalo status hijau (checkmark), scroll ke bawah > **Artifacts** > **FLINT-CLIENT-debug-apk**
- Download ZIP-nya, extract, dapet `app-debug.apk`
- Install di HP ARM64 (Android 8+, RAM 4GB recommended)

## 4. Kalo Merah (Failed)
- Klik job yang merah > scroll log paling bawah, copy error terakhir (yang ada `FAILED` / `Execution failed`)
- Kirim log itu ke gw, gw benerin error yang persis itu. Jangan kirim screenshot doang.
- Atau download artifact `flint-build-logs` kalau ada.

## Kenapa sebelumnya gagal?
`gradlew` lama lo itu palsu (170 byte, isinya cuma `echo`). GitHub Actions yang manggil `./gradlew assembleDebug` pasti fail.
Sekarang udah gw ganti:
- `gradlew` beneran (fallback ke system gradle)
- `gradle/wrapper/gradle-wrapper.properties` -> Gradle 8.5
- Workflow pake `gradle/actions/setup-gradle@v3` + `android-actions/setup-android@v3` + NDK 25.2 + CMake 3.22.1, jadi gak butuh wrapper jar.

## Catatan Penting (jujur)
- Workflow ini nge-build APK-nya doang. Belum nge-test PLAY / Minecraft.
- Biar PLAY jalan di HP, lo masih butuh download di HP (otomatis pas first launch):
  1. Adoptium JDK 21 ARM64 (auto-download di app)
  2. MobileGLUES v1.3.3 .so + LWJGL Android build (wajib, belum di-vendor)
- Tanpa 2 itu, app bakal kebuka tapi PLAY bakal gagal dengan pesan jelas "Renderer .so missing" / "libjvm.so missing" - itu by design, bukan crash diam-diam.
