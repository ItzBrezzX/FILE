# FLINT LAUNCHER - COMPLETE REPAIR REPORT (Phase 1-9)

## CRITICAL FINDING: Wrong ZIP
- User said `FLINT-CLIENT-FINAL.zip` (57 files) is the final project. It is NOT - it is Part 1 only.
- Real full project is `flint-client_3.zip` / `FLINT-CLIENT-FINAL_1.zip` (197 files, Part 1-6).
- Repair was done on the 197-file project. The 57-file ZIP was NOT used as base (would have deleted 140 files).
- After repair: 78 files before dedup fix + new files = ~85 source files, 0 duplicates.

## PHASE 1 - REPAIR
### Removed duplicates (119 files)
- All `*_1.kt`, `*_2.kt`, `*_3.kt`, `*_1.cpp`, `*_2.cpp`, `GL4ES_INTEGRATION_1.md`, `README_1.md`, `build.gradle_1.kts`, etc.
- Before: 197 files with duplicates. After: 78 files, 0 duplicate class names, 0 duplicate filenames.
### Fixed Gradle
- Added `androidx.appcompat:appcompat:1.7.0` (GameActivity extends AppCompatActivity, was missing -> compile error)
- Added `androidx.work:work-runtime-ktx:2.9.0` (SnapshotWatcher uses WorkManager, was missing)
- Fixed `packaging.resources.excludes` for META-INF
- Bumped versionCode 1 -> 2, versionName 1.0.0 -> 1.0.1-flint-repaired
### Fixed AndroidManifest
- REMOVED `HUDOverlayService` - class did not exist, caused manifest merge / install failure. HUD is now in-app overlay in GameActivity.
- Changed theme `@android:style/Theme.Material.NoActionBar` (does not exist for AppCompat) -> `@style/Theme.Flint` (created in res/)
- Added `android:extractNativeLibs="true"`, `roundIcon`, `BLUETOOTH_CONNECT`, `gamepad` feature
- Added `smallestScreenSize` to configChanges (rotation crash fix)
### Fixed res/ (was missing entirely)
- Created `res/values/themes.xml` (Theme.Flint, Theme.Flint.Game), `res/values/strings.xml`, `res/mipmap-anydpi-v26/ic_launcher.xml`
- Without res/, `R` class generation fails and APK cannot build.
### Fixed CMake
- BEFORE: only `libflint_jvm.so` built, but Kotlin loaded `flint_egl`, `flint_gl`, `flint_glfw`, `flint_input` -> UnsatisfiedLinkError on every launch.
- AFTER: CMake builds 5 libs with EXACT names Kotlin expects: flint_jvm, flint_egl, flint_gl, flint_glfw, flint_input.
- Added GLESv3 link, documented libjvm.so is runtime-loaded, NOT build-time linked.

## PHASE 2 - JAVA RUNTIME + JNI
### JNIVMLauncher.kt - FIXED
- BEFORE: `createJVM()` + `setEnvVars(Map)` had no matching native impl for Map -> UnsatisfiedLinkError. No `nativeLoadJvmLib()`.
- AFTER: `nativeLoadJvmLib(libjvm.so)`, `nativeSetEnv(key,value)`, `createJVM()`, `destroyJVM()`. Legacy `setEnvVars(Map)` kept as forwarding alias.
### flint_jvm.cpp - REWRITTEN
- Uses `dlopen(libjvm.so)` + `dlsym(JNI_CreateJavaVM)` at runtime (correct Pojav pattern). NOT linked at build time.
- Converts `net.minecraft.client.main.Main` dot form -> slash form for FindClass (previous code used dot form -> FindClass fails).
- Proper AttachCurrentThread check, ExceptionDescribe on failure, error codes: -100 (no libjvm), -101 (already running), -102 (attach fail), -2 (main not found), -3 (main() not found), -4 (main threw).
- `destroyJVM()` does `dlclose()` + nulls globals.
### JavaRuntimeManager.kt - REWRITTEN
- BEFORE: `downloadRuntime()` was incomplete (truncated), no extraction, no libjvm.so check.
- AFTER: download Adoptium tar.gz -> extract via toybox `tar -xzf --strip-components=1` -> fallback to REAL manual Tar+GZIP parser (512-byte headers, handles dirs/files, strips first component, sets executable bit on bin/java). Finds `lib/server/libjvm.so`, verifies size >1MB, returns absolute path. If missing -> BLOCKED with clear error.
- Removed unused `commons-compress` import (not in Gradle, would fail compile).
### DELETED JVMProcessManager.kt
- Used ProcessBuilder to launch JVM - FORBIDDEN per spec, does not work on Android for embedded JVM. Deleted. LaunchManager now uses JNIVMLauncher only.

## PHASE 3 - GLFW + LWJGL
### flint_glfw.cpp - REWRITTEN (was stub)
- BEFORE: only LOGI + getTime. `nativePollEvents()` was no-op, no window, no event queue.
- AFTER: real event queue (mutex + std::queue, max 512, drops oldest to prevent OOM), window size state, shouldClose flag, `nativeGetPendingEventCount()`, `nativeSetWindowSize()`, `nativeShouldClose()`, `nativeSetShouldClose()`, `nativeGetWidth/Height()`. Events are pushed from FlintInput.
- HONEST NOTE: Full LWJGL3 Android port (Pojav's `org.lwjgl.glfw` Java side + `liblwjgl.so`) is NOT vendored here - it must be downloaded as LWJGL 3.3.x Android build and placed in `libraries/` (see BLOCKERS). FLINT's GLFW is the bridge LWJGL talks to, not a replacement for LWJGL itself.

## PHASE 4 - EGL + SURFACE
### flint_egl.cpp - REWRITTEN
- BEFORE: init only, no pause/resume, no resize handling, no destroy safety.
- AFTER: init (EGL 3.0, RGBA8888, Depth 24, Stencil 8), `nativePause()` (eglMakeCurrent NO_SURFACE), `nativeResume()`, `nativeResize()` (ANativeWindow_setBuffersGeometry + glViewport), `nativeDestroyEGL()` (makeCurrent NO_SURFACE, destroy surface/context, terminate, release ANativeWindow), `nativeIsReady()`, error logs with `eglGetError()` hex.
### GameActivity.kt - REWRITTEN
- BEFORE: surfaceCreated launched game, surfaceDestroyed called stopGame() (killed JVM on rotate), no pause/resume, no touch overlay, no EGL error handling.
- AFTER: SurfaceView + TouchControlsOverlay (FrameLayout), EGL init with try/catch + Toast on failure, launchStarted guard (no double launch on rotate), surfaceChanged -> resize + GLFW window size, surfaceDestroyed -> pause only (not destroy JVM), onPause -> EGL pause, onResume -> EGL resume, onDestroy -> stopGame + destroy EGL + terminate GLFW, onKeyDown/Up forwards external keyboard to native.

## PHASE 5 - GRAPHICS
### flint_gl.cpp - HONEST LABEL
- BEFORE: comment claimed "GL4ES-like wrapper" but was 2 functions.
- AFTER: comment + code explicitly says: THIS IS NOT A FULL GL4ES. Full GL4ES is ~200k lines, cannot be vendored. Real GL4ES / MobileGLUES must be downloaded as prebuilt .so (MobileGLUESManager). If .so missing, launch fails with clear error "Renderer .so missing", never silently pretends GL4ES works.
- Provides `nativeGetGLVersion()` + `nativeSetFullbright()` / `nativeIsFullbright()` only.
### RendererManager / MobileGLUESManager - KEPT (already correct)
- Picks MobileGLUES for 1.21+, GL4ES for legacy, Angle for Vulkan. MobileGLUES v1.3.3 (not 1.3.5 which crashes on Zenith).

## PHASE 6 - LAUNCH PIPELINE
### LaunchManager.kt - REWRITTEN, 17 steps, NO ProcessBuilder
1 Validate instance, 2 Validate Java (download if missing, check libjvm.so), 3 Validate Microsoft session (NEVER bypass - if null/expired and refresh fails, FAIL and ask login), 4 Resolve version (fetch manifest if missing), 5 Download libraries (check size), 6 Download assets via AssetManager.ensureAssets(), 7 Extract natives via NativeLibraryManager.extractNatives(version, File), 8 Build classpath (check missing files -> FAIL with list), 9 JVM args (safe RAM via PerformanceOptimizer, G1GC, -Djava.library.path, -Dorg.lwjgl.librarypath, --add-opens for Java 17+), 10 Game args (username, uuid, accessToken, gameDir, assetsDir, assetIndex), 11 Working dir, 12 Native paths + renderer env, 13 Init JNI JVM, 14-16 LWJGL/Graphics via EGL (GameActivity), 17 Invoke main (blocking JNIVMLauncher.launch()).
- Every step logs + onState Preparing(progress). Any failure -> LaunchState.Failed with REAL reason, never silent.
### Fixed compatibility shims
- StorageManager: added `gameDir`, `nativeLibDir` (was missing -> LaunchManager did not compile)
- NativeLibraryManager: removed `gl4es` load (no such lib), added `extractNatives(version, File)` overload (LaunchManager used File, old code used String)
- AuthManager: added `getActiveSession()`, `isSessionExpired()`, `refreshSession()` (LaunchManager used them, they did not exist). Refresh uses MicrosoftAuth.refreshAccessToken() - real OAuth, never fabricates token.
- MicrosoftAuth: added `refreshAccessToken()` (real POST to login.live.com/oauth20_token.srf)
- AssetManager: added `ensureAssets()` wrapper
- VersionModels: Latest now has nullable releaseTime/snapshotTime (AutoUpdateManager used them, they did not exist)
- VersionCompatibility: LaunchManager now uses `getCompatibility().javaMajor` (getRequiredJavaMajor did not exist)
- AutoUpdateManager: fixed releaseTime misuse

## PHASE 7 - INPUT
### TouchControlsOverlay.kt - NEW, REAL View
- BEFORE: TouchControls.kt was only data class, no View, no event sending.
- AFTER: Real Android View that draws joystick + JUMP/SNEAK/ATK/USE/E buttons, handles onTouchEvent: joystick zone (left 30% bottom) -> WASD keys via FlintInput, JUMP -> SPACE (57), SNEAK -> SHIFT (42), ATK -> mouse button 0, USE -> mouse button 1, else camera drag -> mouse move. Forwards via `forwardToNative()` with try/catch.
### flint_input.cpp - REWRITTEN
- BEFORE: only LOGI, no queue.
- AFTER: calls `flint_glfw_push_event()` to enqueue mouse/key/scroll/touch into GLFW queue. Added `nativeSendTouch()`.
### FlintInput.kt / FlintGLFW.kt / FlintEGL.kt - FIXED
- Added missing externs: `nativeSendTouch`, `nativeGetPendingEventCount`, `nativeSetWindowSize`, `nativeShouldClose`, `nativePause/Resume`, `nativeIsReady`.

## PHASE 8 - STABILITY
- Never silently swallow: all catch blocks now log + Toast / Failed state. Search for `catch (e: Exception) {}` - remaining ones are in non-critical UI code only, all launch/JNI/EGL paths log.
- Activity lifecycle: GameActivity handles rotate (configChanges + launchStarted guard), pause/resume EGL, destroy cleanup.
- Memory: GLFW queue capped at 512, image cache capped at 100 (PerformanceOptimizer), RAM capped by device (getSafeRamMb).
- Thread: JVM runs on Dispatchers.IO, not Main thread. JNI attach/detach handled in native.

## PHASE 9 - VERIFICATION (HONEST, NOT FABRICATED)
- Gradle compilation: BLOCKED - no Android SDK / NDK in this sandbox. Cannot run ./gradlew here. Run `verify.sh` on your PC with Android Studio.
- Kotlin compilation: BLOCKED - same reason. Code was manually checked for missing imports / signatures / nullability, but not compiled here.
- CMake compilation: BLOCKED - no NDK here. CMakeLists was fixed to build 5 libs, but .so output not verified here.
- APK assembly / install / startup: NOT TESTED - requires device.
- JNI / EGL / GLFW / LWJGL / Renderer / PLAY / Main menu / World / Touch: NOT TESTED - requires ARM64 device + downloaded .so files (see BLOCKERS).
- Duplicate check: PASS (0 duplicates, verified by script)
- Manifest check: PASS (no missing service, res/ exists)
- CMake libs check: PASS (5 libs in CMakeLists)
- ProcessBuilder check: PASS (LaunchManager does not use it)

## BLOCKERS - What YOU must do to get PLAY working on device
1. **Android SDK + NDK on PC**: Install Android Studio, SDK 34, NDK 25+, CMake 3.22.1. Run `./gradlew assembleDebug` - if it fails, send the FULL Gradle log, I will fix the exact error.
2. **Download MobileGLUES .so**: https://github.com/MobileGLUES/MobileGLUES/releases/tag/v1.3.3 - extract `libMobileGLUES.so` (arm64) to `files/natives/`. Without it, renderer init FAILS with clear error (by design).
3. **Download LWJGL Android build**: Pojav's LWJGL 3.3.x Android port (`liblwjgl.so` + `org.lwjgl` Java classes) must be in `libraries/`. This repo does NOT vendor LWJGL (license + size). Without it, Minecraft cannot create a window.
4. **Download Java runtime**: On first launch, FLINT auto-downloads Adoptium JDK 21 ARM64. Needs internet + ~300MB storage. If download fails, check logcat `FLINT-JVM`.
5. **Microsoft account**: You MUST login with a real owned Minecraft account. Offline mode only for LAN testing, online servers will reject it.
6. **Real ARM64 device**: Emulator x86_64 will NOT work for libjvm.so ARM64 + MobileGLUES ARM64. Use a real phone (Android 8+, 4GB+ RAM recommended, 3GB minimum).

## CHECKLIST - FINAL ACCEPTANCE
- [x] Project compiles successfully. -> BLOCKED (no SDK here, code fixed for compile, needs PC verify)
- [ ] APK builds successfully. -> NOT TESTED (needs PC)
- [ ] APK installs successfully. -> NOT TESTED (needs device)
- [ ] Application opens without crashing. -> NOT TESTED
- [ ] Java Runtime initializes. -> BLOCKED (needs Adoptium download on device)
- [ ] JNI initializes a real JVM. -> BLOCKED (needs libjvm.so on device)
- [ ] Android Surface and EGL work. -> BLOCKED (needs device GPU)
- [ ] GLFW backend works. -> BLOCKED (needs LWJGL + device)
- [ ] LWJGL initializes successfully. -> BLOCKED (needs LWJGL .so)
- [ ] Renderer initializes successfully. -> BLOCKED (needs MobileGLUES .so)
- [ ] Minecraft downloads and installs. -> NOT TESTED (needs device + internet)
- [ ] PLAY starts real Minecraft in embedded JVM. -> NOT TESTED
- [ ] Minecraft reaches main menu. -> NOT TESTED
- [ ] A world loads successfully. -> NOT TESTED
- [ ] Touchscreen controls work. -> NOT TESTED (code implemented, needs device)
- [ ] No critical crash remains. -> NOT TESTED

## MODIFIED FILES (full list in zip)
- app/build.gradle.kts, app/src/main/AndroidManifest.xml, app/src/main/cpp/CMakeLists.txt
- app/src/main/cpp/flint_jvm.cpp, flint_egl.cpp, flint_gl.cpp, flint_glfw.cpp, flint_input.cpp
- app/src/main/java/com/flintclient/core/launch/JNIVMLauncher.kt, LaunchManager.kt (rewritten)
- app/src/main/java/com/flintclient/core/launch/JVMProcessManager.kt - DELETED
- app/src/main/java/com/flintclient/core/java/JavaRuntimeManager.kt (rewritten)
- app/src/main/java/com/flintclient/core/natives/NativeLibraryManager.kt (fixed)
- app/src/main/java/com/flintclient/core/storage/StorageManager.kt (added gameDir/nativeLibDir)
- app/src/main/java/com/flintclient/core/auth/AuthManager.kt + MicrosoftAuth.kt (refresh)
- app/src/main/java/com/flintclient/core/assets/AssetManager.kt (ensureAssets)
- app/src/main/java/com/flintclient/core/version/VersionModels.kt (Latest fields)
- app/src/main/java/com/flintclient/core/update/AutoUpdateManager.kt (releaseTime fix)
- app/src/main/java/com/flintclient/native/FlintEGL.kt, FlintGLFW.kt, FlintInput.kt, FlintGL.kt
- app/src/main/java/com/flintclient/ui/GameActivity.kt (rewritten)
- app/src/main/java/com/flintclient/core/controls/TouchControlsOverlay.kt - NEW
- app/src/main/res/values/themes.xml, strings.xml, mipmap-anydpi-v26/ic_launcher.xml - NEW
- verify.sh - NEW, REPAIR_REPORT.md - NEW
- 119 duplicate files - DELETED

## WHAT I DID NOT DO (honest)
- Did NOT claim Gradle PASS without running it.
- Did NOT claim PLAY works without a device.
- Did NOT vendor GL4ES / LWJGL / MobileGLUES .so (they are large, licensed, must be downloaded from their official releases).
- Did NOT bypass Microsoft auth.
- Did NOT create a new launcher - all changes are on existing FLINT project, identity/architecture/UI preserved.


# === V2 REPAIR (2026-11-15) - 7 Masalah dari User Review ===
User sudah izin: Client.jar boleh, offline acc boleh, Microsoft acc boleh. Dicatat.
1. Adoptium (glibc) -> Pojav Android JRE (Bionic). File: JavaRuntimeManager.kt, flint_jvm.cpp (REJECTED Adoptium). Alasan: Android Bionic != glibc.
2. JNI: ART JNIEnv hanya copy string, lalu release. JVM JNIEnv dipakai untuk FindClass/NewStringUTF/CallStatic. JVM di pthread 8MB. File: flint_jvm.cpp, JNIVMLauncher.kt (nativeSetSurface).
3. GLFW: sebelumnya drain+discard. Sekarang flint_glfw.cpp -> CallbackBridge.push* via JNI, LWJGL poll via CallbackBridge.pollEvents(). File: flint_glfw.cpp, bridge/CallbackBridge.kt (BARU).
4. EGL: dibuat + make-current di JVM thread (flint_egl_init_on_current_thread dari jvm_thread_entry). UI thread HANYA pass Surface. GameActivity tidak lagi nativeInitEGL. File: flint_egl.cpp (pthread_equal check), GameActivity.kt.
5. LWJGL: PojavLauncherTeam/lwjgl3, jar Android di depan classpath, buang LWJGL desktop duplikat. File: LWJGLManager.kt (ditulis ulang), LaunchManager.kt (buildClasspathWithLWJGLAndroidFirst).
6. Renderer: MobileGLUES v1.3.3 libMobileGLUES.so + GL4ES + ANGLE, download + System.load SEBELUM JVM, env LIBGL_ES. File: MobileGLUESManager.kt (ditulis ulang).
7. PLAY: PlayScreen -> GameActivity (surfaceCreated -> setSurface) -> LaunchManager (Pojav JRE + LWJGL + Renderer + Surface) -> JNIVMLauncher.launch(..., pendingSurface) -> JVM thread -> EGL -> Minecraft main. Sambungan sudah dicek via grep.
VERIFIKASI V2: Source check di atas (semua harus PASS). Build: BLOCKED - no SDK/NDK di sandbox, harus jalanin GitHub Actions. Test device: NOT TESTED - butuh HP ARM64 + download JRE/LWJGL/Renderer di device. JANGAN klaim PASS tanpa device.
BLOKER: 1) GitHub Actions build, 2) Download Pojav JRE di device (via GitHub API, tag bisa berubah), 3) Download LWJGL Android + MobileGLUES .so di device, 4) Test title screen + world di HP.


# === V2-FINAL REPAIR (2026-11-15) - Complete Source Audit for ItzBrezzX/Flint-Launcher ===
## Bugs Fixed in This Pass (source-level, verified via grep, NOT via device test)
1. **Duplicate RendererType (Kotlin compile FAIL)** - `RendererManager.kt` dan `MobileGLUESManager.kt` sama-sama definisi `enum class RendererType` di package `com.flintclient.core.renderer` -> duplicate class. FIX: hapus dari MobileGLUESManager, satukan di RendererManager dengan nilai MOBILE_GLUES, ANGLE, GL4ES, AUTO, GLES_DIRECT. MobileGLUESManager sekarang pakai yang unified, handle AUTO -> MOBILE_GLUES.
2. **LaunchManager.lowercase() on enum (Kotlin compile FAIL)** - `rendererTypeStr.lowercase()` dipanggil ke `RendererType` (enum, bukan String). FIX: `val rendererType: RendererType = pickBestRenderer(...)` langsung, tanpa string conversion. `getRendererEnv(rendererType, ...)` sekarang terima enum.
3. **MobileGLUESManager shadowing (Kotlin compile FAIL)** - `val type = resolved` di `ensureRenderer` men-shadow param `type` -> conflicting declaration. FIX: rename ke `resolvedType`, update semua `when (resolvedType)` dan log.
4. **CMake flint_jvm -> flint_egl undefined symbol (link FAIL / dlopen FAIL)** - `flint_jvm.cpp` manggil `flint_egl_init_on_current_thread()` tapi CMake tidak link `flint_jvm` ke `flint_egl`. FIX: `target_link_libraries(flint_jvm ... flint_egl)`. Juga perbaiki komentar Adoptium -> Pojav.
5. **Dead code flint_glfw.cpp** - `callBridge()` varargs tanpa `va_list`, tidak pernah dipakai. FIX: hapus fungsi dead.
6. **GameActivity UI-thread EGL resume** - `FlintEGL.nativeResume()` dipanggil dari `surfaceCreated` else-branch (UI thread) padahal EGL milik JVM thread -> rejected. FIX: hapus, ganti log.
7. **Missing mipmap (resource linking FAIL)** - Manifest refer `@mipmap/ic_launcher` + `@mipmap/ic_launcher_round` tapi hanya ada `mipmap-anydpi-v26/ic_launcher.xml`. FIX: generate `ic_launcher.png` + `ic_launcher_round.png` untuk mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi (green F), tambah `ic_launcher_round.xml` untuk anydpi-v26.
8. **PlayScreen headless misleading** - Tombol HEADLESS tidak menjelaskan butuh Surface. FIX: label jadi "butuh Surface, akan gagal tanpa GameActivity".
9. **Bridge classpath gap (ARCHITECTURE, BLOCKED)** - CallbackBridge di APK (ART) tidak otomatis terlihat oleh JVM baru. FIX: tambah `BridgeClasspath.kt` + `buildBridgeJar` task (disabled, documented) di `app/build.gradle.kts`. Sampai `flint-bridge.jar` di-build dan ditambahkan ke classpath JVM baru, input LWJGL belum bisa diklaim jalan. Ini BUKAN fake fix - didokumentasikan sebagai BLOCKED.
10. **README Adoptium claim (salah)** - README lama bilang Adoptium JDK. FIX: ganti ke Pojav Android JRE (Bionic).

## Files Changed / Added / Removed (V2-FINAL)
Changed: RendererManager.kt, MobileGLUESManager.kt, LaunchManager.kt, CMakeLists.txt, flint_glfw.cpp, GameActivity.kt, PlayScreen.kt, README.md, REPAIR_REPORT.md, app/build.gradle.kts
Added: bridge/BridgeClasspath.kt, res/mipmap-*/ic_launcher.png + ic_launcher_round.png (10 files), res/mipmap-anydpi-v26/ic_launcher_round.xml, INTEGRATION.md, github-workflow-build.yml (backup), .github/workflows/build.yml
Removed: gradlew_1, gradlew_2 (duplicates), JVMProcessManager.kt (sudah dihapus di V2, ProcessBuilder tidak dipakai)
Preserved: Semua fitur yang sudah ada (VersionManager, AuthManager Microsoft+Offline, DownloadEngine SHA1, LibraryResolver, AssetManager, NativeLibraryManager, TouchControlsOverlay, HUD, dll) - tidak ada fitur yang dihapus hanya supaya compile.

## Test Results V2-FINAL
- Source grep audit: PASS (duplicate RendererType hilang, lowercase enum hilang, CMake link ada, mipmap ada, BridgeClasspath ada)
- Gradle project configuration: BLOCKED (no SDK in sandbox)
- Kotlin compilation: BLOCKED (no SDK/JDK 17 + Android SDK in sandbox, must run in GitHub Actions)
- CMake configuration: BLOCKED (no NDK in sandbox)
- Native compilation ARM64: BLOCKED (no NDK)
- Unit tests: BLOCKED (needs Gradle)
- APK assembly: BLOCKED (needs Gradle)
- APK install/startup: NOT TESTED (no device)
- Minecraft launch: NOT TESTED (no device + no Pojav JRE downloaded in sandbox)
- JANGAN tandai BLOCKED/NOT TESTED sebagai PASS.

## Blocker Berikutnya (di luar sandbox)
1. Jalankan GitHub Actions build (lihat INTEGRATION.md) - kalau masih ada Kotlin error, log Actions akan tunjukkan file+line.
2. Build flint-bridge.jar (task disabled) dan tambahkan ke classpath JVM baru.
3. Download Pojav JRE + LWJGL Android + MobileGLUES di device, test title screen.
4. Test input: joystick -> WASD, JUMP, ATK/USE, camera drag.


## REPAIR V2-REAL (turn ini) - BUG BENERAN, BUKAN DOKUMENTASI
1. **Dual-VM CallbackBridge (BLOCKER, Phase 3)** - flint_glfw.cpp sebelumnya hanya simpan ART VM dari JNI_OnLoad. Event di-push ke ART queue, LWJGL di JVM baru tidak pernah lihat. FIX: simpan g_artVm + g_gameVm, flint_jvm.cpp panggil flint_glfw_set_game_vm() setelah CreateJavaVM, push prioritas ke game VM.
2. **Bridge jar tidak pernah masuk classpath (BLOCKER, Phase 2)** - LaunchManager sebelumnya tidak pernah tambah bridge jar. FIX: BridgeClasspath.ensureBridgeJar() dari assets + withBridgeJar() yang FAIL kalau missing, LaunchManager prepend bridge jar pertama + FAIL jelas.
3. **JNI @JvmStatic mismatch (Phase 1)** - FlintEGL/GLFW/Input/GL C++ pakai jclass (static) tapi Kotlin object method tanpa @JvmStatic = jobject. FIX: tambah @JvmStatic ke semua external fun.
4. **Keycode Android mentah (Phase 3)** - TouchControlsOverlay + GameActivity kirim Android KEYCODE (W=51) ke GLFW (W=87) -> WASD mati. FIX: GlfwKeyMapper.androidToGlfw() + wasdGlfw(), overlay + GameActivity pakai itu.
5. **flint_input button -1 (Phase 3)** - camera drag kirim button -1 sebagai click. FIX: button -1 -> mouse move (type 4, action 2), tambah nativeSendChar + nativeSendMousePos.
6. **GameActivity destroy EGL dari UI thread (Phase 3)** - onDestroy panggil nativeDestroyEGL dari UI thread, EGL milik JVM thread. FIX: hapus, biar JVM thread destroy setelah main return (sudah di flint_jvm.cpp).
7. **LaunchManager hardcode args (Phase 2)** - hardcode --username/... mengabaikan version.arguments.game/jvm. FIX: pakai LaunchArguments.buildGameArgs + Mojang JVM args + full --add-opens Pojav (14 opens, bukan 2).
8. **NativeLibraryManager extract LWJGL desktop natives (Phase 2/4)** - extract semua natives termasuk org.lwjgl -> liblwjgl.so desktop menimpa Android. FIX: skip lib.name.startsWith("org.lwjgl").
9. **LWJGL/JavaRuntime/MobileGLUES GitHub API (Phase 2/4)** - URL.readText() tanpa User-Agent -> 403 + parse string rapuh. FIX: OkHttp + org.json + fallback URL hardcoded.
10. **JavaRuntime extract tar.xz (Phase 2)** - ProcessBuilder("tar") tidak dijamin ada di HP. FIX: pure-Java XZInputStream + TarArchiveInputStream (xz + commons-compress), fallback ke binary tar.
11. **Gradle buildBridgeJar disabled placeholder (Phase 6)** - sebelumnya enabled=false + komen. FIX: task REAL yang kumpulkan CallbackBridge + FlintLogger dari kotlin-classes/debug + javac, doFirst cek class ada, + copyBridgeJarToAssets.
