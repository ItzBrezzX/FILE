#!/bin/bash
# FLINT verify.sh - honest verification, NEVER fabricates PASS
# Run on a machine WITH Android SDK + NDK + device. In this sandbox (no SDK) it will report BLOCKED, not PASS.
echo "=== FLINT VERIFICATION ==="
echo "1. Check Android SDK..."
if [ -z "$ANDROID_HOME" ] && [ ! -d "$HOME/Android/Sdk" ] && [ ! -d "/opt/android-sdk" ]; then echo "BLOCKED: ANDROID_HOME not set, no Android SDK in this environment. Cannot run Gradle build here."; echo "To verify on your PC: set ANDROID_HOME, run ./gradlew assembleDebug"; else echo "SDK found: $ANDROID_HOME"; fi
echo "2. Check duplicates..."
DUP=$(find app/src -name "*_1.kt" -o -name "*_2.kt" | wc -l)
if [ "$DUP" -eq 0 ]; then echo "PASS: No _1/_2 duplicate .kt files"; else echo "FAIL: $DUP duplicate files remain"; fi
echo "3. Check CMake libs..."
grep -q "flint_egl" app/src/main/cpp/CMakeLists.txt && echo "PASS: CMake builds flint_egl" || echo "FAIL: CMake missing flint_egl"
grep -q "flint_glfw" app/src/main/cpp/CMakeLists.txt && echo "PASS: CMake builds flint_glfw" || echo "FAIL: CMake missing flint_glfw"
echo "4. Check ProcessBuilder NOT used for JVM..."
if grep -r "ProcessBuilder" app/src/main/java/com/flintclient/core/launch/LaunchManager.kt; then echo "FAIL: LaunchManager still uses ProcessBuilder"; else echo "PASS: LaunchManager does NOT use ProcessBuilder"; fi
echo "5. Check manifest service..."
if grep -q "HUDOverlayService" app/src/main/AndroidManifest.xml; then echo "FAIL: Manifest still references missing service"; else echo "PASS: Manifest clean"; fi
echo "6. Check res/ exists..."
[ -f "app/src/main/res/values/themes.xml" ] && echo "PASS: res/values/themes.xml exists" || echo "FAIL: res missing"
echo "=== END - Device tests (EGL, JVM, PLAY, world) require a real ARM64 device, see TESTING.md ==="
