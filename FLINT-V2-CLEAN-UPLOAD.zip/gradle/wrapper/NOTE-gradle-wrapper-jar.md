# Kenapa gradle-wrapper.jar tidak ada di repo ini?

`gradle-wrapper.jar` adalah file binary (~60 KB) yang seharusnya di-commit bersama `gradlew` + `gradle-wrapper.properties`.

Di upload ini file itu TIDAK ADA, karena:
1. Sandbox / mesin yang menyiapkan ZIP ini tidak punya Gradle + tidak punya internet untuk menjalankan `gradle wrapper`, jadi jar tidak pernah dibuat.
2. `gradlew` di repo ini adalah script fallback (628 byte), bukan script wrapper resmi Gradle yang panjang (~8 KB). Dia sengaja dibuat fallback: kalau `gradle-wrapper.jar` ada -> pakai jar, kalau tidak ada -> pakai `gradle` dari PATH.
3. Workflow GitHub Actions di `.github/workflows/build.yml` TIDAK memakai `./gradlew`, tapi memakai `gradle` dari `gradle/actions/setup-gradle` - jadi build di Actions tidak butuh wrapper jar.

## Cara membuat wrapper jar yang benar (di laptop, sekali saja)

Di laptop yang sudah install Android Studio / Gradle + internet:

```bash
cd Flint-Launcher
gradle wrapper --gradle-version 8.5 --distribution-type all
git add gradle/wrapper/gradle-wrapper.jar gradlew gradlew.bat
git commit -m "Add Gradle wrapper jar"
git push
```

Setelah itu, `gradlew` resmi dari Gradle akan menimpa `gradlew` fallback di sini. Sampai saat itu, JANGAN mengklaim `./gradlew` bekerja di semua mesin - di Actions yang dipakai adalah `gradle` dari setup-gradle.

## Jangan
- Jangan copy `gradlew_1` / `gradlew_2` dari ZIP lama - itu duplikat stub placeholder, sudah dihapus di upload bersih ini.
- Jangan commit file `*_1.kt`, `*_2.kt`, `*_1.md` - itu duplikat auto-rename, bukan source asli.
