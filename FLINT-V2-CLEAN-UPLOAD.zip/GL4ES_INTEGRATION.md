# GL4ES Integration - FLINT CLIENT

FLINT memakai shim GLESv3 di `cpp/flint_gl.cpp` untuk tahap awal.
Untuk Minecraft 1.16+ full compatibility, integrasikan GL4ES upstream (MIT, ptitSeb/gl4es):

```bash
git submodule add https://github.com/ptitSeb/gl4es.git app/src/main/cpp/gl4es
```

Lalu di `app/src/main/cpp/CMakeLists.txt` tambahkan:
```cmake
add_subdirectory(gl4es)
target_link_libraries(flint_gl GL)
```

Kenapa GL4ES penting?
- Minecraft Java pakai OpenGL 3.2+ desktop, Android cuma punya OpenGL ES 3.x
- GL4ES translate GL -> GLES, sama seperti yang dipakai PojavLauncher
- Tanpa GL4ES, shader & rendering 1.17+ akan error

Di FLINT, EGL context di `flint_egl.cpp` sudah disiapkan untuk GL4ES:
- Context ES 3.0, depth 24, stencil 8
- `eglMakeCurrent` sebelum JVM start (lihat GameActivity.kt)
- `nativeResize` memanggil `glViewport` saat surface berubah

Setelah submodule ditambahkan, ganti `FlintGL.nativeGetGLVersion()` untuk return `gl4es version`.
