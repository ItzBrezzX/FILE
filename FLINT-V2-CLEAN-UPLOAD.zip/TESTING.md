# FLINT CLIENT - CARA TEST (Part 6)

## 1. Build APK
1. Buka Android Studio -> Open folder `flint-client`
2. Sync Gradle (tunggu sampai selesai, jangan skip)
3. Build > Build APK(s) > Build APK(s) -> Install ke HP
4. Kalau error di native: pastikan NDK terinstall, CMake 3.22.1

## 2. Test Urutan (jangan loncat!)
Ikuti `LaunchTestChecklist.kt` T01 s/d T15. Urutan penting:
- T01 Buka Launcher dulu
- T02 Auto Update Snapshot
- T03 Install 1.21.10
- T04 PLAY 1.21.10 -> Title Screen
- T05 Masuk World 30 detik
- Kalau T04 gagal, jangan lanjut ke T06. Screenshot logcat + kirim ke aku.

## 3. Kalau Crash, Kirim Ini:
- HP: (contoh: Redmi Note 12, 4GB RAM)
- Android: (contoh: Android 13)
- Versi yang di-test: (1.21.10 / snapshot / b1.7.3)
- Renderer: (MobileGLUES / Angle / GL4ES)
- Logcat: `adb logcat | grep FLINT` atau dari CrashReporter di app
- Screenshot error

## 4. Yang Sudah Bisa Di-test Sekarang:
- UI Main Menu + Mod Menu (preview HTML sudah 100%)
- Auto Update manifest (fetch Mojang)
- Modrinth search live (butuh internet)
- Controller detection (butuh controller BT)
- Version filter All/Release/Snapshot/Beta/Alpha

## 5. Yang Masih Butuh .so Real:
- MobileGLUES .so harus di-download dari GitHub MobileGLUES v1.3.3, extract ke files/natives/
- libjvm.so dari Adoptium Java 21, extract ke files/java/21/lib/server/
- Tanpa 2 file .so itu, PLAY akan log "JVM gagal" - itu wajar, bukan bug code.

## 6. Template Laporan:
Lihat `LaunchTestChecklist.getTestReportTemplate()` - copy, isi PASS/FAIL, kirim ke aku.


## TEST RESULTS - V2-REAL (turn ini, jujur, tidak diklaim PASS kalau belum diuji)
- Source grep audit (dual-VM, bridge, @JvmStatic, keymapper, VersionCompatibility): PASS - semua check di atas PASS di sandbox.
- Kotlin compilation (./gradlew assembleDebug): BLOCKED - sandbox tidak punya Android SDK / NDK / Gradle wrapper jar. Harus jalan di GitHub Actions (workflow .github/workflows/build.yml sudah diperbarui: buildBridgeJar dulu, baru assembleDebug).
- CMake native compilation: BLOCKED - alasan sama, NDK tidak ada di sandbox.
- Unit tests: NOT TESTED - belum jalan karena build BLOCKED.
- APK assembly: NOT TESTED / BLOCKED - belum ada APK karena build BLOCKED.
- APK install + startup di HP: NOT TESTED - tidak ada device Android di sandbox.
- Minecraft launch nyata (1.21.1 + Pojav JRE + LWJGL Android + MobileGLUES): NOT TESTED - butuh HP ARM64 + JRE + internet + akun Microsoft. Jangan klaim jalan sampai diuji di HP.
- JNI signature check (manual grep Kotlin package vs C++ JNI name): PASS - FlintEGL/GLFW/Input/GL/JNIVMLauncher semua cocok.
- Duplicate class check: PASS - VersionCompatibility duplicate sudah diperbaiki, tidak ada duplicate lain.
